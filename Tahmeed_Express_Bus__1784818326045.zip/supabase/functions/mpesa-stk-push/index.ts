import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const MPESA_CONSUMER_KEY = Deno.env.get("MPESA_CONSUMER_KEY") ?? "";
const MPESA_CONSUMER_SECRET = Deno.env.get("MPESA_CONSUMER_SECRET") ?? "";
const MPESA_BUSINESS_SHORT_CODE = Deno.env.get("MPESA_BUSINESS_SHORT_CODE") ?? "529914";
const MPESA_PASSKEY = Deno.env.get("MPESA_PASSKEY") ?? "";
const MPESA_CALLBACK_URL = Deno.env.get("MPESA_CALLBACK_URL") ?? "";

const SANDBOX = (Deno.env.get("MPESA_ENVIRONMENT") ?? "production") === "sandbox";
const BASE_URL = SANDBOX
  ? "https://sandbox.safaricom.co.ke"
  : "https://api.safaricom.co.ke";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function generateOAuthToken(): Promise<string> {
  const credentials = btoa(`${MPESA_CONSUMER_KEY}:${MPESA_CONSUMER_SECRET}`);
  const response = await fetch(
    `${BASE_URL}/oauth/v1/generate?grant_type=client_credentials`,
    { headers: { Authorization: `Basic ${credentials}` } },
  );
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`OAuth token generation failed (${response.status}): ${errorText}`);
  }
  const data = await response.json();
  return data.access_token;
}

function generateTimestamp(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");
  return `${year}${month}${day}${hours}${minutes}${seconds}`;
}

function generatePassword(shortCode: string, passkey: string, timestamp: string): string {
  return btoa(`${shortCode}${passkey}${timestamp}`);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  try {
    const { phone_number, amount, account_reference } = await req.json();

    if (!phone_number || !amount) {
      return new Response(
        JSON.stringify({ success: false, error: "Phone number and amount are required" }),
        { status: 400, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } },
      );
    }

    const numericAmount = Math.round(Number(amount));
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return new Response(
        JSON.stringify({ success: false, error: "Amount must be a positive number" }),
        { status: 400, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } },
      );
    }

    // Normalize phone number to 2547XXXXXXXX format
    let normalizedPhone = phone_number.replace(/[\s-]/g, "");
    if (normalizedPhone.startsWith("0")) normalizedPhone = "254" + normalizedPhone.substring(1);
    else if (normalizedPhone.startsWith("+")) normalizedPhone = normalizedPhone.substring(1);
    else if (!normalizedPhone.startsWith("254")) normalizedPhone = "254" + normalizedPhone;

    if (!/^254[17]\d{8}$/.test(normalizedPhone)) {
      return new Response(
        JSON.stringify({ success: false, error: "Invalid phone number format. Use 07XXXXXXXX or 01XXXXXXXX" }),
        { status: 400, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } },
      );
    }

    console.log("[STK Push] Generating OAuth token...");
    const accessToken = await generateOAuthToken();
    const timestamp = generateTimestamp();
    const password = generatePassword(MPESA_BUSINESS_SHORT_CODE, MPESA_PASSKEY, timestamp);
    console.log(`[STK Push] Timestamp: ${timestamp}, Short Code: ${MPESA_BUSINESS_SHORT_CODE}`);

    const stkPushPayload = {
      BusinessShortCode: MPESA_BUSINESS_SHORT_CODE,
      Password: password,
      Timestamp: timestamp,
      TransactionType: "CustomerPayBillOnline",
      Amount: numericAmount,
      PartyA: normalizedPhone,
      PartyB: MPESA_BUSINESS_SHORT_CODE,
      PhoneNumber: normalizedPhone,
      CallBackURL: MPESA_CALLBACK_URL,
      AccountReference: account_reference || "Booking",
      TransactionDesc: "Tahmeed Express Bus Ticket",
    };

    console.log("[STK Push] Sending STK Push request...");
    const stkResponse = await fetch(`${BASE_URL}/mpesa/stkpush/v1/processrequest`, {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
      body: JSON.stringify(stkPushPayload),
    });

    const stkData = await stkResponse.json();
    console.log("[STK Push] Response:", JSON.stringify(stkData));

    if (stkData.ResponseCode !== "0") {
      return new Response(
        JSON.stringify({ success: false, error: stkData.errorMessage || "STK Push request failed", details: stkData }),
        { status: 400, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } },
      );
    }

    // Save transaction to database
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { error: dbError } = await supabase.from("mpesa_transactions").insert({
      merchant_request_id: stkData.MerchantRequestID,
      checkout_request_id: stkData.CheckoutRequestID,
      phone_number: normalizedPhone,
      amount: numericAmount,
      account_reference: account_reference || "Booking",
      transaction_desc: "Tahmeed Express Bus Ticket",
      status: "pending",
    });

    if (dbError) console.error("[STK Push] Database insert error:", dbError);

    return new Response(
      JSON.stringify({
        success: true,
        merchant_request_id: stkData.MerchantRequestID,
        checkout_request_id: stkData.CheckoutRequestID,
        response_code: stkData.ResponseCode,
        response_description: stkData.ResponseDescription,
        customer_message: stkData.CustomerMessage,
      }),
      { status: 200, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } },
    );
  } catch (error) {
    console.error("[STK Push] Error:", error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 500, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } },
    );
  }
});
