import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// ============================================================
// M-Pesa Callback Handler
// Receives payment result from Safaricom Daraja API
// Updates the mpesa_transactions table with the result
// ============================================================

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "content-type",
};

Deno.serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  try {
    // Parse the callback payload from Safaricom
    const body = await req.json();
    console.log("[M-Pesa Callback] Received:", JSON.stringify(body));

    // Safaricom sends the result in Body.stkCallback
    const stkCallback = body?.Body?.stkCallback;

    if (!stkCallback) {
      console.error("[M-Pesa Callback] Invalid callback structure");
      return new Response(
        JSON.stringify({ ResultCode: 1, ResultDesc: "Invalid callback" }),
        { status: 400, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } },
      );
    }

    const {
      MerchantRequestID,
      CheckoutRequestID,
      ResultCode,
      ResultDesc,
      CallbackMetadata,
    } = stkCallback;

    // Initialize Supabase client with service role (bypasses RLS)
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Determine transaction status from ResultCode
    // ResultCode 0 = success, anything else = failure
    const status = ResultCode === 0 ? "completed" : "failed";

    // Extract callback metadata by index (matches Safaricom Daraja callback format)
    // Index 0: Amount, Index 1: MpesaReceiptNumber, Index 2: TransactionDate/BookingRef,
    // Index 3: TransactionDate, Index 4: PhoneNumber
    let mpesaReceiptNumber: string | null = null;
    let callbackPhone: string | null = null;
    let callbackAmount: number | null = null;
    let bookingRef: string | null = null;

    if (CallbackMetadata?.Item) {
      const meta = CallbackMetadata.Item;
      if (meta[0]) callbackAmount = meta[0].Value;
      if (meta[1]) mpesaReceiptNumber = meta[1].Value;
      if (meta[2]) bookingRef = meta[2].Value;
      if (meta[4]) callbackPhone = String(meta[4].Value);
    }

    console.log(`[M-Pesa Callback] Amount: ${callbackAmount}, Receipt: ${mpesaReceiptNumber}, Ref: ${bookingRef}, Phone: ${callbackPhone}`);

    // Update the transaction record
    const { error: updateError } = await supabase
      .from("mpesa_transactions")
      .update({
        status,
        result_code: String(ResultCode),
        result_description: ResultDesc,
        mpesa_receipt_number: mpesaReceiptNumber,
        callback_metadata: CallbackMetadata,
        updated_at: new Date().toISOString(),
      })
      .eq("checkout_request_id", CheckoutRequestID);

    if (updateError) {
      console.error("[M-Pesa Callback] Database update error:", updateError);
      return new Response(
        JSON.stringify({ ResultCode: 1, ResultDesc: "Database update failed" }),
        { status: 500, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } },
      );
    }

    console.log(
      `[M-Pesa Callback] Transaction ${CheckoutRequestID} updated to status: ${status}`,
      mpesaReceiptNumber ? `| Receipt: ${mpesaReceiptNumber}` : "",
    );

    // Always return success to Safaricom (they expect this)
    return new Response(
      JSON.stringify({
        ResultCode: 0,
        ResultDesc: "Accepted",
      }),
      { status: 200, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } },
    );
  } catch (error) {
    console.error("[M-Pesa Callback] Error:", error);
    return new Response(
      JSON.stringify({
        ResultCode: 1,
        ResultDesc: error instanceof Error ? error.message : "Internal server error",
      }),
      { status: 500, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } },
    );
  }
});
