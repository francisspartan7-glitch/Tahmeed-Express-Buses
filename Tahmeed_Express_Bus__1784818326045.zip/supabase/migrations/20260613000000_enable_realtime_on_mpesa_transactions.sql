-- Enable Realtime on mpesa_transactions table for frontend subscription
ALTER PUBLICATION supabase_realtime ADD TABLE mpesa_transactions;

-- Ensure the replica identity is set to FULL for Realtime to capture all changes
ALTER TABLE mpesa_transactions REPLICA IDENTITY FULL;

-- Add index on checkout_request_id for fast lookups (used by frontend subscription)
CREATE INDEX IF NOT EXISTS idx_mpesa_transactions_checkout_request_id 
ON mpesa_transactions(checkout_request_id);

-- Add index on status for filtering
CREATE INDEX IF NOT EXISTS idx_mpesa_transactions_status 
ON mpesa_transactions(status);

-- Add index on created_at for ordering
CREATE INDEX IF NOT EXISTS idx_mpesa_transactions_created_at 
ON mpesa_transactions(created_at DESC);
