export type View = 'home' | 'search-results' | 'seat-passenger' | 'payment' | 'ticket' | 'admin';
export type PaymentMethod = 'stk' | 'paybill' | 'till' | 'send';
