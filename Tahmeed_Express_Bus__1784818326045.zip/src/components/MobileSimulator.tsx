"use client";

import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import {
  Bus,
  MapPin,
  Calendar,
  Search as MagnifyingGlass,
  ChevronDown as CaretDown,
  Check,
  ArrowLeft,
  ArrowRight,
  Users,
  Star,
  Plug as PlugCharging,
  Phone,
  Wifi as WifiHigh,
  Battery as BatteryHigh,
} from "lucide-react";
import { toast } from "sonner";
import { BRAND, CITIES, FEATURES } from "../constants";
import { routes } from "../data/travelData";

// ---- Types ----
type TripType = "one-way" | "round-trip";
type AppStep = "booking" | "searching" | "results" | "ticket";

interface City {
  id: string;
  name: string;
  code: string;
  region: string;
  popular: boolean;
}

interface Trip {
  id: string;
  from: string;
  to: string;
  departTime: string;
  arriveTime: string;
  duration: string;
  price: number;
  busType: string;
  seatsAvailable: number;
  operator: string;
  rating: number;
}

// ---- Helpers ----
const formatDate = (d: Date): string =>
  d.toLocaleDateString("en-KE", { weekday: "short", day: "numeric", month: "short" });

const getTomorrow = (): Date => {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  d.setHours(0, 0, 0, 0);
  return d;
};

const getDayAfter = (d: Date): Date => {
  const next = new Date(d);
  next.setDate(next.getDate() + 1);
  return next;
};

// ---- Mini Calendar ----
const MiniCalendar: React.FC<{
  selected: Date | null;
  onSelect: (d: Date) => void;
  minDate: Date;
  onClose: () => void;
}> = ({ selected, onSelect, minDate, onClose }) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());

  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const firstDayOfWeek = new Date(viewYear, viewMonth, 1).getDay();
  const adjustedFirstDay = firstDayOfWeek === 0 ? 6 : firstDayOfWeek - 1;

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ];

  const prevMonth = () => {
    if (viewMonth === 0) { setViewYear(viewYear - 1); setViewMonth(11); }
    else setViewMonth(viewMonth - 1);
  };
  const nextMonth = () => {
    if (viewMonth === 11) { setViewYear(viewYear + 1); setViewMonth(0); }
    else setViewMonth(viewMonth + 1);
  };

  const canGoPrev = viewYear > today.getFullYear() || (viewYear === today.getFullYear() && viewMonth > today.getMonth());

  const days: (number | null)[] = [];
  for (let i = 0; i < adjustedFirstDay; i++) days.push(null);
  for (let d = 1; d <= daysInMonth; d++) days.push(d);

  const isDisabled = (day: number): boolean => {
    const d = new Date(viewYear, viewMonth, day);
    d.setHours(0, 0, 0, 0);
    return d < minDate;
  };

  const isSelected = (day: number): boolean =>
    selected !== null && selected.getFullYear() === viewYear && selected.getMonth() === viewMonth && selected.getDate() === day;

  const isToday = (day: number): boolean =>
    today.getFullYear() === viewYear && today.getMonth() === viewMonth && today.getDate() === day;

  return (
    <motion.div
      initial={{ opacity: 0, y: -8, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -8, scale: 0.97 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-zinc-200/80 p-4 z-30"
    >
      <div className="flex items-center justify-between mb-4">
        <button onClick={prevMonth} disabled={!canGoPrev} className="p-1.5 rounded-full hover:bg-zinc-100 disabled:opacity-30 disabled:cursor-default transition-colors" aria-label="Previous month">
          <ArrowLeft size={16} />
        </button>
        <span className="text-sm font-semibold text-zinc-800">{monthNames[viewMonth]} {viewYear}</span>
        <button onClick={nextMonth} className="p-1.5 rounded-full hover:bg-zinc-100 transition-colors" aria-label="Next month">
          <ArrowRight size={16} />
        </button>
      </div>
      <div className="grid grid-cols-7 gap-0.5 text-center">
        {["Mo","Tu","We","Th","Fr","Sa","Su"].map((d) => (
          <div key={d} className="text-[10px] font-semibold text-zinc-400 uppercase py-1">{d}</div>
        ))}
        {days.map((day, i) => {
          if (day === null) return <div key={`e-${i}`} />;
          const disabled = isDisabled(day);
          const sel = isSelected(day);
          const tdy = isToday(day);
          return (
            <button
              key={day}
              disabled={disabled}
              onClick={() => { if (!disabled) { onSelect(new Date(viewYear, viewMonth, day)); onClose(); } }}
              className={`w-9 h-9 text-xs rounded-full flex items-center justify-center transition-colors ${
                disabled ? "text-zinc-300 cursor-default" : "hover:bg-zinc-100 cursor-pointer"
              } ${sel ? "bg-[#0F4C43] text-white hover:bg-[#0F4C43] font-bold" : ""} ${tdy && !sel ? "font-bold text-[#0F4C43]" : ""}`}
            >
              {day}
            </button>
          );
        })}
      </div>
    </motion.div>
  );
};

// ---- City Dropdown ----
const CityDropdown: React.FC<{
  value: City | null;
  onChange: (city: City) => void;
  excludeId?: string;
  placeholder: string;
  icon: React.ReactNode;
}> = ({ value, onChange, excludeId, placeholder, icon }) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) { setOpen(false); setQuery(""); }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filtered = CITIES.filter((c) => c.id !== excludeId && c.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-3 py-3 bg-zinc-50 rounded-xl border border-zinc-200/80 text-left transition-all focus:outline-none focus:ring-2 focus:ring-[#0F4C43]/30"
      >
        <span className="text-zinc-400 shrink-0">{icon}</span>
        <span className={`flex-1 text-sm ${value ? "text-zinc-900 font-medium" : "text-zinc-400"}`}>
          {value ? `${value.name} (${value.code})` : placeholder}
        </span>
        <motion.span animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <CaretDown size={14} className="text-zinc-400" />
        </motion.span>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-zinc-200/80 z-20 overflow-hidden"
          >
            <div className="px-3 pt-3 pb-2">
              <div className="flex items-center gap-2 px-3 py-2 bg-zinc-50 rounded-xl">
                <MagnifyingGlass size={14} className="text-zinc-400 shrink-0" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search city..."
                  className="bg-transparent text-sm text-zinc-900 placeholder:text-zinc-400 outline-none flex-1"
                  autoFocus
                />
              </div>
            </div>
            <div className="max-h-52 overflow-y-auto">
              {filtered.length === 0 && (
                <div className="px-4 py-6 text-sm text-zinc-400 text-center">No cities found</div>
              )}
              {filtered.map((city) => (
                <button
                  key={city.id}
                  type="button"
                  onClick={() => { onChange(city as City); setOpen(false); setQuery(""); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-zinc-50 transition-colors ${value?.id === city.id ? "bg-emerald-50/70" : ""}`}
                >
                  <div className="w-9 h-9 rounded-xl bg-zinc-100 flex items-center justify-center text-xs font-bold text-zinc-600">{city.code}</div>
                  <div className="flex-1 text-left">
                    <div className="text-sm font-semibold text-zinc-800">{city.name}</div>
                    <div className="text-[11px] text-zinc-500">{city.region}</div>
                  </div>
                  {value?.id === city.id && <Check size={16} className="text-[#0F4C43]" />}
                  {city.popular && (
                    <span className="text-[10px] font-semibold text-[#E29548] bg-amber-50 px-2 py-0.5 rounded-full">Popular</span>
                  )}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// ---- Date Field ----
const DateField: React.FC<{
  value: Date | null;
  onChange: (d: Date) => void;
  minDate: Date;
  placeholder: string;
}> = ({ value, onChange, minDate, placeholder }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-3 py-3 bg-zinc-50 rounded-xl border border-zinc-200/80 text-left transition-all focus:outline-none focus:ring-2 focus:ring-[#0F4C43]/30"
      >
        <Calendar size={18} className="text-zinc-400 shrink-0" />
        <span className={`flex-1 text-sm ${value ? "text-zinc-900 font-medium" : "text-zinc-400"}`}>
          {value ? formatDate(value) : placeholder}
        </span>
      </button>
      <AnimatePresence>
        {open && (
          <MiniCalendar selected={value} onSelect={onChange} minDate={minDate} onClose={() => setOpen(false)} />
        )}
      </AnimatePresence>
    </div>
  );
};

// ---- Trip Type Toggle ----
const TripTypeToggle: React.FC<{ value: TripType; onChange: (t: TripType) => void }> = ({ value, onChange }) => (
  <div className="relative flex bg-zinc-100 rounded-xl p-1">
    <motion.div
      className="absolute top-1 bottom-1 rounded-lg bg-white shadow-sm border border-zinc-200/60"
      animate={{ left: value === "one-way" ? "0.25rem" : "calc(50%)", width: "calc(50% - 0.25rem)" }}
      transition={{ type: "spring", stiffness: 400, damping: 30 }}
    />
    {(["one-way", "round-trip"] as TripType[]).map((t) => (
      <button
        key={t}
        type="button"
        onClick={() => onChange(t)}
        className={`relative z-10 flex-1 py-2.5 text-sm font-semibold rounded-lg transition-colors ${value === t ? "text-zinc-900" : "text-zinc-500"}`}
      >
        {t === "one-way" ? "One Way" : "Round Trip"}
      </button>
    ))}
  </div>
);

// ---- Feature Card ----
const iconMap: Record<string, React.FC<{ size?: number; className?: string; style?: React.CSSProperties }>> = {
  Phone, PlugCharging, Users, Star, WifiHigh, BatteryHigh
};

const FeatureCard: React.FC<{ feature: (typeof FEATURES)[number]; index: number }> = ({ feature, index }) => {
  const Icon = iconMap[feature.icon];
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] }}
      className="bg-white rounded-2xl border border-zinc-200/70 p-4 flex flex-col gap-2 hover:shadow-lg hover:shadow-zinc-200/50 hover:border-zinc-300 transition-all duration-300"
    >
      <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: feature.color + "14" }}>
        {Icon && <Icon size={20} className="text-current" style={{ color: feature.color }} />}
      </div>
      <div>
        <div className="text-sm font-bold text-zinc-800">{feature.title}</div>
        <div className="text-[11px] text-zinc-500 leading-relaxed mt-0.5">{feature.description}</div>
      </div>
    </motion.div>
  );
};

// ---- Status Bar ----
const StatusBar: React.FC = () => (
  <div className="flex items-center justify-between px-5 pt-3 pb-1">
    <span className="text-[10px] font-semibold text-zinc-900">9:41</span>
    <div className="flex items-center gap-1.5">
      <WifiHigh size={12} className="text-zinc-700" />
      <BatteryHigh size={14} className="text-zinc-700" />
    </div>
  </div>
);

// ---- Searching View ----
const SearchingView: React.FC = () => {
  const reduce = useReducedMotion();
  const steps = ["Finding available buses...", "Checking seat availability...", "Verifying schedules...", "Almost there..."];
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setStepIndex((prev) => (prev < steps.length - 1 ? prev + 1 : prev));
    }, 800);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center py-12 gap-6">
      <motion.div
        animate={reduce ? undefined : { scale: [1, 1.08, 1], opacity: [0.6, 1, 0.6] }}
        transition={{ repeat: Infinity, duration: 1.2, ease: "easeInOut" }}
        className="w-20 h-20 rounded-2xl bg-[#0F4C43] flex items-center justify-center shadow-lg shadow-[#0F4C43]/30"
      >
        <Bus size={36} className="text-white" />
      </motion.div>

      <div className="text-center">
        <motion.div
          key={stepIndex}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-sm font-bold text-zinc-800"
        >
          {steps[stepIndex]}
        </motion.div>
      </div>

      <div className="w-48 h-1.5 bg-zinc-200 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: "0%" }}
          animate={{ width: "100%" }}
          transition={{ duration: 3.2, ease: "easeInOut" }}
          className="h-full bg-[#0F4C43] rounded-full"
        />
      </div>
    </div>
  );
};

// ---- Results View ----
const ResultsView: React.FC<{
  trips: Trip[];
  onSelect: (trip: Trip) => void;
  onBack: () => void;
  fromCity: City;
  toCity: City;
}> = ({ trips, onSelect, onBack, fromCity, toCity }) => {
  const reduce = useReducedMotion();
  const container = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.06 } },
  };
  const item = {
    hidden: { opacity: 0, y: 16 },
    show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] } },
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="w-9 h-9 rounded-full bg-zinc-100 flex items-center justify-center hover:bg-zinc-200 transition-colors" aria-label="Back to search">
          <ArrowLeft size={16} className="text-zinc-600" />
        </button>
        <div>
          <div className="text-sm font-bold text-zinc-800 flex items-center gap-2">
            {fromCity.name} <ArrowRight size={12} className="text-zinc-400" /> {toCity.name}
          </div>
          <div className="text-[11px] text-zinc-500">{trips.length} trips available</div>
        </div>
      </div>

      <motion.div variants={reduce ? undefined : container} initial={reduce ? false : "hidden"} animate="show" className="flex flex-col gap-3">
        {trips.map((trip) => (
          <motion.button
            key={trip.id}
            variants={reduce ? undefined : (item as any)}
            onClick={() => onSelect(trip)}
            className="bg-white rounded-2xl border border-zinc-200/70 p-4 text-left hover:border-[#0F4C43]/30 hover:shadow-lg hover:shadow-zinc-200/50 transition-all active:scale-[0.98]"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">{trip.operator}</span>
              <span className="text-[10px] font-bold text-[#E29548] bg-amber-50 px-2.5 py-0.5 rounded-full">{trip.busType}</span>
            </div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="text-xl font-black text-zinc-900">{trip.departTime}</div>
                <div className="flex flex-col items-center">
                  <div className="w-10 h-[2px] bg-zinc-300 rounded-full" />
                  <span className="text-[10px] text-zinc-400 font-semibold">{trip.duration}</span>
                </div>
                <div className="text-xl font-black text-zinc-900">{trip.arriveTime}</div>
              </div>
              <div className="text-lg font-black text-[#0F4C43]">KES {trip.price.toLocaleString()}</div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Star size={13} className="text-[#E29548]" fill="currentColor" />
                <span className="text-xs font-semibold text-zinc-600">{trip.rating}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className={`text-xs font-semibold ${trip.seatsAvailable < 10 ? "text-red-500" : "text-zinc-500"}`}>
                  {trip.seatsAvailable} seats left
                </span>
              </div>
            </div>
          </motion.button>
        ))}
      </motion.div>
    </div>
  );
};

// ---- Ticket View ----
const TicketView: React.FC<{
  trip: Trip;
  from: City;
  to: City;
  date: string;
  onReset: () => void;
}> = ({ trip, from, to, date, onReset }) => {
  const reduce = useReducedMotion();
  return (
    <motion.div
      initial={reduce ? undefined : { opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col gap-4"
    >
      <div className="flex items-center gap-3">
        <button onClick={onReset} className="w-9 h-9 rounded-full bg-zinc-100 flex items-center justify-center hover:bg-zinc-200 transition-colors" aria-label="Book another trip">
          <ArrowLeft size={16} className="text-zinc-600" />
        </button>
        <div>
          <div className="text-sm font-bold text-[#0F4C43]">{BRAND.name}</div>
        </div>
      </div>

      <motion.div
        initial={reduce ? undefined : { scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.15, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="bg-white rounded-2xl border border-zinc-200/70 overflow-hidden shadow-lg shadow-zinc-200/50"
      >
        <div className="p-5 pb-4">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Boarding Pass</span>
            <span className="text-[10px] font-bold text-[#E29548] bg-amber-50 px-2.5 py-1 rounded-full">{trip.busType}</span>
          </div>
          <div className="flex items-center justify-between mb-1">
            <div>
              <div className="text-2xl font-black text-zinc-900 tracking-tight">{from.code}</div>
              <div className="text-[11px] text-zinc-500 mt-0.5">{from.name}</div>
            </div>
            <div className="flex flex-col items-center gap-1">
              <div className="text-[10px] font-semibold text-zinc-400">{trip.duration}</div>
              <div className="w-16 h-[2px] bg-zinc-200 rounded-full relative">
                <div className="absolute inset-y-0 left-0 right-0 flex items-center justify-center">
                  <Bus size={14} className="text-[#0F4C43] bg-white px-0.5" />
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-black text-zinc-900 tracking-tight">{to.code}</div>
              <div className="text-[11px] text-zinc-500 mt-0.5">{to.name}</div>
            </div>
          </div>
        </div>

        <div className="relative h-5">
          <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
            <line x1="0" y1="10" x2="100%" y2="10" stroke="#e4e4e7" strokeWidth="1" strokeDasharray="6 4" />
          </svg>
          <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-zinc-100 rounded-full" />
          <div className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-zinc-100 rounded-full" />
        </div>

        <div className="p-5 pt-4">
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div>
              <div className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">Date</div>
              <div className="text-sm font-bold text-zinc-800 mt-1">{date}</div>
            </div>
            <div>
              <div className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">Depart</div>
              <div className="text-sm font-bold text-zinc-800 mt-1">{trip.departTime}</div>
            </div>
            <div>
              <div className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">Arrive</div>
              <div className="text-sm font-bold text-zinc-800 mt-1">{trip.arriveTime}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <div>
              <div className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">Seat</div>
              <div className="text-sm font-bold text-zinc-800 mt-1">14A - Window</div>
            </div>
            <div>
              <div className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">Gate</div>
              <div className="text-sm font-bold text-zinc-800 mt-1">B3</div>
            </div>
          </div>

          <div className="flex justify-center">
            <div className="flex gap-[2px]">
              {Array.from({ length: 40 }).map((_, i) => (
                <div
                  key={i}
                  className="bg-zinc-800 rounded-[1px]"
                  style={{ width: `${Math.random() > 0.35 ? 2 : 3}px`, height: `${28 + Math.random() * 12}px` }}
                />
              ))}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-zinc-100 flex justify-between items-center">
            <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">Paid via M-Pesa</span>
            <span className="text-lg font-black text-[#0F4C43]">KES {trip.price.toLocaleString()}</span>
          </div>
        </div>
      </motion.div>

      <motion.button
        initial={reduce ? undefined : { opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        onClick={onReset}
        className="w-full py-3.5 bg-[#0F4C43] text-white font-bold text-sm rounded-2xl hover:bg-[#0d3f38] active:scale-[0.98] transition-all"
      >
        Book Another Trip
      </motion.button>
    </motion.div>
  );
};

// ---- MAIN SIMULATOR ----
export default function MobileSimulator() {
  const reduce = useReducedMotion();

  const [tripType, setTripType] = useState<TripType>("one-way");
  const [fromCity, setFromCity] = useState<City | null>(null);
  const [toCity, setToCity] = useState<City | null>(null);
  const [departDate, setDepartDate] = useState<Date | null>(null);
  const [returnDate, setReturnDate] = useState<Date | null>(null);

  const [step, setStep] = useState<AppStep>("booking");
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [filteredTrips, setFilteredTrips] = useState<Trip[]>([]);

  const tomorrow = getTomorrow();
  const canSearch = fromCity && toCity && departDate && (tripType === "one-way" || returnDate);

  const handleSearch = () => {
    if (!canSearch) {
      if (!fromCity) toast.error("Please select a departure city");
      else if (!toCity) toast.error("Please select a destination");
      else if (!departDate) toast.error("Please select a travel date");
      else if (tripType === "round-trip" && !returnDate) toast.error("Please select a return date");
      return;
    }
    if (fromCity.id === toCity.id) {
      toast.error("Departure and destination cannot be the same");
      return;
    }
    setStep("searching");
    setTimeout(() => {
      const trips = routes
        .filter(r => r.origin.toLowerCase() === fromCity.name.toLowerCase() && r.destination.toLowerCase() === toCity.name.toLowerCase())
        .map(r => ({
          id: r.id,
          from: r.origin,
          to: r.destination,
          departTime: r.departureTime,
          arriveTime: "Next Day",
          duration: r.duration,
          price: r.price,
          busType: r.busType || "Executive",
          seatsAvailable: r.seatsLeft || 8,
          operator: "Tahmeed Coach",
          rating: r.rating
        })) as Trip[];
      setFilteredTrips(trips);
      setStep("results");
    }, 3200);
  };

  const handleSelectTrip = (trip: Trip) => { setSelectedTrip(trip); setStep("ticket"); };
  const handleReset = () => { setStep("booking"); setSelectedTrip(null); setFilteredTrips([]); };
  const swapCities = () => { setFromCity(toCity); setToCity(fromCity); };
  const ticketDate = departDate ? formatDate(departDate) : "";

  return (
    <div className="flex flex-col h-full bg-[#f5f3f0] rounded-[44px] overflow-hidden border-[5px] border-zinc-800 shadow-2xl shadow-zinc-900/30">
      {/* Notch */}
      <div className="relative flex justify-center pt-2 pb-0 bg-[#f5f3f0]">
        <div className="w-28 h-6 bg-zinc-800 rounded-b-2xl" />
      </div>

      <StatusBar />

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto px-4 pb-6">
        <AnimatePresence mode="wait">
          {step === "booking" && (
            <motion.div
              key="booking"
              initial={reduce ? undefined : { opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={reduce ? undefined : { opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="flex flex-col gap-4 pt-2"
            >
              <div className="text-center mb-1">
                <div className="text-lg font-black text-[#0F4C43] tracking-tight">{BRAND.name}</div>
                <div className="text-[11px] text-zinc-500">Book your next journey</div>
              </div>

              <TripTypeToggle value={tripType} onChange={setTripType} />

              <CityDropdown value={fromCity} onChange={setFromCity} excludeId={toCity?.id} placeholder="From where?" icon={<Bus size={18} />} />

              <div className="flex justify-center -my-2">
                <button
                  type="button"
                  onClick={swapCities}
                  className="w-8 h-8 rounded-full bg-white border border-zinc-200 flex items-center justify-center hover:bg-zinc-50 active:scale-90 transition-all shadow-sm"
                  aria-label="Swap cities"
                >
                  <ArrowRight size={14} className="text-zinc-500 rotate-90" />
                </button>
              </div>

              <CityDropdown value={toCity} onChange={setToCity} excludeId={fromCity?.id} placeholder="Where to?" icon={<MapPin size={18} />} />

              <DateField value={departDate} onChange={setDepartDate} minDate={tomorrow} placeholder="Travel date" />

              <AnimatePresence>
                {tripType === "round-trip" && (
                  <motion.div
                    key="return-date"
                    initial={reduce ? undefined : { height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                    className="overflow-hidden"
                  >
                    <DateField
                      value={returnDate}
                      onChange={setReturnDate}
                      minDate={departDate ? getDayAfter(departDate) : tomorrow}
                      placeholder="Return date"
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              <motion.button
                whileHover={reduce ? undefined : { scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleSearch}
                disabled={!canSearch}
                className={`w-full py-3.5 rounded-2xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                  canSearch ? "bg-[#0F4C43] text-white hover:bg-[#0d3f38] shadow-lg shadow-[#0F4C43]/25" : "bg-zinc-200 text-zinc-400 cursor-not-allowed"
                }`}
              >
                <MagnifyingGlass size={16} />
                Find Buses
              </motion.button>

              <div className="flex items-center gap-3">
                <div className="flex-1 h-[1px] bg-zinc-200" />
                <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-widest">Why Travel With Us</span>
                <div className="flex-1 h-[1px] bg-zinc-200" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                {FEATURES.map((feature, i) => (
                  <FeatureCard key={feature.title} feature={feature} index={i} />
                ))}
              </div>

              <div className="h-4" />
            </motion.div>
          )}

          {step === "searching" && (
            <motion.div
              key="searching"
              initial={reduce ? undefined : { opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={reduce ? undefined : { opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <SearchingView />
            </motion.div>
          )}

          {step === "results" && (
            <motion.div
              key="results"
              initial={reduce ? undefined : { opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={reduce ? undefined : { opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="pt-2"
            >
              <ResultsView trips={filteredTrips} onSelect={handleSelectTrip} onBack={handleReset} fromCity={fromCity!} toCity={toCity!} />
            </motion.div>
          )}

          {step === "ticket" && selectedTrip && fromCity && toCity && (
            <motion.div
              key="ticket"
              initial={reduce ? undefined : { opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={reduce ? undefined : { opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="pt-2"
            >
              <TicketView trip={selectedTrip} from={fromCity} to={toCity} date={ticketDate} onReset={handleReset} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="flex justify-center pb-2 pt-1 bg-[#f5f3f0]">
        <div className="w-32 h-1 bg-zinc-300 rounded-full" />
      </div>
    </div>
  );
}
