import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Loader } from 'lucide-react';
import { cn } from '../lib/utils';
import { stations } from '../data/travelData';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from './ui/command';

interface HeroProps {
  onSearch: (query: string) => void;
}

const StationDropdown: React.FC<{
  value: string;
  onSelect: (val: string) => void;
  placeholder: string;
  label: string;
  icon: React.ReactNode;
}> = ({ value, onSelect, placeholder, label, icon }) => {
  const [open, setOpen] = useState(false);
  const cities = Array.from(new Set(stations.map(s => s.city))).sort();

  return (
    <div className="relative w-full">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            className={cn(
              "w-full h-16 px-4 bg-white border border-[#D1D5DB] rounded-[8px] flex items-center gap-3 transition-all text-left outline-none relative pt-4",
              !value && "text-[#9CA3AF]"
            )}
          >
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6B7280]">
              {icon}
            </div>
            <div className="pl-8 flex flex-col justify-center h-full">
              <span className="text-[12px] text-[#6B7280] absolute top-2 left-12">{label}</span>
              <span className="text-[16px] text-[#111827] font-medium mt-1">{value || placeholder}</span>
            </div>
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-[calc(100vw-32px)] max-w-[568px] p-0 rounded-xl border-[#E5E7EB] shadow-xl z-[100]" align="start">
          <Command>
            <CommandInput placeholder={`Search ${label.toLowerCase()}...`} className="h-12" />
            <CommandList className="max-h-[300px]">
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup>
                {cities.map((city) => (
                  <CommandItem
                    key={city}
                    onSelect={() => {
                      onSelect(city);
                      setOpen(false);
                    }}
                    className="py-3 px-4 cursor-pointer hover:bg-slate-50"
                  >
                    {city}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
};

const Hero: React.FC<HeroProps> = ({ onSearch }) => {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [date, setDate] = useState('');
  const [tripType, setTripType] = useState<'one-way' | 'round-trip'>('one-way');

  const travlerLogo = "https://storage.googleapis.com/dala-prod-public-storage/generated-images/7f901b81-3f15-47f9-8c28-202789f34fc0/travler-logo-03a5323c-1781051307435.webp";

  return (
    <div className="w-full px-1">
      <motion.div 
          className="search-card mb-8"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        >
        {/* Trip Type Toggle */}
        <div className="flex gap-6 mb-4">
          <label 
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => setTripType('one-way')}
          >
            <div 
              className={cn(
                "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all",
                tripType === 'one-way' ? "border-[#111827]" : "border-[#D1D5DB]"
              )}
            >
              {tripType === 'one-way' && <div className="w-2.5 h-2.5 bg-[#111827] rounded-full" />}
            </div>
            <span className="text-[14px] text-[#6B7280]">One Way</span>
          </label>
          <label 
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => setTripType('round-trip')}
          >
            <div 
              className={cn(
                "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all",
                tripType === 'round-trip' ? "border-[#111827]" : "border-[#D1D5DB]"
              )}
            >
              {tripType === 'round-trip' && <div className="w-2.5 h-2.5 bg-[#111827] rounded-full" />}
            </div>
            <span className="text-[14px] text-[#6B7280]">Round Trip</span>
          </label>
        </div>
        
        <div className="mb-4 text-right">
          <span className="text-[14px] font-medium text-[#374151]">Book your next ticket using</span>
          <img src={travlerLogo} alt="Travler" className="h-5 inline-block ml-1 align-middle" />
        </div>

        <div className="space-y-2">
          <StationDropdown 
            label="From"
            value={from}
            onSelect={setFrom}
            placeholder="e.g Mombasa"
            icon={
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
              </svg>
            }
          />
          <StationDropdown 
            label="To"
            value={to}
            onSelect={setTo}
            placeholder="e.g Nairobi"
            icon={
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
              </svg>
            }
          />
          <div className="relative w-full">
            <div className="relative h-16 bg-white border border-[#D1D5DB] rounded-[8px] flex items-center px-4 pt-4">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6B7280]">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                </svg>
              </div>
              <div className="pl-8 flex flex-col justify-center h-full w-full">
                <span className="text-[12px] text-[#6B7280] absolute top-2 left-12">Travel Date</span>
                <input 
                  type="text"
                  value={date || "10 Jun, 2026"}
                  onChange={(e) => setDate(e.target.value)}
                  onFocus={(e) => (e.target.type = "date")}
                  onBlur={(e) => (e.target.type = "text")}
                  className="w-full bg-transparent border-none outline-none text-[16px] text-[#111827] font-medium placeholder-[#111827] mt-1 p-0 h-auto leading-tight"
                  placeholder="10 Jun, 2026"
                />
              </div>
            </div>
          </div>
        </div>

        <motion.button 
          onClick={() => onSearch(`${from} to ${to}`)}
          className="search-btn w-full h-[56px] flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-shadow"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          transition={{ type: "spring", stiffness: 400, damping: 15 }}
        >
          <Search className="w-5 h-5" />
          <span>Search Buses</span>
        </motion.button>
      </motion.div>
    </div>
  );
};

export default Hero;