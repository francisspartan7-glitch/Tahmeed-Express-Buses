import React from 'react';
import { Timer, Star, CheckCircle2, Clock, MapPin } from 'lucide-react';
import { routes, BusRoute } from '../data/travelData';
import { motion } from 'framer-motion';
import { Button } from './ui/button';
import { toast } from 'sonner';

interface PackageListProps {
  limit?: number;
  title?: string;
  onBook?: (route: BusRoute) => void;
  searchQuery?: string;
}

const PackageList: React.FC<PackageListProps> = ({ limit, title = "Bus Routes & Schedules", onBook, searchQuery = "" }) => {
  const filteredRoutes = routes.filter(route => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      route.title.toLowerCase().includes(q) ||
      route.origin.toLowerCase().includes(q) ||
      route.destination.toLowerCase().includes(q)
    );
  });

  const sortedRoutes = [...filteredRoutes].sort((a, b) => a.title.localeCompare(b.title));
  const displayRoutes = limit ? sortedRoutes.slice(0, limit) : sortedRoutes;

  const handleBookClick = (route: BusRoute) => {
    if (onBook) {
      onBook(route);
    } else {
      toast.success(`Redirecting to reservation for ${route.title}...`);
    }
  };

  return (
    <section className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tight">{title}</h2>
          <p className="text-slate-500 mt-2 font-medium">Premium bus services across all major routes with luxury amenities.</p>
        </div>
        {!limit && (
           <div className="text-[10px] font-black text-black bg-slate-100 px-4 py-2 rounded-full border border-slate-200 uppercase tracking-widest">
            {filteredRoutes.length} Active Routes
           </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {displayRoutes.length > 0 ? (
          displayRoutes.map((route, idx) => (
            <motion.div
              key={route.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: Math.min(idx * 0.05, 0.5) }}
              className="bg-white rounded-3xl overflow-hidden shadow-md border border-slate-100 flex flex-col group hover:shadow-xl transition-all duration-300"
            >
              <div className="relative h-56 overflow-hidden transition-all duration-700">
                <img 
                  src={route.image} 
                  alt={route.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 right-4 bg-primary text-white px-3 py-1 rounded-full text-xs font-black shadow-lg uppercase tracking-widest">
                  KES {route.price.toLocaleString()}
                </div>
                <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm px-3 py-1 rounded-lg text-[10px] font-black text-slate-900 flex items-center gap-1 uppercase tracking-widest">
                  <Timer size={12} /> {route.duration}
                </div>
              </div>
              
              <div className="p-6 flex-grow space-y-4">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <h3 className="text-xl font-black text-slate-900 line-clamp-1 uppercase tracking-tight">{route.title}</h3>
                    <div className="flex items-center gap-1 text-slate-400 text-xs font-bold">
                      <MapPin size={12} className="text-black" />
                      <span className="truncate">{route.origin} &rarr; {route.destination}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-black bg-slate-50 px-2 py-1 rounded-lg flex-shrink-0">
                    <Star size={14} fill="currentColor" />
                    <span className="text-xs font-black">{route.rating.toFixed(1)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-6 border-y border-slate-50 py-4">
                  <div className="flex flex-col">
                    <span className="text-[9px] uppercase tracking-[0.2em] text-slate-400 font-black">Departure</span>
                    <div className="flex items-center gap-1.5 text-slate-900 font-black">
                      <Clock size={14} className="text-slate-400" />
                      <span className="text-sm">{route.departureTime}</span>
                    </div>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[9px] uppercase tracking-[0.2em] text-slate-400 font-black">Status</span>
                    <span className="text-slate-900 text-[10px] font-black flex items-center gap-1 uppercase">
                      <span className="w-1.5 h-1.5 bg-black rounded-full animate-pulse" />
                      Available
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  {route.features.slice(0, 4).map((f, i) => (
                    <div key={i} className="flex items-center gap-2 text-[10px] text-slate-500 font-bold uppercase">
                      <CheckCircle2 size={12} className="text-black" />
                      <span className="truncate">{f}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-6 pt-0">
                <Button 
                  onClick={() => handleBookClick(route)}
                  className="w-full bg-primary hover:bg-orange-600 rounded-xl h-12 font-black shadow-md hover:shadow-xl transition-all text-white uppercase tracking-widest text-xs"
                >
                  Reserve Seat
                </Button>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full py-20 text-center bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
            <p className="text-slate-400 font-black uppercase tracking-widest">No routes found matching "{searchQuery}"</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default PackageList;