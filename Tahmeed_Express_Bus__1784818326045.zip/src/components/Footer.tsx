import React from 'react';
import { Facebook, Twitter, Instagram, Mail, ArrowUpRight, MessageCircle, Phone } from 'lucide-react';
import { Button } from './ui/button';
import { TAHMEED_PHONE, TAHMEED_PHONE_2, TAHMEED_EMAIL, TAHMEED_WHATSAPP_PRIMARY } from '../constants';

interface FooterProps {
  setView: (view: any) => void;
}

const Footer: React.FC<FooterProps> = ({ setView }) => {
  const logoUrl = "https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1783081885012_FB_IMG_1783081764091.jpg";
  const supportNumbers = [
    { label: 'Support Line 1', number: TAHMEED_PHONE },
    { label: 'Support Line 2', number: TAHMEED_PHONE_2 },
  ];
  const whatsappLink = `https://wa.me/${TAHMEED_WHATSAPP_PRIMARY}?text=${encodeURIComponent('Hello Tahmeed Express, I would like to make an inquiry...')}`;

  return (
    <footer className="bg-black text-slate-400 pt-24 pb-12 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-16 mb-20">
          <div className="md:col-span-4 space-y-10">
            <div className="flex flex-col items-start gap-6">
              <a 
                href="https://tahmeedexpressbuses.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group hover:opacity-90 transition-opacity"
              >
                <img 
                  src={logoUrl} 
                  alt="Tahmeed Express Logo" 
                  className="h-16 w-auto object-contain brightness-0 invert opacity-80"
                />
              </a>
              <p className="text-base leading-relaxed max-w-sm">
                Tahmeed Express - East Africa's premier luxury travel service. Experience unrivaled comfort, safety, and reliability on every mile.
              </p>
            </div>
            <div className="flex flex-col gap-6">
              <div className="flex gap-5">
                {[Facebook, Twitter, Instagram].map((Icon, i) => (
                  <div key={i} className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 hover:bg-white hover:text-black cursor-pointer transition-all text-white group">
                    <Icon size={20} className="group-hover:scale-110 transition-transform" />
                  </div>
                ))}
              </div>
              <div className="flex flex-col gap-3">
                {supportNumbers.map(({ label, number }) => (
                  <a
                    key={number}
                    href={`tel:${number}`}
                    className="flex items-center gap-3 bg-white/5 text-white px-5 py-3 rounded-2xl border border-white/10 hover:bg-white hover:text-black transition-all group w-fit"
                  >
                    <Phone size={18} />
                    <span className="font-black text-sm tracking-wide">{label}: {number}</span>
                  </a>
                ))}
                <a
                  href={`mailto:${TAHMEED_EMAIL}`}
                  className="flex items-center gap-3 bg-white/5 text-white px-5 py-3 rounded-2xl border border-white/10 hover:bg-white hover:text-black transition-all group w-fit"
                >
                  <Mail size={18} />
                  <span className="font-black text-sm tracking-wide">{TAHMEED_EMAIL}</span>
                </a>
                <a
                  href={whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 bg-emerald-500/10 text-emerald-400 px-6 py-3 rounded-2xl border border-emerald-500/20 hover:bg-emerald-500 hover:text-white transition-all group w-fit"
                >
                  <MessageCircle size={22} />
                  <span className="font-black text-sm tracking-wide">WHATSAPP SUPPORT</span>
                </a>
              </div>
            </div>
          </div>

          <div className="md:col-span-2">
            <h4 className="text-white font-black mb-10 uppercase tracking-[0.2em] text-xs">Experience</h4>
            <ul className="space-y-5 text-sm font-bold">
              <li><button onClick={() => setView('stations')} className="hover:text-white transition-colors flex items-center gap-2 group text-left">Bus Stations <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" /></button></li>
              <li><button onClick={() => setView('routes')} className="hover:text-white transition-colors flex items-center gap-2 group text-left">Our Routes <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" /></button></li>
              <li><button onClick={() => setView('blog')} className="hover:text-white transition-colors flex items-center gap-2 group text-left">Travel Blog <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" /></button></li>
              <li><button onClick={() => setView('bookings')} className="hover:text-white transition-colors flex items-center gap-2 group text-left">Book Ticket <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" /></button></li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <h4 className="text-white font-black mb-10 uppercase tracking-[0.2em] text-xs">Legal</h4>
            <ul className="space-y-5 text-sm font-bold">
              <li><a href="#" className="hover:text-white transition-colors">Safety Protocols</a></li>
              <li><a href="#" className="hover:text-white transition-colors">VIP Lounge Access</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
            </ul>
          </div>

          <div className="md:col-span-4">
            <h4 className="text-white font-black mb-10 uppercase tracking-[0.2em] text-xs">Stay Updated</h4>
            <p className="text-sm mb-8 leading-relaxed">Join our mailing list for exclusive deals and new route announcements across Kenya and beyond.</p>
            <div className="flex gap-3 p-2 bg-white/5 rounded-[1.25rem] border border-white/10 focus-within:border-white/50 transition-all">
              <input 
                type="email" 
                placeholder="your@email.com" 
                className="bg-transparent border-none rounded-lg px-4 py-3 w-full text-white text-sm outline-none placeholder:text-slate-500 font-bold"
              />
              <Button size="sm" className="bg-white hover:bg-slate-200 text-black rounded-xl px-6 font-black">
                <Mail size={20} />
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t border-white/5 pt-12 flex flex-col md:flex-row justify-between items-center gap-8 text-[11px] font-black uppercase tracking-[0.25em] text-slate-500">
          <p className="text-center md:text-left">&copy; {new Date().getFullYear()} TAHMEED EXPRESS GROUP. LUXURY TRAVEL REDEFINED.</p>
          <div className="flex gap-10 font-bold">
            <span>KENYA</span>
            <span className="opacity-30">UGANDA</span>
            <span className="opacity-30">TANZANIA</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;