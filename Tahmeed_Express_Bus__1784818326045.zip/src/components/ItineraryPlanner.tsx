import { Station, PaymentMethod, BusRoute, IMAGES, DEFAULT_PAYMENT_METHODS, PassengerDetail, routes } from '../data/travelData';
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Calendar, Users, Search, ChevronRight, CheckCircle, ArrowRight, Armchair, MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { toast } from 'sonner';
import { StationSelect } from './DestinationList';
import BusSeatSelection from './BusSeatSelection';
import { cn } from '../lib/utils';

interface ItineraryPlannerProps {
  initialRoute?: BusRoute | null;
  onClearRoute?: () => void;
}

const ItineraryPlanner: React.FC<ItineraryPlannerProps> = ({ initialRoute, onClearRoute }) => {
  const [bookingStep, setBookingStep] = useState(1);
  const [from, setFrom] = useState(initialRoute?.origin.toUpperCase() || 'NAIROBI');
  const [to, setTo] = useState(initialRoute?.destination.toUpperCase() || 'MOMBASA');
  const [date, setDate] = useState('2026-04-09');
  const passengers = 1;
  const [tripType, setTripType] = useState<'one-way' | 'round-trip'>('one-way');
  const [selectedRoute, setSelectedRoute] = useState<BusRoute | null>(initialRoute || null);
  const [selectedSeats, setSelectedSeats] = useState<number[]>([]);
  const [passengerDetails, setPassengerDetails] = useState<PassengerDetail[]>([]);
  const [boardingPoint, setBoardingPoint] = useState('');
  const [droppingPoint, setDroppingPoint] = useState('');

  const whatsappNumber = "0751299364";
  const whatsappLink = `https://wa.me/254${whatsappNumber.substring(1)}`;

  const isVipSeat = (seatNum: number) => seatNum <= 12;
  const basePrice = selectedRoute?.price || 0;
  const vipSurcharge = 200;
  const totalPrice = selectedSeats.reduce((sum, seat) => sum + basePrice + (isVipSeat(seat) ? vipSurcharge : 0), 0);

  useEffect(() => {
    if (initialRoute) {
      setSelectedRoute(initialRoute);
      setFrom(initialRoute.origin.toUpperCase());
      setTo(initialRoute.destination.toUpperCase());
      setBookingStep(3);
    }
  }, [initialRoute]);

  useEffect(() => {
    const newDetails = selectedSeats.map((seat) => {
      const existing = passengerDetails.find(p => p.seatNumber === seat);
      return existing || { name: '', phone: '', idNumber: '', seatNumber: seat };
    });
    setPassengerDetails(newDetails);
  }, [selectedSeats]);

  const handleSearch = () => {
    const filteredResults = routes.filter(r => 
      (r.origin.toUpperCase().includes(from) || from.includes(r.origin.toUpperCase())) && 
      (r.destination.toUpperCase().includes(to) || to.includes(r.destination.toUpperCase()))
    );

    if (filteredResults.length === 1) {
      setSelectedRoute(filteredResults[0]);
      setBookingStep(3);
    } else {
      setBookingStep(2);
    }
  };

  const handleRouteSelect = (route: BusRoute) => {
    setSelectedRoute(route);
    setBookingStep(3);
  };

  const handleSeatToggle = (seatNumber: number) => {
    if (selectedSeats.includes(seatNumber)) {
      setSelectedSeats(selectedSeats.filter(s => s !== seatNumber));
    } else {
      setSelectedSeats([...selectedSeats, seatNumber]);
    }
  };

  const handlePassengerSubmit = () => {
    const isAnyEmpty = passengerDetails.some(p => !p.name || !p.phone || !p.idNumber);
    if (isAnyEmpty) {
      toast.error('Please fill in all traveler details');
      return;
    }

    if (!boardingPoint || !droppingPoint) {
      toast.error('Please specify boarding and dropping points');
      return;
    }

    const phoneRegex = /^(07|01|254|(\+254))\d{8,10}$/;
    const invalidPhone = passengerDetails.find(p => !phoneRegex.test(p.phone.replace(/\s/g, '')));
    if (invalidPhone) {
      toast.error(`Invalid phone number for ${invalidPhone.name || 'passenger'}`);
      return;
    }

    const passengerNames = passengerDetails.map(p => p.name).join(', ');
    const seatList = selectedSeats.sort((a, b) => a - b).map(s => `${s}${isVipSeat(s) ? ' (VIP)' : ''}`).join(', ');
    
    const message = `Hello Tahmeed Express! 👋

I would like to complete my booking:

🚌 *Route:* ${from} to ${to}
📍 *Boarding:* ${boardingPoint}
📍 *Dropping:* ${droppingPoint}
📅 *Date:* ${date}
👥 *Passengers:* ${selectedSeats.length} (${passengerNames})
💺 *Seats:* ${seatList}
💰 *Total Amount:* KES ${totalPrice.toLocaleString()}

Please provide payment instructions to confirm my ticket.`;
    
    const encodedMessage = encodeURIComponent(message);
    const finalWhatsappLink = `https://wa.me/254${whatsappNumber.substring(1)}?text=${encodedMessage}`;
    
    toast.success('Redirecting to WhatsApp for payment...');
    window.open(finalWhatsappLink, '_blank');
    setBookingStep(6);
  };

  const updatePassenger = (index: number, field: keyof PassengerDetail, value: string) => {
    const updated = [...passengerDetails];
    updated[index] = { ...updated[index], [field]: value };
    setPassengerDetails(updated);
  };

  const steps = [
    { id: 1, label: 'Search' },
    { id: 2, label: 'Route' },
    { id: 3, label: 'Booking' },
    { id: 6, label: 'Success' }
  ];

  const BookingContextBar = () => (
    <motion.div 
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white/95 backdrop-blur-md border border-slate-200 rounded-full py-1 px-4 mb-4 flex items-center justify-between shadow-sm max-w-4xl w-full mx-auto h-8"
    >
      <div className="flex items-center gap-2 text-[9px] font-black text-slate-900 uppercase tracking-widest overflow-hidden whitespace-nowrap">
        <span className="text-black truncate">{from}</span>
        <span className="text-slate-300">-</span>
        <span className="text-black truncate">{to}</span>
        <span className="text-slate-300">-</span>
        <span className="text-black truncate">{date}</span>
      </div>
      <Button 
        variant="ghost" 
        size="sm" 
        onClick={() => { setBookingStep(1); onClearRoute?.(); }}
        className="h-5 px-2 text-[8px] font-black uppercase text-black hover:bg-slate-50 rounded-full flex items-center gap-1 shrink-0"
      >
        <Search size={10} /> Modify
      </Button>
    </motion.div>
  );

  return (
    <div className="relative min-h-[90vh] flex flex-col items-center justify-start pt-6 pb-16 bg-white">
      <div className="fixed inset-0 z-0 pointer-events-none opacity-10">
        <img 
          src={IMAGES.INTERIOR} 
          alt="Bus Interior" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-white/80" />
      </div>

      <div className="relative z-10 w-full max-w-6xl px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-5xl font-black text-black tracking-tighter flex items-center justify-center gap-3 mb-2 uppercase">
            Book <span className="text-slate-200"><ArrowRight size={28} strokeWidth={4} /></span> 
            Chat <span className="text-slate-200"><ArrowRight size={28} strokeWidth={4} /></span> 
            Travel
          </h1>
          <p className="text-slate-400 text-base md:text-lg font-black uppercase tracking-[0.3em] italic opacity-80">
            The Platinum Standard in Road Travel
          </p>
        </div>

        <div className="flex items-center justify-center mb-10 gap-2 md:gap-4">
          {steps.map((step, idx) => (
            <React.Fragment key={step.id}>
              <div className="flex flex-col items-center gap-2">
                <div 
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-xs transition-all ${
                    bookingStep >= step.id 
                      ? 'bg-primary text-white shadow-xl' 
                      : 'bg-white text-slate-300 border-2 border-slate-100'
                  }`}
                >
                  {bookingStep > step.id ? <CheckCircle size={18} /> : step.id}
                </div>
                <span className={`text-[8px] font-black uppercase tracking-[0.2em] ${bookingStep >= step.id ? 'text-black' : 'text-slate-300'}`}>
                  {step.label}
                </span>
              </div>
              {idx < steps.length - 1 && (
                <div className={`h-0.5 w-6 md:w-12 rounded-full mb-6 ${bookingStep > step.id ? 'bg-primary' : 'bg-slate-100'}`} />
              )}
            </React.Fragment>
          ))}
        </div>

        {bookingStep > 1 && bookingStep < 6 && <BookingContextBar />}

        <AnimatePresence mode="wait">
          {bookingStep === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full max-w-5xl mx-auto"
            >
              <div className="relative overflow-hidden rounded-[2.5rem] shadow-2xl border border-slate-200 p-1.5 bg-white">
                <div className="bg-white rounded-[2.25rem] p-6 md:p-10 space-y-8">
                  <div className="flex gap-4 mb-2">
                    <button 
                      onClick={() => setTripType('one-way')}
                      className={cn(
                        "px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all",
                        tripType === 'one-way' ? "bg-primary text-white shadow-lg" : "bg-slate-50 text-slate-400 hover:bg-slate-100"
                      )}
                    >
                      ONE WAY
                    </button>
                    <button 
                      onClick={() => setTripType('round-trip')}
                      className={cn(
                        "px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all",
                        tripType === 'round-trip' ? "bg-primary text-white shadow-lg" : "bg-slate-50 text-slate-400 hover:bg-slate-100"
                      )}
                    >
                      ROUND TRIP
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-end">
                    <StationSelect 
                      label="FROM"
                      value={from}
                      onSelect={(val) => setFrom(val.toUpperCase())}
                      placeholder="eg Nairobi"
                      className="lg:col-span-1"
                    />

                    <StationSelect 
                      label="TO"
                      value={to}
                      onSelect={(val) => setTo(val.toUpperCase())}
                      placeholder="eg Mombasa"
                      className="lg:col-span-1"
                    />

                    <div className="space-y-2 lg:col-span-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1 ml-1">
                        <Calendar size={12} /> DEPARTURE
                      </label>
                      <div className="relative">
                        <input
                          type="date"
                          value={date}
                          onChange={(e) => setDate(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 font-black text-slate-900 text-sm focus:ring-2 focus:ring-black transition-all h-[60px] cursor-pointer"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mt-10 flex justify-center">
                    <Button 
                      onClick={handleSearch}
                      className="bg-primary hover:bg-orange-600 text-white font-black text-xl py-8 px-14 rounded-[2rem] transform transition flex items-center gap-4 uppercase tracking-[0.2em] shadow-2xl h-[72px] w-full"
                    >
                      <Search size={24} /> SEARCH BUSES
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {bookingStep === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full max-w-4xl mx-auto"
            >
              <div className="space-y-6">
                <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Select Departure</h2>
                
                <div className="grid grid-cols-1 gap-4">
                {routes.filter(r => 
                  (r.origin.toUpperCase().includes(from) || from.includes(r.origin.toUpperCase())) && 
                  (r.destination.toUpperCase().includes(to) || to.includes(r.destination.toUpperCase()))
                ).map((route) => (
                  <Card key={route.id} className="p-5 overflow-hidden rounded-3xl border border-slate-100 shadow-md hover:shadow-xl transition-all bg-white group">
                    <div className="flex flex-col md:flex-row gap-6">
                      <div className="md:w-1/4 relative h-40 md:h-auto rounded-2xl overflow-hidden transition-all duration-700">
                        <img src={route.image} alt={route.title} className="w-full h-full object-cover" />
                      </div>
                      <div className="md:w-3/4 flex flex-col justify-between py-2">
                        <div>
                          <div className="flex justify-between items-start mb-2">
                            <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tighter">{route.title}</h3>
                            <div className="text-primary font-black text-2xl">KES {route.price.toLocaleString()}</div>
                          </div>
                          <div className="flex flex-wrap gap-4 text-slate-400 font-black text-[10px] uppercase tracking-widest">
                            <div className="flex items-center gap-1.5"><Calendar size={12} /> {date}</div>
                            <div className="flex items-center gap-1.5"><Users size={12} /> {passengers} Available</div>
                          </div>
                        </div>
                        <Button 
                          onClick={() => handleRouteSelect(route)}
                          className="w-full mt-6 bg-primary hover:bg-orange-600 text-white font-black py-5 rounded-2xl flex items-center justify-center gap-3 uppercase tracking-widest text-xs shadow-lg"
                        >
                          SELECT SEATS <ChevronRight size={18} />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
                </div>
              </div>
            </motion.div>
          )}

          {bookingStep === 3 && selectedRoute && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                <div className="lg:col-span-7 space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="p-4 bg-primary text-white rounded-2xl">
                      <Armchair size={28} />
                    </div>
                    <div>
                      <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight">1. Select Your Seats</h2>
                      <p className="text-slate-400 font-black text-[10px] uppercase tracking-[0.2em]">{selectedRoute.busType || 'Platinum'} Executive Class</p>
                    </div>
                  </div>
                  <BusSeatSelection 
                    totalSeats={selectedRoute.totalSeats || 49}
                    occupiedSeats={selectedRoute.occupiedSeats || []}
                    selectedSeats={selectedSeats}
                    onSeatToggle={handleSeatToggle}
                    basePrice={basePrice}
                    vipSurcharge={vipSurcharge}
                    isVipSeat={isVipSeat}
                    busClass={selectedRoute.busType || 'Platinum'}
                    departureTime={selectedRoute.departureTime}
                    arrivalTime={selectedRoute.departureTime}
                    from={selectedRoute.origin.toUpperCase()}
                    to={selectedRoute.destination.toUpperCase()}
                    onPassengersComplete={() => {}}
                    onBack={() => {}}
                  />
                </div>

                <div className="lg:col-span-5 space-y-8 lg:sticky lg:top-24">
                   <div className="flex items-center gap-4">
                    <div className="p-4 bg-primary text-white rounded-2xl">
                      <Users size={28} />
                    </div>
                    <div>
                      <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight">2. Traveler Details</h2>
                      <p className="text-slate-400 font-black text-[10px] uppercase tracking-[0.2em]">
                        {selectedSeats.length > 0 
                          ? `Registering ${selectedSeats.length} passenger(s)`
                          : 'Select a seat on the map'}
                      </p>
                    </div>
                  </div>

                  <AnimatePresence mode="wait">
                    {selectedSeats.length === 0 ? (
                      <motion.div
                        key="no-seats"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-[3rem] p-16 text-center"
                      >
                        <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm text-slate-200">
                           <Armchair size={40} />
                        </div>
                        <p className="text-slate-400 font-black text-xs uppercase tracking-[0.3em] leading-loose">
                          Please select your <br /> seats to proceed
                        </p>
                      </motion.div>
                    ) : (
                      <motion.div
                        key="with-seats"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                      >
                        <div className="grid grid-cols-1 gap-4">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1 ml-1">
                              <MapPin size={12} /> Boarding Station
                            </label>
                            <input
                              type="text"
                              placeholder="e.g. Nairobi Terminal"
                              value={boardingPoint}
                              onChange={(e) => setBoardingPoint(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 font-black text-slate-900 text-sm focus:ring-2 focus:ring-black transition-all"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1 ml-1">
                              <MapPin size={12} /> Destination Terminal
                            </label>
                            <input
                              type="text"
                              placeholder="e.g. Mombasa Main Station"
                              value={droppingPoint}
                              onChange={(e) => setDroppingPoint(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 font-black text-slate-900 text-sm focus:ring-2 focus:ring-black transition-all"
                            />
                          </div>
                        </div>

                        <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                          {passengerDetails.map((passenger, idx) => (
                            <Card key={idx} className="p-5 rounded-3xl border border-slate-100 bg-white shadow-sm">
                              <div className="flex justify-between items-center mb-5">
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-lg bg-primary text-white flex items-center justify-center text-[10px] font-black uppercase">
                                    P{idx + 1}
                                  </div>
                                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Seat {passenger.seatNumber}</h3>
                                </div>
                              </div>

                              <div className="grid grid-cols-1 gap-4">
                                <input
                                  type="text"
                                  placeholder="Full Name"
                                  value={passenger.name}
                                  onChange={(e) => updatePassenger(idx, 'name', e.target.value)}
                                  className="w-full bg-slate-50 border border-slate-100 rounded-xl p-3 font-bold text-slate-900 text-xs"
                                />
                                <div className="grid grid-cols-2 gap-3">
                                  <input
                                    type="tel"
                                    placeholder="Phone (07...)"
                                    value={passenger.phone}
                                    onChange={(e) => updatePassenger(idx, 'phone', e.target.value)}
                                    className="w-full bg-slate-50 border border-slate-100 rounded-xl p-3 font-bold text-slate-900 text-xs"
                                  />
                                  <input
                                    type="text"
                                    placeholder="ID Number"
                                    value={passenger.idNumber}
                                    onChange={(e) => updatePassenger(idx, 'idNumber', e.target.value)}
                                    className="w-full bg-slate-50 border border-slate-100 rounded-xl p-3 font-bold text-slate-900 text-xs"
                                  />
                                </div>
                              </div>
                            </Card>
                          ))}
                        </div>

                        <Card className="p-8 rounded-[2.5rem] border-2 border-primary bg-white shadow-2xl relative overflow-hidden">
                          <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-bl-[100px] pointer-events-none" />
                          
                          <div className="flex justify-between items-end mb-8">
                             <div>
                               <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Total Payable</p>
                               <p className="text-4xl font-black text-primary tracking-tighter">KES {totalPrice.toLocaleString()}</p>
                             </div>
                             <div className="text-right">
                               <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Seats</p>
                               <p className="text-sm font-black text-primary">{selectedSeats.sort((a,b)=>a-b).join(', ')}</p>
                             </div>
                          </div>

                          <Button 
                            onClick={handlePassengerSubmit}
                            className="w-full group bg-primary hover:bg-orange-600 text-white font-black py-6 rounded-2xl flex items-center justify-center gap-4 uppercase tracking-[0.2em] text-xs transition-all shadow-xl"
                          >
                            NEXT: CONFIRM ON WHATSAPP <MessageCircle size={18} />
                          </Button>
                        </Card>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          )}

          {bookingStep === 6 && selectedRoute && (
            <motion.div
              key="step6"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center px-4 max-w-3xl mx-auto"
            >
              <div className="relative mb-10">
                <div className="w-32 h-32 bg-slate-50 rounded-full flex items-center justify-center mx-auto shadow-inner border border-slate-100">
                  <CheckCircle size={80} className="text-primary opacity-90" />
                </div>
              </div>

              <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-6 tracking-tighter uppercase">Booking Request Sent!</h2>
              <p className="text-slate-500 text-lg font-bold mb-10 leading-relaxed uppercase tracking-widest">
                Safe travels, <span className="text-black">{passengerDetails[0]?.name || 'Traveler'}</span>! 
                Your request for <span className="text-black">{selectedRoute.title}</span> has been processed. 
                Please finalize your payment on WhatsApp to confirm your seats: <span className="text-black">{selectedSeats.join(', ')}</span>.
              </p>

              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button 
                  onClick={() => { setBookingStep(1); onClearRoute?.(); setSelectedRoute(null); setSelectedSeats([]); setPassengerDetails([]); }}
                  className="bg-slate-100 hover:bg-slate-200 text-primary font-black px-10 py-6 rounded-2xl shadow-sm text-sm uppercase tracking-widest"
                >
                  BOOK ANOTHER TRIP
                </Button>
                
                <Button 
                  asChild
                  className="bg-primary hover:bg-orange-600 text-white font-black px-10 py-6 rounded-2xl shadow-2xl text-sm flex items-center gap-3 uppercase tracking-widest"
                >
                  <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                    <MessageCircle size={22} /> OPEN WHATSAPP
                  </a>
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="mt-auto pt-16 flex flex-wrap justify-center gap-10 opacity-60 pb-8">
        <div className="flex items-center gap-3 font-black text-[10px] uppercase tracking-[0.3em] text-slate-400">
          <div className="w-2 h-2 rounded-full bg-black shadow-sm" /> WhatsApp Support
        </div>
        <div className="flex items-center gap-3 font-black text-[10px] uppercase tracking-[0.3em] text-slate-400">
          <div className="w-2 h-2 rounded-full bg-black shadow-sm" /> Roadside Assistance
        </div>
        <div className="flex items-center gap-3 font-black text-[10px] uppercase tracking-[0.3em] text-slate-400">
          <div className="w-2 h-2 rounded-full bg-black shadow-sm" /> Platinum Safety
        </div>
      </div>
    </div>
  );
};

export default ItineraryPlanner;
