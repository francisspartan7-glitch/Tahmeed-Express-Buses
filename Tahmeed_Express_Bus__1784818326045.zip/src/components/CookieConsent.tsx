import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Info, X } from 'lucide-react';
import { Button } from './ui/button';

const CookieConsent = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('tahmeed-cookie-consent');
    if (!consent) {
      setShow(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('tahmeed-cookie-consent', 'true');
    setShow(false);
  };

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-0 left-0 right-0 z-[100] p-4 md:p-6"
        >
          <div className="max-w-4xl mx-auto bg-black text-white p-6 rounded-3xl shadow-2xl border border-slate-800 flex flex-col md:flex-row items-center gap-6 justify-between">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-white/10 text-white rounded-2xl shrink-0 hidden sm:block">
                <Info size={24} />
              </div>
              <div>
                <h4 className="text-lg font-black uppercase tracking-wider mb-1">Cookie Notice</h4>
                <p className="text-sm text-slate-400 leading-relaxed font-bold">
                  We use cookies to improve your booking experience and provide secure travel transactions. By continuing to use our site, you agree to our use of cookies.
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 w-full md:w-auto">
              <Button 
                onClick={handleAccept}
                className="flex-1 md:flex-none bg-white text-black hover:bg-slate-200 font-black uppercase tracking-widest px-8 h-12 rounded-2xl shadow-lg"
              >
                Accept
              </Button>
              <button 
                onClick={() => setShow(false)}
                className="p-3 text-slate-500 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CookieConsent;