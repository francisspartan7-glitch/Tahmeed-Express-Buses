import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, User, Phone, CreditCard, Check, X, MapPin, ChevronDown, ExternalLink, Shield, Lock } from 'lucide-react';
import { PAYSTACK } from '@/constants';

export interface PassengerInfo {
  name: string;
  phone: string;
  idNumber: string;
}

export interface StopSelection {
  boardingPoint: string;
  dropOffPoint: string;
}

export interface SeatData {
  num: number;
  status: 'available' | 'occupied' | 'selected';
  class: 'vip' | 'business' | 'normal';
}

type Step = 'seats' | 'form';

interface BusSeatSelectionProps {
  totalSeats?: number;
  occupiedSeats?: number[];
  selectedSeats: number[];
  onSeatToggle: (seatNum: number) => void;
  basePrice: number;
  vipSurcharge?: number;
  isVipSeat: (seatNum: number) => boolean;
  busClass: string;
  departureTime: string;
  arrivalTime: string;
  from: string;
  to: string;
  boardingPoints?: string[];
  dropOffPoints?: string[];
  onPassengersComplete: (passengers: PassengerInfo[]) => void;
  onBack: () => void;
}

export default function BusSeatSelection({
  totalSeats = 44,
  occupiedSeats = [],
  selectedSeats,
  onSeatToggle,
  basePrice,
  vipSurcharge = 0,
  isVipSeat,
  busClass,
  departureTime,
  arrivalTime,
  from,
  to,
  boardingPoints = [],
  dropOffPoints = [],
  onPassengersComplete,
  onBack,
}: BusSeatSelectionProps) {
  const [step, setStep] = useState<Step>('seats');
  const [passengers, setPassengers] = useState<PassengerInfo[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [stopSelection, setStopSelection] = useState<StopSelection>({ boardingPoint: '', dropOffPoint: '' });

  const rows = Math.ceil(totalSeats / 4);

  const getSeatData = useCallback(
    (seatNum: number): SeatData => {
      if (occupiedSeats.includes(seatNum)) return { num: seatNum, status: 'occupied', class: 'normal' };
      if (selectedSeats.includes(seatNum)) {
        return { num: seatNum, status: 'selected', class: isVipSeat(seatNum) ? 'vip' : seatNum <= 16 ? 'business' : 'normal' };
      }
      return {
        num: seatNum,
        status: 'available',
        class: isVipSeat(seatNum) ? 'vip' : seatNum <= 16 ? 'business' : 'normal',
      };
    },
    [occupiedSeats, selectedSeats, isVipSeat]
  );

  const getClassLabel = (cls: string) => {
    switch (cls) {
      case 'vip': return 'VIP';
      case 'business': return 'Business';
      default: return 'Normal';
    }
  };

  const getSeatColor = (seat: SeatData) => {
    if (seat.status === 'occupied') return 'bg-gray-200 text-gray-400 cursor-not-allowed';
    if (seat.status === 'selected') {
      if (seat.class === 'vip') return 'bg-amber-500 text-white shadow-md shadow-amber-500/30';
      if (seat.class === 'business') return 'bg-emerald-500 text-white shadow-md shadow-emerald-500/30';
      return 'bg-blue-500 text-white shadow-md shadow-blue-500/30';
    }
    if (seat.class === 'vip') return 'bg-amber-50 border-2 border-amber-300 text-amber-700 hover:bg-amber-100 hover:border-amber-400 cursor-pointer';
    if (seat.class === 'business') return 'bg-emerald-50 border-2 border-emerald-300 text-emerald-700 hover:bg-emerald-100 hover:border-emerald-400 cursor-pointer';
    return 'bg-blue-50 border-2 border-blue-200 text-blue-700 hover:bg-blue-100 hover:border-blue-300 cursor-pointer';
  };

  const getPriceForSeat = (seatNum: number) => isVipSeat(seatNum) ? basePrice + vipSurcharge : basePrice;
  const totalPrice = selectedSeats.reduce((sum, s) => sum + getPriceForSeat(s), 0);

  const handleContinueToForm = () => {
    const existing = [...passengers];
    while (existing.length < selectedSeats.length) {
      existing.push({ name: '', phone: '', idNumber: '' });
    }
    const trimmed = existing.slice(0, selectedSeats.length);
    setPassengers(trimmed);
    setErrors({});
    setStep('form');
  };

  const handlePassengerChange = (index: number, field: keyof PassengerInfo, value: string) => {
    const updated = [...passengers];
    updated[index] = { ...updated[index], [field]: value };
    setPassengers(updated);
    const key = `${index}-${field}`;
    if (errors[key]) {
      const next = { ...errors };
      delete next[key];
      setErrors(next);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    passengers.forEach((p, i) => {
      if (!p.name.trim()) newErrors[`${i}-name`] = 'Name is required';
      if (!p.phone.trim()) newErrors[`${i}-phone`] = 'Phone is required';
      else if (!/^(07|01)\d{8}$/.test(p.phone.trim())) newErrors[`${i}-phone`] = 'Enter valid Safaricom number (07XX XXX XXX)';
      if (!p.idNumber.trim()) newErrors[`${i}-idNumber`] = 'ID/Passport is required';
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmitForm = () => {
    if (validateForm()) onPassengersComplete(passengers);
  };

  const handleBackToSeats = () => {
    setStep('seats');
    setErrors({});
  };

  return (
    <AnimatePresence mode="wait">
      {step === 'seats' ? (
        <motion.div key="seats" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}>
          <div className="flex flex-wrap items-center gap-3 mb-5 text-[11px] font-medium">
            <div className="flex items-center gap-1.5"><div className="w-5 h-5 rounded-md bg-amber-50 border-2 border-amber-300" /><span className="text-amber-700">VIP</span></div>
            <div className="flex items-center gap-1.5"><div className="w-5 h-5 rounded-md bg-emerald-50 border-2 border-emerald-300" /><span className="text-emerald-700">Business</span></div>
            <div className="flex items-center gap-1.5"><div className="w-5 h-5 rounded-md bg-blue-50 border-2 border-blue-200" /><span className="text-blue-700">Normal</span></div>
            <div className="flex items-center gap-1.5"><div className="w-5 h-5 rounded-md bg-gray-200" /><span className="text-gray-500">Booked</span></div>
            <div className="flex items-center gap-1.5"><div className="w-5 h-5 rounded-md bg-[#f97316] shadow-md shadow-orange-500/30" /><span className="text-[#f97316]">Selected</span></div>
          </div>
          <div className="bg-gray-50 rounded-2xl border border-gray-200 p-4 pb-6">
            <div className="flex items-center justify-between mb-4 px-2">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full border-3 border-gray-300 flex items-center justify-center bg-white"><div className="w-2 h-2 rounded-full bg-gray-400" /></div>
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Driver</span>
              </div>
              <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider">Front</div>
            </div>
            <div className="flex flex-col gap-1.5">
              {Array.from({ length: rows }, (_, rowIdx) => {
                const leftA = rowIdx * 4 + 1;
                const leftB = rowIdx * 4 + 2;
                const rightC = rowIdx * 4 + 3;
                const rightD = rowIdx * 4 + 4;
                return (
                  <div key={rowIdx} className="flex items-center justify-center gap-1">
                    <div className="flex gap-1">
                      {[leftA, leftB].map((seatNum) => {
                        if (seatNum > totalSeats) return <div key={seatNum} className="w-9 h-9" />;
                        const seat = getSeatData(seatNum);
                        return (
                          <motion.button key={seatNum} whileTap={seat.status !== 'occupied' ? { scale: 0.9 } : undefined} onClick={() => seat.status !== 'occupied' && onSeatToggle(seatNum)} disabled={seat.status === 'occupied'} className={`w-9 h-9 rounded-lg text-[10px] font-bold flex items-center justify-center transition-colors ${getSeatColor(seat)}`} title={`Seat ${seatNum} - ${getClassLabel(seat.class)}${seat.status === 'occupied' ? ' (Booked)' : ''}`}>{seatNum}</motion.button>
                        );
                      })}
                    </div>
                    <div className="w-4 flex items-center justify-center"><div className="w-full h-px bg-gray-200" /></div>
                    <div className="flex gap-1">
                      {[rightC, rightD].map((seatNum) => {
                        if (seatNum > totalSeats) return <div key={seatNum} className="w-9 h-9" />;
                        const seat = getSeatData(seatNum);
                        return (
                          <motion.button key={seatNum} whileTap={seat.status !== 'occupied' ? { scale: 0.9 } : undefined} onClick={() => seat.status !== 'occupied' && onSeatToggle(seatNum)} disabled={seat.status === 'occupied'} className={`w-9 h-9 rounded-lg text-[10px] font-bold flex items-center justify-center transition-colors ${getSeatColor(seat)}`} title={`Seat ${seatNum} - ${getClassLabel(seat.class)}${seat.status === 'occupied' ? ' (Booked)' : ''}`}>{seatNum}</motion.button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex justify-center mt-4">
              <div className="flex items-center gap-2 text-[10px] text-gray-400 font-semibold uppercase tracking-wider">
                <div className="w-8 h-1 bg-gray-300 rounded" />Exit<div className="w-8 h-1 bg-gray-300 rounded" />
              </div>
            </div>
            <div className="text-center mt-1.5 text-[10px] font-semibold text-gray-400 uppercase tracking-wider">Rear</div>
          </div>

          {/* Boarding & Drop-off Sections — below seat map */}
          <div className="mt-5 flex flex-col gap-4">
            {/* Boarding Point Selection */}
            <div className="bg-white rounded-xl border border-gray-200 p-4 tahmeed-card">
              <div className="location-label mb-3">
                <span className="icon"><MapPin className="w-4 h-4 text-emerald-600" /></span>
                <span>Boarding Point</span>
              </div>
              <p className="text-[11px] text-gray-500 mb-3">Where will you board in {from}?</p>
              <div className="boarding-dropdown relative">
                <select
                  value={stopSelection.boardingPoint}
                  onChange={(e) => setStopSelection(prev => ({ ...prev, boardingPoint: e.target.value }))}
                  className="appearance-none cursor-pointer"
                >
                  <option value="">Not specified (select later)</option>
                  {boardingPoints.map((point) => (
                    <option key={point} value={point}>{point}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
              {boardingPoints.length === 0 && (
                <div className="text-center py-2 text-gray-400 text-[13px]">No boarding points available</div>
              )}
            </div>

            {/* Drop-off Point Selection */}
            <div className="bg-white rounded-xl border border-gray-200 p-4 tahmeed-card">
              <div className="location-label mb-3">
                <span className="icon"><MapPin className="w-4 h-4 text-orange-600" /></span>
                <span>Drop-off Point</span>
              </div>
              <p className="text-[11px] text-gray-500 mb-3">Where will you alight in {to}?</p>
              <div className="dropping-dropdown relative">
                <select
                  value={stopSelection.dropOffPoint}
                  onChange={(e) => setStopSelection(prev => ({ ...prev, dropOffPoint: e.target.value }))}
                  className="appearance-none cursor-pointer"
                >
                  <option value="">Not specified (select later)</option>
                  {dropOffPoints.map((point) => (
                    <option key={point} value={point}>{point}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
              {dropOffPoints.length === 0 && (
                <div className="text-center py-2 text-gray-400 text-[13px]">No drop-off points available</div>
              )}
            </div>
          </div>

          {selectedSeats.length > 0 && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }} className="mt-5 bg-white border border-gray-200 rounded-2xl p-4 shadow-sm">
              <div className="flex flex-wrap gap-2 mb-3">
                {selectedSeats.sort((a, b) => a - b).map((seatNum) => (
                  <span key={seatNum} className="inline-flex items-center gap-1.5 bg-orange-50 text-[#f97316] text-[12px] font-semibold px-2.5 py-1 rounded-full">
                    Seat {seatNum}
                    {isVipSeat(seatNum) && (<span className="text-[10px] bg-amber-500 text-white px-1.5 py-0.5 rounded-full font-bold">VIP</span>)}
                  </span>
                ))}
              </div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="text-[12px] text-gray-500 font-medium">{selectedSeats.length} seat{selectedSeats.length > 1 ? 's' : ''} selected</div>
                  <div className="text-[20px] font-extrabold text-[#f97316]">KSh {totalPrice.toLocaleString()}</div>
                </div>
              </div>
              <motion.button
                onClick={handleContinueToForm}
                className="complete-booking-btn w-full py-3 text-[15px] font-bold transition-all bg-[#FFD54F] text-[#1a1a1a] shadow-lg shadow-[#FFD54F]/30 hover:shadow-xl hover:shadow-[#FFD54F]/40"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: "spring", stiffness: 400, damping: 15 }}
              >
                Complete Booking
              </motion.button>
            </motion.div>
          )}
        </motion.div>
      ) : (
        <motion.div key="form" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}>
          <motion.button onClick={handleBackToSeats} className="flex items-center gap-1.5 text-[13px] font-medium text-gray-500 hover:text-gray-800 mb-4 transition-colors" whileHover={{ x: -3 }} whileTap={{ scale: 0.95 }} transition={{ type: "spring", stiffness: 400, damping: 15 }}>
            <ArrowLeft className="w-4 h-4" />Back to seat selection
          </motion.button>
          <h2 className="text-[17px] font-extrabold text-gray-900 mb-1">Passenger Details</h2>
          <p className="text-[13px] text-gray-500 mb-5">Fill in details for each selected seat</p>
          <div className="flex flex-col gap-5">
            {selectedSeats.sort((a, b) => a - b).map((seatNum, idx) => (
              <div key={seatNum} className="bg-gray-50 rounded-xl border border-gray-200 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <span className="bg-[#f97316] text-white text-[11px] font-bold px-2.5 py-1 rounded-full">Seat {seatNum}</span>
                  {isVipSeat(seatNum) && (<span className="bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">VIP</span>)}
                  <span className="text-[12px] text-gray-400">KSh {getPriceForSeat(seatNum).toLocaleString()}</span>
                </div>
                <div className="flex flex-col gap-3">
                  <div>
                    <label className="block text-[12px] font-semibold text-gray-700 mb-1">Full Name <span className="text-red-500">*</span></label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input type="text" value={passengers[idx]?.name || ''} onChange={(e) => handlePassengerChange(idx, 'name', e.target.value)} placeholder="e.g. John Mwangi" className={`w-full pl-9 pr-3 py-2.5 rounded-lg border text-[13px] bg-white focus:outline-none focus:ring-2 transition-all ${errors[`${idx}-name`] ? 'border-red-400 focus:ring-red-200' : 'border-gray-200 focus:ring-orange-500/20 focus:border-[#f97316]'}`} />
                    </div>
                    {errors[`${idx}-name`] && (<p className="mt-1 text-[11px] text-red-500 flex items-center gap-1"><X className="w-3 h-3" /> {errors[`${idx}-name`]}</p>)}
                  </div>
                  <div>
                    <label className="block text-[12px] font-semibold text-gray-700 mb-1">Phone Number <span className="text-red-500">*</span></label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input type="tel" value={passengers[idx]?.phone || ''} onChange={(e) => handlePassengerChange(idx, 'phone', e.target.value)} placeholder="e.g. 0712 345 678" className={`w-full pl-9 pr-3 py-2.5 rounded-lg border text-[13px] bg-white focus:outline-none focus:ring-2 transition-all ${errors[`${idx}-phone`] ? 'border-red-400 focus:ring-red-200' : 'border-gray-200 focus:ring-orange-500/20 focus:border-[#f97316]'}`} />
                    </div>
                    {errors[`${idx}-phone`] && (<p className="mt-1 text-[11px] text-red-500 flex items-center gap-1"><X className="w-3 h-3" /> {errors[`${idx}-phone`]}</p>)}
                  </div>
                  <div>
                    <label className="block text-[12px] font-semibold text-gray-700 mb-1">ID / Passport Number <span className="text-red-500">*</span></label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input type="text" value={passengers[idx]?.idNumber || ''} onChange={(e) => handlePassengerChange(idx, 'idNumber', e.target.value)} placeholder="e.g. 12345678" className={`w-full pl-9 pr-3 py-2.5 rounded-lg border text-[13px] bg-white focus:outline-none focus:ring-2 transition-all ${errors[`${idx}-idNumber`] ? 'border-red-400 focus:ring-red-200' : 'border-gray-200 focus:ring-orange-500/20 focus:border-[#f97316]'}`} />
                    </div>
                    {errors[`${idx}-idNumber`] && (<p className="mt-1 text-[11px] text-red-500 flex items-center gap-1"><X className="w-3 h-3" /> {errors[`${idx}-idNumber`]}</p>)}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-5 bg-white border border-gray-200 rounded-2xl p-4 shadow-sm">
            <div className="flex justify-between items-center mb-3">
              <span className="text-[13px] text-gray-500 font-medium">Order Summary</span>
              <span className="text-[20px] font-extrabold text-[#f97316]">KSh {totalPrice.toLocaleString()}</span>
            </div>
            <div className="text-[11px] text-gray-400 mb-3">{selectedSeats.length} passenger{selectedSeats.length > 1 ? 's' : ''} - {busClass} - {departureTime}</div>
            <motion.button
              onClick={handleSubmitForm}
              className="w-full bg-gradient-to-r from-[#dc2626] via-[#f97316] to-[#ea580c] text-white rounded-full py-3 text-[15px] font-bold shadow-lg shadow-orange-600/25 hover:shadow-xl hover:shadow-orange-600/30 transition-shadow"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 15 }}
            >Proceed to Payment</motion.button>

            {/* Divider */}
            <div className="flex items-center gap-3 my-3">
              <div className="flex-1 h-px bg-gray-200" />
              <span className="text-[11px] font-medium text-gray-400 uppercase tracking-wider">Or pay instantly</span>
              <div className="flex-1 h-px bg-gray-200" />
            </div>

            {/* Paystack checkout button */}
            <motion.a
              href={PAYSTACK.PAYMENT_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-center gap-2.5 w-full rounded-full py-3.5 text-[15px] font-bold transition-all"
              style={{ backgroundColor: PAYSTACK.BRAND_COLOR, color: '#fff' }}
              whileHover={{ scale: 1.03, boxShadow: '0 8px 30px rgba(0, 194, 68, 0.35)' }}
              whileTap={{ scale: 0.98 }}
              transition={{ type: "spring", stiffness: 400, damping: 15 }}
            >
              <Shield className="w-4.5 h-4.5" strokeWidth={2.5} />
              {PAYSTACK.LABEL}
              <ExternalLink className="w-4 h-4 opacity-70 group-hover:opacity-100 transition-opacity" strokeWidth={2} />
            </motion.a>
            <p className="text-[11px] text-gray-400 text-center mt-2 flex items-center justify-center gap-1">
              <Lock className="w-3 h-3 inline-block" strokeWidth={2} />
              Secured by Paystack • M-Pesa & Cards accepted
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}