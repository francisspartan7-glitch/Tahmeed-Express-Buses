import { motion } from 'framer-motion';
import {
  Smartphone,
  BatteryCharging,
  Armchair,
  Crown,
  ShieldCheck,
  Sparkles,
  Wifi,
} from 'lucide-react';

const amenities = [
  {
    title: 'Lipa na M-Pesa',
    desc: 'Pay conveniently using M-Pesa',
    icon: Smartphone,
    bg: 'bg-blue-50 dark:bg-blue-950/30',
    iconBg: 'bg-blue-100 dark:bg-blue-900/50',
    iconColor: 'text-blue-600 dark:text-blue-400',
    border: 'border-blue-100 dark:border-blue-900/40',
  },
  {
    title: 'Power Outlets',
    desc: 'Keep your devices charged',
    icon: BatteryCharging,
    bg: 'bg-emerald-50 dark:bg-emerald-950/30',
    iconBg: 'bg-emerald-100 dark:bg-emerald-900/50',
    iconColor: 'text-emerald-600 dark:text-emerald-400',
    border: 'border-emerald-100 dark:border-emerald-900/40',
  },
  {
    title: 'Extra Legroom',
    desc: 'Travel with space to stretch',
    icon: Armchair,
    bg: 'bg-amber-50 dark:bg-amber-950/30',
    iconBg: 'bg-amber-100 dark:bg-amber-900/50',
    iconColor: 'text-amber-600 dark:text-amber-400',
    border: 'border-amber-100 dark:border-amber-900/40',
  },
  {
    title: 'VIP Seating',
    desc: 'Premium comfort, top priority',
    icon: Crown,
    bg: 'bg-purple-50 dark:bg-purple-950/30',
    iconBg: 'bg-purple-100 dark:bg-purple-900/50',
    iconColor: 'text-purple-600 dark:text-purple-400',
    border: 'border-purple-100 dark:border-purple-900/40',
  },
];

const advantages = [
  {
    title: 'Lipa na M-Pesa',
    desc: 'Book your tickets hassle-free using M-Pesa. Simple, secure, and widely accepted across Kenya.',
    icon: Smartphone,
    color: 'text-blue-600 dark:text-blue-400',
    bg: 'bg-blue-50 dark:bg-blue-950/30',
  },
  {
    title: 'We Care',
    desc: 'Comfortable, well-maintained buses designed for Kenyan roads. Your safety and comfort are our priority.',
    icon: ShieldCheck,
    color: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-50 dark:bg-emerald-950/30',
  },
  {
    title: 'No 1 Bus Countrywide',
    desc: '16 years of leadership in Kenyan transport. Trusted by thousands of passengers nationwide.',
    icon: Sparkles,
    color: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-50 dark:bg-amber-950/30',
  },
  {
    title: 'Sleeping Coach',
    desc: 'Air conditioning, high-speed Wi-Fi, and power outlets on all our coaches. Travel in comfort day or night.',
    icon: Wifi,
    color: 'text-purple-600 dark:text-purple-400',
    bg: 'bg-purple-50 dark:bg-purple-950/30',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { type: 'spring', stiffness: 100, damping: 15 },
  },
};

export default function Amenities() {
  return (
    <section className="px-4 py-12 md:py-16 max-w-6xl mx-auto">
      {/* Amenities Section */}
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-50px' }}
        variants={containerVariants}
      >
        <div className="mb-8">
          <span className="inline-block text-[11px] font-bold tracking-[0.15em] uppercase text-[#f97316] mb-2">
            Premium Amenities
          </span>
          <h2 className="text-2xl md:text-3xl font-extrabold text-gray-900 dark:text-white tracking-tight">
            Travel in Comfort
          </h2>
          <p className="text-sm md:text-base text-gray-500 dark:text-gray-400 mt-1.5 max-w-[65ch]">
            Enjoy our premium facilities designed to make every journey relaxing and enjoyable.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {amenities.map((item, i) => (
            <motion.div
              key={item.title}
              variants={itemVariants}
              className={`${item.bg} ${item.border} border rounded-2xl p-5 md:p-6 flex flex-col items-center text-center cursor-default transition-all duration-300 hover:-translate-y-1 hover:shadow-lg`}
            >
              <div className={`${item.iconBg} w-12 h-12 rounded-full flex items-center justify-center mb-3`}>
                <item.icon className={`w-6 h-6 ${item.iconColor}`} strokeWidth={1.5} />
              </div>
              <h3 className="text-sm font-bold text-gray-900 dark:text-white">{item.title}</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Our Advantages Section */}
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-50px' }}
        variants={containerVariants}
        className="mt-16 md:mt-20"
      >
        <div className="mb-8">
          <span className="inline-block text-[11px] font-bold tracking-[0.15em] uppercase text-[#f97316] mb-2">
            Why Choose Us
          </span>
          <h2 className="text-2xl md:text-3xl font-extrabold text-gray-900 dark:text-white tracking-tight">
            Our Advantages
          </h2>
          <p className="text-sm md:text-base text-gray-500 dark:text-gray-400 mt-1.5 max-w-[65ch]">
            Discover why thousands of passengers choose Tahmeed Express for their journeys.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {advantages.map((item, i) => (
            <motion.div
              key={item.title}
              variants={itemVariants}
              className="group flex items-start gap-4 p-5 rounded-2xl border border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-gray-200 dark:hover:border-gray-700"
            >
              <div className={`${item.bg} w-12 h-12 rounded-xl flex items-center justify-center shrink-0`}>
                <item.icon className={`w-6 h-6 ${item.color}`} strokeWidth={1.5} />
              </div>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-gray-900 dark:text-white">{item.title}</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 leading-relaxed">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}