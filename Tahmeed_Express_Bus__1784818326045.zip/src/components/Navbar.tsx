import React, { useState } from 'react';
import { LayoutDashboard, Home, Phone, Info } from 'lucide-react';
import { type View } from '../types';

interface NavbarProps {
  currentView?: View;
  setView?: React.Dispatch<React.SetStateAction<View>>;
}

const Navbar: React.FC<NavbarProps> = ({ currentView = 'home', setView = () => {} }) => {
  const [isOpen, setIsOpen] = useState(false);

  const logoUrl = "https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1783081885012_FB_IMG_1783081764091.jpg";
  const kenyaFlagUrl = "https://flagcdn.com/w40/ke.png";

  return (
    <nav className="bg-white w-full px-1 pt-2 mb-6 relative">
      <div className="flex justify-between items-center h-12">
        <div className="flex items-center">
          <img 
            src={logoUrl} 
            alt="Tahmeed" 
            className="h-10 md:h-12 w-auto object-contain cursor-pointer"
            onClick={() => setView('home')}
          />
        </div>

        <div className="flex items-center gap-4">
          <img 
            src={kenyaFlagUrl} 
            alt="Kenya" 
            className="w-6 h-6 rounded-full object-cover"
          />
          <div 
            className="w-6 h-[18px] flex flex-col justify-between cursor-pointer"
            onClick={() => setIsOpen(!isOpen)}
          >
            <span className="w-full h-0.5 bg-black rounded-sm"></span>
            <span className="w-full h-0.5 bg-black rounded-sm"></span>
            <span className="w-full h-0.5 bg-black rounded-sm"></span>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {isOpen && (
        <div className="absolute top-14 right-0 w-48 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-50 animate-in fade-in slide-in-from-top-2">
          <button
            onClick={() => {
              setView('home');
              setIsOpen(false);
            }}
            className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 text-gray-700 transition-colors"
          >
            <Home className="w-4 h-4 text-[#f97316]" />
            <span className="text-sm font-bold">Home</span>
          </button>
          <button
            onClick={() => {
              setView('admin');
              setIsOpen(false);
            }}
            className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 text-gray-700 transition-colors border-t border-gray-50"
          >
            <LayoutDashboard className="w-4 h-4 text-[#f97316]" />
            <span className="text-sm font-bold">Admin Dashboard</span>
          </button>
          <div className="border-t border-gray-50 my-1"></div>
          <button className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 text-gray-700 transition-colors opacity-50 cursor-not-allowed">
            <Phone className="w-4 h-4" />
            <span className="text-sm font-medium">Contact Support</span>
          </button>
          <button className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 text-gray-700 transition-colors opacity-50 cursor-not-allowed">
            <Info className="w-4 h-4" />
            <span className="text-sm font-medium">About Tahmeed</span>
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;