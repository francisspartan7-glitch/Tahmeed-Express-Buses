import React from 'react';
import { motion } from 'framer-motion';
import { 
  Bus, 
  User, 
  Phone, 
  MapPin, 
  Clock, 
  ChevronLeft, 
  Bell, 
  TrendingUp, 
  Users, 
  DollarSign,
  Search
} from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

export interface Booking {
  id: string;
  passengerName: string;
  passengerCount: number;
  phone: string;
  from: string;
  to: string;
  departureTime: string;
  time: string;
  status?: 'pending' | 'confirmed';
}

interface AdminDashboardProps {
  bookings: Booking[];
  onBack: () => void;
  onUpdateBookingStatus?: (id: string, status: 'pending' | 'confirmed') => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ bookings, onBack, onUpdateBookingStatus }) => {
  const stats = [
    { label: 'Total Bookings', value: bookings.length, icon: Bus, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Total Passengers', value: bookings.reduce((sum, b) => sum + b.passengerCount, 0), icon: Users, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Revenue', value: `KES ${(bookings.length * 1500).toLocaleString()}`, icon: DollarSign, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Active Alerts', value: bookings.filter(b => b.time.includes('AM') || b.time.includes('PM')).length, icon: Bell, color: 'text-red-600', bg: 'bg-red-50' },
  ];

  return (
    <div className="bg-[#F9FAFB] min-h-screen pb-20">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900 tracking-tight">Admin Dashboard</h1>
        </div>
        <div className="relative">
          <Bell className="w-6 h-6 text-gray-400" />
          {bookings.length > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">
              {bookings.length > 9 ? '9+' : bookings.length}
            </span>
          )}
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          {stats.map((stat, i) => (
            <Card key={i} className="p-4 border-none shadow-sm bg-white">
              <div className={`${stat.bg} ${stat.color} w-10 h-10 rounded-xl flex items-center justify-center mb-3`}>
                <stat.icon className="w-5 h-5" />
              </div>
              <p className="text-[12px] text-gray-500 font-medium">{stat.label}</p>
              <p className="text-[18px] font-bold text-gray-900 mt-0.5">{stat.value}</p>
            </Card>
          ))}
        </div>

        {/* Pending Payment Requests */}
        {bookings.filter(b => b.status === 'pending').length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3 px-1">
              <h2 className="text-[16px] font-bold text-gray-900 flex items-center gap-2">
                <span className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />
                Pending Payment Requests
              </h2>
              <Badge variant="outline" className="text-yellow-600 border-yellow-200 font-medium">
                {bookings.filter(b => b.status === 'pending').length} waiting
              </Badge>
            </div>

            <div className="space-y-3">
              {bookings.filter(b => b.status === 'pending').map((booking, idx) => (
                <motion.div
                  key={booking.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <Card className="p-4 border-2 border-yellow-200 shadow-sm bg-yellow-50">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-yellow-100 text-yellow-700 rounded-full flex items-center justify-center">
                          <Phone className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-[15px] font-bold text-gray-900">{booking.passengerName}</p>
                          <p className="text-[13px] text-gray-700 font-semibold flex items-center gap-1">
                            <Phone className="w-3 h-3" /> {booking.phone}
                          </p>
                          <p className="text-[11px] text-orange-600 font-semibold flex items-center gap-1 mt-0.5">
                            <Users className="w-3 h-3" /> {booking.passengerCount} passenger{booking.passengerCount > 1 ? 's' : ''}
                          </p>
                        </div>
                      </div>
                      <Badge className="bg-yellow-100 text-yellow-700 border border-yellow-300">Awaiting Prompt</Badge>
                    </div>

                    <div className="bg-white rounded-lg p-3 mb-3">
                      <p className="text-[12px] font-bold text-gray-700 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-gray-400" />
                        {booking.from} → {booking.to} | {booking.departureTime}
                      </p>
                    </div>

                    <motion.button
                      whileTap={{ scale: 0.97 }}
                      onClick={() => onUpdateBookingStatus?.(booking.id, 'confirmed')}
                      className="w-full bg-emerald-500 text-white rounded-full py-2.5 text-[14px] font-bold hover:bg-emerald-600 transition-colors flex items-center justify-center gap-2"
                    >
                      <Phone className="w-4 h-4" />
                      Prompt Payment Now
                    </motion.button>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Live Alerts Section */}
        <div>
          <div className="flex items-center justify-between mb-3 px-1">
            <h2 className="text-[16px] font-bold text-gray-900 flex items-center gap-2">
              <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              Live Booking Alerts
            </h2>
            <Badge variant="outline" className="text-gray-500 font-medium">Real-time</Badge>
          </div>

          <div className="space-y-3">
            {bookings.length === 0 ? (
              <Card className="p-8 text-center border-dashed border-2 bg-white">
                <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Search className="w-6 h-6 text-gray-300" />
                </div>
                <p className="text-gray-400 text-sm">No recent bookings to display</p>
              </Card>
            ) : (
              bookings.map((booking, idx) => (
                <motion.div
                  key={booking.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <Card className="p-4 border-none shadow-sm bg-white hover:ring-2 hover:ring-orange-500/20 transition-all">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-orange-50 text-orange-600 rounded-full flex items-center justify-center">
                          <User className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-[15px] font-bold text-gray-900">{booking.passengerName}</p>
                          <p className="text-[12px] text-gray-500 flex items-center gap-1">
                            <Phone className="w-3 h-3" /> {booking.phone}
                          </p>
                          <p className="text-[11px] text-orange-600 font-semibold flex items-center gap-1 mt-0.5">
                            <Users className="w-3 h-3" /> {booking.passengerCount} passenger{booking.passengerCount > 1 ? 's' : ''}
                          </p>
                        </div>
                      </div>
                      <Badge className={
                        booking.status === 'pending' 
                          ? 'bg-yellow-100 text-yellow-700 border border-yellow-300' 
                          : 'bg-emerald-50 text-emerald-600 border-none'
                      }>
                        {booking.status === 'pending' ? 'Pending' : 'Confirmed'}
                      </Badge>
                    </div>

                    <div className="bg-gray-50 rounded-lg p-3 grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <p className="text-[10px] uppercase text-gray-400 font-bold tracking-wider">Route</p>
                        <p className="text-[12px] font-bold text-gray-700 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-gray-400" />
                          {booking.from} → {booking.to}
                        </p>
                      </div>
                      <div className="space-y-1 text-right">
                        <p className="text-[10px] uppercase text-gray-400 font-bold tracking-wider">Schedule</p>
                        <p className="text-[12px] font-bold text-gray-700 flex items-center gap-1 justify-end">
                          <Clock className="w-3 h-3 text-gray-400" />
                          {booking.departureTime}
                        </p>
                      </div>
                    </div>

                    <div className="mt-3 flex justify-between items-center">
                      <p className="text-[11px] text-gray-400 font-medium">Ref: {booking.id}</p>
                      <p className="text-[11px] text-gray-500 italic font-medium">{booking.time}</p>
                    </div>
                  </Card>
                </motion.div>
              ))
            )}
          </div>
        </div>

        {/* Growth Stats */}
        <Card className="p-4 bg-[#111827] text-white border-none shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-gray-400 text-[12px] font-medium uppercase tracking-wider">Daily Performance</p>
              <h3 className="text-xl font-bold mt-1">Operational Summary</h3>
            </div>
            <div className="p-2 bg-white/10 rounded-lg">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-400">Bus Occupancy</span>
              <span className="font-bold">84%</span>
            </div>
            <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
              <div className="bg-emerald-400 h-full w-[84%]" />
            </div>
            <div className="flex justify-between items-center text-sm pt-2">
              <span className="text-gray-400">On-time Departures</span>
              <span className="font-bold">96%</span>
            </div>
            <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
              <div className="bg-blue-400 h-full w-[96%]" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;
