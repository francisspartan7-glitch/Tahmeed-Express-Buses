import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Wifi, Usb, Wind, Star, Users } from 'lucide-react';
import { cn } from '../lib/utils';
import { routes } from '../data/travelData';

interface SearchResultsProps {
  from: string;
  to: string;
  date: string;
  onBack: () => void;
  onSelectBus?: (bus: BusResult) => void;
}

export interface BusResult {
  id: string;
  from: string;
  to: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  busModel: string;
  busClass: string;
  rating: number;
  price: number;
  seatsLeft: number;
  amenities: string[];
  logoUrl: string;
  boardingPoints?: string[];
  pickupStations?: string[];
}

const TAHMEED_LOGO = 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1783081885012_FB_IMG_1783081764091.jpg';
const DATE_PILLS = ['10 Jun', '11 Jun', '12 Jun', '13 Jun', '14 Jun'];

const amenityIcons: Record<string, React.ReactNode> = {
  'WiFi': <Wifi size={15} />,
  'USB Charging': <Usb size={15} />,
  'Air Con': <Wind size={15} />,
  'Refreshments': <span className="text-[10px] font-bold">H2O</span>,
};

const calculateArrivalTime = (departure: string, duration: string): string => {
  const timeMatch = departure.match(/(\d{1,2}):(\d{2})\s*(AM|PM)/i);
  if (!timeMatch) return departure;
  let hours = parseInt(timeMatch[1], 10);
  const minutes = parseInt(timeMatch[2], 10);
  const ampm = timeMatch[3].toUpperCase();
  if (ampm === 'PM' && hours !== 12) hours += 12;
  if (ampm === 'AM' && hours === 12) hours = 0;
  const durMatch = duration.match(/(\d+)/);
  const addHours = durMatch ? parseInt(durMatch[1], 10) : 5;
  const totalMinutes = (hours * 60 + minutes) + (addHours * 60);
  const arrHours = Math.floor(totalMinutes / 60) % 24;
  const arrMinutes = totalMinutes % 60;
  const arrAmpm = arrHours >= 12 ? 'PM' : 'AM';
  const displayHours = arrHours % 12 || 12;
  return `${displayHours.toString().padStart(2, '0')}:${arrMinutes.toString().padStart(2, '0')} ${arrAmpm}`;
};

const formatPrice = (price: number): string => {
  return `KES ${price.toLocaleString()}`;
};

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.05, duration: 0.4, ease: [0.16, 1, 0.3, 1] as any },
  }),
  exit: { opacity: 0, y: -10, transition: { duration: 0.2 } },
};

const SearchResults: React.FC<SearchResultsProps> = ({ from, to, date, onBack, onSelectBus }) => {
  const [selectedDate, setSelectedDate] = useState(date || '10 Jun');
  const [selectedBusId, setSelectedBusId] = useState<string | null>(null);
  const [filterClass, setFilterClass] = useState<'All' | 'VIP' | 'Executive' | 'Standard'>('All');

  const results = useMemo(() => {
    const origin = from?.trim() || 'Nairobi';
    const destination = to?.trim() || 'Mombasa';
    let filtered = routes.filter(r =>
      r.origin.toLowerCase() === origin.toLowerCase() &&
      r.destination.toLowerCase() === destination.toLowerCase()
    );
    if (filterClass !== 'All') {
      filtered = filtered.filter(r => r.busType === filterClass);
    }
    return filtered.map(r => ({
      id: r.id,
      from: r.origin,
      to: r.destination,
      departureTime: r.departureTime,
      arrivalTime: calculateArrivalTime(r.departureTime, r.duration),
      duration: r.duration,
      busModel: r.busType === 'VIP' ? 'SCANIA F360 2+1' : r.busType === 'Executive' ? 'MAN EXPLORER 2+2' : 'SCANIA F330',
      busClass: r.busType === 'VIP' ? 'VIP CLASS 2+1' : r.busType === 'Executive' ? 'EXECUTIVE CLASS' : 'STANDARD CLASS',
      rating: r.rating,
      price: r.price,
      seatsLeft: r.seatsLeft || 8,
      amenities: r.features,
      logoUrl: TAHMEED_LOGO,
      boardingPoints: r.boardingPoints,
      pickupStations: r.pickupStations,
    }));
  }, [from, to, filterClass]);

  const handleSelectBus = (bus: BusResult) => {
    setSelectedBusId(bus.id);
    onSelectBus?.(bus);
  };

  const getRouteCode = (fromCity: string, toCity: string): string => {
    const code = (city: string) => city.substring(0, 3).toUpperCase();
    return `${code(fromCity)}-${code(toCity)} 1`;
  };

  const getPriceTiers = (basePrice: number) => ({
    bclass: Math.round(basePrice * 0.8),
    normal: basePrice,
    vip: Math.round(basePrice * 1.4),
  });

  const getClassTag = (busClass: string): string => {
    if (busClass.includes('VIP')) return 'vip';
    if (busClass.includes('EXECUTIVE')) return 'executive';
    return 'standard';
  };

  return (
    <div className="bg-[#F3F4F6] min-h-screen flex flex-col font-sans">
      <div className="bg-[#f97316] text-white px-4 pt-3 pb-4">
        <div className="flex items-center gap-3 mb-3">
          <button onClick={onBack} className="p-1.5 -ml-1.5 hover:bg-white/15 rounded-full transition-colors">
            <ArrowLeft size={22} />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-[15px] font-bold tracking-tight leading-tight truncate">
              {from || 'Nairobi'}
              <span className="mx-1.5 opacity-70">-</span>
              {to || 'Mombasa'}
            </h1>
            <p className="text-[12px] text-white/80 leading-tight mt-0.5 font-medium">
              {selectedDate}, 2026 - {results.length} trips found
            </p>
          </div>
        </div>
        <div className="flex gap-2 overflow-x-auto scrollbar-hide -mx-1 px-1">
          {DATE_PILLS.map((d) => (
            <motion.button
              key={d}
              onClick={() => setSelectedDate(d)}
              className={cn(
                'flex-shrink-0 rounded-full px-4 py-2 text-[13px] font-semibold transition-all',
                selectedDate === d ? 'bg-white text-[#f97316] shadow-sm' : 'bg-white/15 text-white hover:bg-white/25'
              )}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 15 }}
            >
              {d}
            </motion.button>
          ))}
        </div>
      </div>

      <div className="px-4 py-2.5 flex gap-2 overflow-x-auto scrollbar-hide bg-white border-b border-gray-200">
        {['All', 'VIP', 'Executive', 'Standard'].map((cls) => (
          <button
            key={cls}
            onClick={() => setFilterClass(cls as any)}
            className={cn(
              'flex items-center gap-1.5 rounded-full px-4 py-1.5 text-[12px] font-bold transition-all flex-shrink-0',
              filterClass === cls ? 'bg-[#f97316] text-white shadow-sm' : 'border border-gray-200 text-gray-600 hover:bg-gray-50'
            )}
          >
            {cls} {cls !== 'All' ? 'Class' : 'Buses'}
          </button>
        ))}
      </div>

      <div className="flex-1 px-3 pt-4 pb-12 overflow-y-auto">
        <AnimatePresence mode="wait">
          <div className="flex flex-col gap-3">
            {results.length === 0 && (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-200">
                <p className="text-gray-500 font-medium">No trips found for this route.</p>
                <button onClick={onBack} className="text-[#f97316] font-bold mt-2">Try another route</button>
              </div>
            )}
            {results.map((bus, i) => {
              const prices = getPriceTiers(bus.price);
              const classTag = getClassTag(bus.busClass);
              const routeCode = getRouteCode(bus.from, bus.to);
              return (
                <motion.div
                  key={bus.id}
                  variants={cardVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  custom={i}
                  layout
                  className="bus-result-card"
                  onClick={() => handleSelectBus(bus)}
                >
                  <div className="px-4 pt-3 pb-2">
                    <span className="bus-route-badge">{routeCode}</span>
                    <div className="bus-times">
                      <div className="from">
                        <span className="time-value">{bus.departureTime}</span>
                        <span className="location-label">{bus.from}</span>
                      </div>
                      <div className="duration-wrap">
                        <span className="duration-text">{bus.duration}</span>
                        <div className="duration-line" />
                      </div>
                      <div className="to">
                        <span className="time-value">{bus.arrivalTime}</span>
                        <span className="location-label">{bus.to}</span>
                      </div>
                    </div>

                    <div className="bus-company">
                      <div className="bus-company-left">
                        <img src={bus.logoUrl} alt="Tahmeed" className="bus-company-logo" />
                        <div>
                          <div className="bus-company-name">Tahmeed Express</div>
                          <div className="bus-company-model">{bus.busModel}</div>
                        </div>
                      </div>
                      <span className="rating-badge">
                        <Star className="star-icon" fill="currentColor" />
                        {bus.rating}
                      </span>
                    </div>

                    <div className="bus-amenities">
                      {bus.amenities.slice(0, 4).map((a) => (
                        <span key={a} title={a}>
                          {amenityIcons[a] || <Wifi size={15} />}
                        </span>
                      ))}
                      <span className={`bus-class-tag ${classTag}`}>
                        {bus.busClass.replace(' CLASS', '')}
                      </span>
                    </div>

                    <div className="bus-prices">
                      <div className="price-tier">
                        <span className="tier-label">Bclass</span>
                        <span className="tier-value">{formatPrice(prices.bclass)}</span>
                      </div>
                      <span className="price-divider">|</span>
                      <div className="price-tier">
                        <span className="tier-label">Normal</span>
                        <span className="tier-value">{formatPrice(prices.normal)}</span>
                      </div>
                      <span className="price-divider">|</span>
                      <div className="price-tier">
                        <span className="tier-label">VIP</span>
                        <span className="tier-value vip-price">{formatPrice(prices.vip)}</span>
                      </div>
                    </div>

                    <div className="bus-meta">
                      <span className={cn('seats-left', bus.seatsLeft <= 5 ? 'low' : 'ok')}>
                        <Users size={14} />
                        {bus.seatsLeft} seats left
                      </span>
                      <motion.button
                        className={cn('view-seats-btn', selectedBusId === bus.id && 'selected')}
                        whileHover={{ scale: 1.04 }}
                        whileTap={{ scale: 0.95 }}
                        transition={{ type: "spring", stiffness: 400, damping: 15 }}
                        onClick={(e) => { e.stopPropagation(); handleSelectBus(bus); }}
                      >
                        {selectedBusId === bus.id ? 'SELECTED' : 'View Seats'}
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default SearchResults;