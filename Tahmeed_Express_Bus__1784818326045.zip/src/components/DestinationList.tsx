import React from 'react';
import { Star, MapPin, Building2, ExternalLink, ChevronDown, Check, Route, Search } from 'lucide-react';
import { stations, routes } from '../data/travelData';
import { motion } from 'framer-motion';
import { Card, CardContent, CardFooter } from './ui/card';
import { Badge } from './ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from './ui/command';
import { cn } from '../lib/utils';

interface DestinationListProps {
  limit?: number;
  title?: string;
  searchQuery?: string;
}

const DestinationList: React.FC<DestinationListProps> = ({ limit, title = "Our Nationwide Network", searchQuery = "" }) => {
  const filtered = stations.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.city.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const displayStations = limit ? filtered.slice(0, limit) : filtered;

  return (
    <section className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tight">{title}</h2>
          <p className="text-slate-500 mt-2 font-medium italic uppercase tracking-widest text-xs">Safe and modern terminals serving East Africa.</p>
        </div>
        {!limit && (
           <div className="text-[10px] font-black text-black bg-slate-100 px-4 py-2 rounded-full border border-slate-200 uppercase tracking-widest">
            {filtered.length} Terminals Available
           </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {displayStations.map((station, idx) => (
          <motion.div
            key={station.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: Math.min(idx * 0.05, 0.5) }}
          >
            <Card className="overflow-hidden group cursor-pointer border border-slate-100 shadow-xl hover:shadow-2xl transition-all duration-500 bg-white rounded-[2rem] h-full flex flex-col">
              <div className="relative h-64 overflow-hidden transition-all duration-700">
                <img 
                  src={station.image} 
                  alt={station.name} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-primary text-white backdrop-blur-sm border-none shadow-sm font-black text-[10px] uppercase px-3 py-1 rounded-full">
                    {station.category}
                  </Badge>
                </div>
                <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute bottom-6 left-6 flex items-center gap-2 text-white font-black uppercase tracking-widest text-[11px]">
                   <MapPin size={14} />
                   <span>{station.city}</span>
                </div>
              </div>
              <CardContent className="p-6 flex-grow">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-xl font-black text-slate-900 uppercase tracking-tighter leading-none">{station.name}</h3>
                  <div className="flex items-center gap-1 text-black">
                    <Star size={16} fill="currentColor" />
                    <span className="text-sm font-black">{station.rating}</span>
                  </div>
                </div>
                <p className="text-slate-500 text-xs font-black uppercase tracking-wider leading-relaxed opacity-60">
                  {station.description}
                </p>
              </CardContent>
              <CardFooter className="p-6 pt-0 mt-auto">
                <button className="text-[11px] font-black text-black uppercase tracking-[0.2em] hover:translate-x-1 flex items-center gap-2 transition-all group-hover:text-black">
                  <span>View Details</span>
                  <ExternalLink size={14} />
                </button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-20 bg-slate-50 rounded-[3rem] border-2 border-dashed border-slate-200">
          <div className="bg-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
            <Building2 className="text-slate-300" size={40} />
          </div>
          <h3 className="text-xl font-black text-slate-900 mb-1 uppercase tracking-tight">No terminals found</h3>
          <p className="text-slate-400 font-black text-xs uppercase tracking-widest">We couldn't find any locations matching "{searchQuery}"</p>
        </div>
      )}
    </section>
  );
};

interface StationSelectProps {
  value: string;
  onSelect: (value: string) => void;
  label: string;
  placeholder?: string;
  icon?: React.ReactNode;
  className?: string;
  dark?: boolean;
}

export const StationSelect: React.FC<StationSelectProps> = ({ 
  value, 
  onSelect, 
  label, 
  placeholder = "Select City", 
  icon = <MapPin size={16} className="text-black" />,
  className,
}) => {
  const [open, setOpen] = React.useState(false);

  const cities = Array.from(new Set(stations.map(s => s.city))).sort();
  
  const routesByOrigin = routes.reduce((acc, route) => {
    if (!acc[route.origin]) acc[route.origin] = [];
    acc[route.origin].push(route);
    return acc;
  }, {} as Record<string, typeof routes>);

  return (
    <div className={cn("space-y-2", className)}>
      <label className={cn("text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2 ml-1", "text-slate-400")}>
        {icon} {label}
      </label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            className={cn(
              "w-full border border-slate-200 rounded-2xl p-4 font-black text-sm flex items-center justify-between transition-all text-left h-[60px]",
              "bg-slate-50 text-slate-900 hover:bg-white hover:border-black hover:shadow-lg hover:-translate-y-0.5"
            )}
          >
            <span className={cn("truncate", !value && "text-slate-300 font-black italic")}>{value || placeholder}</span>
            <ChevronDown size={20} className={cn("text-slate-400 transition-transform duration-200", open && "rotate-180")} />
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-[320px] p-0 rounded-[2rem] border border-slate-100 shadow-[0_20px_50px_rgba(0,0,0,0.2)] overflow-hidden bg-white z-[100]" align="start">
          <Command className="bg-white">
            <div className="flex items-center px-4 py-3 border-b border-slate-50">
              <Search className="text-slate-300 mr-2" size={18} />
              <CommandInput placeholder="Search city..." className="border-none focus:ring-0 font-black text-sm uppercase tracking-tight h-10" />
            </div>
            <CommandList className="max-h-[350px] overflow-y-auto custom-scrollbar">
              <CommandEmpty className="py-10 text-center text-xs text-slate-400 font-black uppercase tracking-[0.2em]">No terminal found.</CommandEmpty>
              
              <CommandGroup heading="POPULAR TERMINALS" className="px-2 py-3">
                {cities.map((city) => (
                  <CommandItem
                    key={city}
                    value={city}
                    onSelect={() => {
                      onSelect(city);
                      setOpen(false);
                    }}
                    className="rounded-2xl px-4 py-4 flex items-center justify-between cursor-pointer hover:bg-slate-50 aria-selected:bg-slate-50 transition-all mb-1 group"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                        <MapPin size={18} />
                      </div>
                      <div>
                        <p className="font-black text-slate-900 text-sm uppercase tracking-tighter leading-none mb-1.5">{city}</p>
                        <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.2em]">
                          {routesByOrigin[city]?.length || 0} Daily Departures
                        </p>
                      </div>
                    </div>
                    {value === city && <Check size={20} className="text-black" />}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default DestinationList;