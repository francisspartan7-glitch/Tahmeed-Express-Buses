import React from 'react';
import { Quote, Star } from 'lucide-react';
import { motion } from 'framer-motion';

const reviews = [
  {
    id: 1,
    name: "Elena Rodriguez",
    location: "Nairobi",
    text: "The express bus is my go-to for coast trips. The VIP seats are incredibly comfortable and the WiFi actually works throughout the journey!",
    rating: 5,
    avatar: "ER"
  },
  {
    id: 2,
    name: "Mark Thompson",
    location: "Mombasa",
    text: "Punctuality is everything for me. Every time I travel, we depart and arrive exactly as scheduled. Highly recommended.",
    rating: 5,
    avatar: "MT"
  },
  {
    id: 3,
    name: "Sophie Chen",
    location: "Kampala",
    text: "Best cross-border service. The staff helped me with all the customs paperwork at the border, making the trip stress-free.",
    rating: 4,
    avatar: "SC"
  }
];

const Reviews: React.FC = () => {
  return (
    <section className="py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Passenger Experiences</h2>
        <p className="text-slate-500 mt-2 font-medium">Join thousands of happy travelers across East Africa.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {reviews.map((rev, idx) => (
          <motion.div
            key={rev.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 relative transition-all duration-500"
          >
            <Quote className="absolute top-6 right-6 text-slate-50" size={40} />
            <div className="flex gap-1 text-black mb-4">
              {[...Array(rev.rating)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
            </div>
            <p className="text-slate-600 italic font-medium leading-relaxed mb-8">"{rev.text}"</p>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center text-white font-black text-sm">
                {rev.avatar}
              </div>
              <div>
                <h4 className="font-black text-slate-900 uppercase tracking-tight">{rev.name}</h4>
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{rev.location}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default Reviews;