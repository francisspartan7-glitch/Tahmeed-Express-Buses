import React from 'react';
import { blogPosts } from '../data/travelData';
import { Calendar, User, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

interface BlogSectionProps {
  limit?: number;
}

const BlogSection: React.FC<BlogSectionProps> = ({ limit }) => {
  const posts = limit ? blogPosts.slice(0, limit) : blogPosts;

  return (
    <section className="space-y-12">
      <div className="text-center space-y-3">
        <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tight">The Travel Journal</h2>
        <p className="text-slate-500 max-w-2xl mx-auto font-medium">
          Latest travel tips, stories, and destination guides from our community.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        {posts.map((post, idx) => (
          <motion.article
            key={post.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="group cursor-pointer"
          >
            <div className="relative h-64 overflow-hidden rounded-[2.5rem] mb-6 transition-all duration-700">
              <img 
                src={post.image} 
                alt={post.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute top-5 left-5">
                <span className="bg-white/95 backdrop-blur-sm text-black text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-sm">
                  {post.category}
                </span>
              </div>
            </div>

            <div className="space-y-4 px-2">
              <div className="flex items-center gap-5 text-[10px] text-slate-400 font-black uppercase tracking-[0.2em]">
                <div className="flex items-center gap-1.5">
                  <Calendar size={12} />
                  <span>{post.date}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <User size={12} />
                  <span>{post.author}</span>
                </div>
              </div>
              
              <h3 className="text-2xl font-black text-slate-900 group-hover:text-black transition-colors uppercase tracking-tighter leading-tight">
                {post.title}
              </h3>
              
              <p className="text-slate-500 text-sm font-medium leading-relaxed line-clamp-2">
                {post.excerpt}
              </p>

              <button className="flex items-center gap-2 text-black font-black text-[10px] uppercase tracking-[0.3em] hover:translate-x-1 transition-transform">
                Read Story <ArrowRight size={14} />
              </button>
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
};

export default BlogSection;