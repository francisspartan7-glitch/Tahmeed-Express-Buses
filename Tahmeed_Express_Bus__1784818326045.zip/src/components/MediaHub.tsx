import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Camera,
  Play,
  Image,
  Instagram,
  MessageCircle,
  Phone,
  Youtube,
  ExternalLink,
  Music2,
  ChevronLeft,
  X,
  LayoutGrid,
  Search,
  Globe,
  Clapperboard,
} from 'lucide-react';
import { TAHMEED_LOGO_URL, TAHMEED_BRAND_NAME, TAHMEED_PHONE } from '../constants';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface MediaItem {
  id: string;
  title: string;
  description?: string;
  type: 'photo' | 'video';
  url: string;
  thumbnail_url?: string;
  created_at: string;
}

interface SocialLink {
  id: string;
  platform: string;
  label: string;
  url: string;
  icon: string;
  is_active: boolean;
  priority: number;
}

/* ------------------------------------------------------------------ */
/*  Default seed data (localStorage fallback)                          */
/* ------------------------------------------------------------------ */

const DEFAULT_MEDIA: MediaItem[] = [
  {
    id: '1', title: 'Tahmeed Fleet', description: 'Our luxurious fleet ready for the journey',
    type: 'photo', url: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=800',
    thumbnail_url: undefined, created_at: new Date().toISOString(),
  },
  {
    id: '2', title: 'Tahmeed Luxury Fleet Coach', description: 'Premium coach featuring state-of-the-art amenities for intercity travel',
    type: 'photo', url: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1784409254863_images.jpeg',
    thumbnail_url: undefined, created_at: new Date().toISOString(),
  },
  {
    id: '3', title: 'Premium Sleeping Cabin Interior', description: 'Reclining luxury cabins with privacy curtains and personal entertainment',
    type: 'photo', url: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1784409254864_images__1_.jpeg',
    thumbnail_url: undefined, created_at: new Date().toISOString(),
  },
  {
    id: '4', title: 'Nairobi-Mombasa Highway', description: 'Scenic views along the route',
    type: 'photo', url: 'https://images.unsplash.com/photo-1468421870903-4df1664ac249?w=800',
    thumbnail_url: undefined, created_at: new Date().toISOString(),
  },
  {
    id: '5', title: 'VIP Lounge Experience', description: 'Relax before departure',
    type: 'photo', url: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800',
    thumbnail_url: undefined, created_at: new Date().toISOString(),
  },
  {
    id: '6', title: 'Onboard Comfort', description: 'Premium seats with extra legroom',
    type: 'photo', url: 'https://images.unsplash.com/photo-1559223607-a43c990c692c?w=800',
    thumbnail_url: undefined, created_at: new Date().toISOString(),
  },
  {
    id: '7', title: 'Tahmeed Express Promo', description: 'Experience luxury travel across East Africa',
    type: 'video', url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    thumbnail_url: undefined, created_at: new Date().toISOString(),
  },
  {
    id: '8', title: 'Customer Testimonials', description: 'Hear from our happy passengers',
    type: 'video', url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    thumbnail_url: undefined, created_at: new Date().toISOString(),
  },
  {
    id: '9', title: 'Coastal Views', description: 'Stunning views along the coast',
    type: 'photo', url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800',
    thumbnail_url: undefined, created_at: new Date().toISOString(),
  },
  {
    id: '10', title: 'Team Tahmeed', description: 'Our dedicated team ready to serve you',
    type: 'photo', url: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800',
    thumbnail_url: undefined, created_at: new Date().toISOString(),
  },
];

const DEFAULT_SOCIALS: SocialLink[] = [
  { id: '1', platform: 'whatsapp', label: 'WhatsApp Support', url: 'https://wa.me/254751299364', icon: 'MessageCircle', is_active: true, priority: 1 },
  { id: '2', platform: 'phone', label: 'Call Us', url: 'tel:+254722000000', icon: 'Phone', is_active: true, priority: 2 },
  { id: '3', platform: 'tiktok', label: 'TikTok', url: 'https://www.tiktok.com/@tahmeedexpress', icon: 'Music2', is_active: true, priority: 3 },
  { id: '4', platform: 'youtube', label: 'YouTube', url: 'https://www.youtube.com/@tahmeedexpress', icon: 'Youtube', is_active: true, priority: 4 },
  { id: '5', platform: 'instagram', label: 'Instagram', url: 'https://www.instagram.com/tahmeedexpress', icon: 'Instagram', is_active: true, priority: 5 },
];

/* ------------------------------------------------------------------ */
/*  localStorage helpers                                               */
/* ------------------------------------------------------------------ */

function loadFromStorage<T>(key: string, fallback: T[]): T[] {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T[]) : fallback;
  } catch {
    return fallback;
  }
}

function saveToStorage<T>(key: string, data: T[]) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch { /* quota exceeded — ignored */ }
}

/* ------------------------------------------------------------------ */
/*  Social icon renderer                                               */
/* ------------------------------------------------------------------ */

const socialIconMap: Record<string, React.ReactNode> = {
  MessageCircle: <MessageCircle className="w-6 h-6" />,
  Phone: <Phone className="w-6 h-6" />,
  Music2: <Music2 className="w-6 h-6" />,
  Youtube: <Youtube className="w-6 h-6" />,
  Instagram: <Instagram className="w-6 h-6" />,
  Globe: <Globe className="w-6 h-6" />,
  ExternalLink: <ExternalLink className="w-6 h-6" />,
};

const socialColors: Record<string, string> = {
  whatsapp: 'from-emerald-500 to-emerald-600',
  phone: 'from-blue-500 to-blue-600',
  tiktok: 'from-purple-500 to-pink-500',
  youtube: 'from-red-500 to-rose-600',
  instagram: 'from-pink-500 to-purple-600',
  default: 'from-orange-500 to-amber-600',
};

/* ------------------------------------------------------------------ */
/*  MediaHub Component                                                 */
/* ------------------------------------------------------------------ */

interface MediaHubProps {
  onBack: () => void;
}

export default function MediaHub({ onBack }: MediaHubProps) {
  const [mediaItems, setMediaItems] = useState<MediaItem[]>(() =>
    loadFromStorage('media_hub_items', DEFAULT_MEDIA)
  );
  const [socialLinks] = useState<SocialLink[]>(() =>
    loadFromStorage('media_hub_socials', DEFAULT_SOCIALS)
  );
  const [activeTab, setActiveTab] = useState<'all' | 'videos' | 'photos'>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);

  useEffect(() => {
    saveToStorage('media_hub_items', mediaItems);
  }, [mediaItems]);

  const filtered = mediaItems.filter((item) => {
    if (activeTab === 'videos') return item.type === 'video';
    if (activeTab === 'photos') return item.type === 'photo';
    return true;
  });

  const activeSocials = socialLinks
    .filter((l) => l.is_active)
    .sort((a, b) => a.priority - b.priority);

  const openLightbox = useCallback((index: number) => setLightboxIndex(index), []);
  const closeLightbox = useCallback(() => {
    setLightboxIndex(null);
    setPlayingVideo(null);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      {/* Back Button */}
      <div className="sticky top-0 z-30 bg-[#0a0a0f]/80 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-[600px] mx-auto px-4 py-3 flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 -ml-2 hover:bg-white/10 rounded-full transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="text-sm font-bold text-white/60">Media Hub</span>
        </div>
      </div>

      <div className="max-w-[600px] mx-auto px-4 pb-24">
        {/* ─── Header ─── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="text-center pt-8 pb-6"
        >
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-gradient-to-r from-orange-500/30 via-amber-400/20 to-orange-500/30 blur-3xl rounded-full" />
            <img
              src={TAHMEED_LOGO_URL}
              alt={TAHMEED_BRAND_NAME}
              className="relative z-10 w-20 h-20 object-contain rounded-2xl mx-auto brightness-0 invert opacity-90"
            />
          </div>
          <h1 className="text-2xl font-extrabold mt-4 tracking-tight bg-gradient-to-r from-white via-white to-white/70 bg-clip-text text-transparent">
            @tahmeedexpress
          </h1>
          <p className="text-sm text-white/50 mt-2 max-w-xs mx-auto leading-relaxed">
            East Africa's premier luxury travel service. Find us on social media or reach us instantly!
          </p>
        </motion.div>

        {/* ─── Quick Action Buttons ─── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-2 gap-3 mb-8"
        >
          {activeSocials.map((link, i) => {
            const gradient = socialColors[link.platform] || socialColors.default;
            return (
              <motion.a
                key={link.id}
                href={link.url}
                target={link.url.startsWith('http') ? '_blank' : undefined}
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.97 }}
                className={`relative overflow-hidden rounded-2xl p-4 bg-gradient-to-br ${gradient} shadow-lg shadow-black/20 group`}
              >
                <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-colors" />
                <div className="relative z-10 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                    {socialIconMap[link.icon] || <ExternalLink className="w-5 h-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-bold uppercase tracking-wider text-white/70">
                      {link.platform}
                    </p>
                    <p className="text-sm font-bold truncate">{link.label}</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-white/40 shrink-0" />
                </div>
              </motion.a>
            );
          })}
        </motion.div>

        {/* ─── Tabs ─── */}
        <div className="flex gap-1.5 mb-5 p-1 bg-white/5 rounded-2xl">
          {(['all', 'videos', 'photos'] as const).map((tab) => {
            const icons = { all: LayoutGrid, videos: Clapperboard, photos: Camera };
            const Icon = icons[tab];
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-[13px] font-bold transition-all ${
                  activeTab === tab
                    ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20'
                    : 'text-white/40 hover:text-white/70'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="capitalize">{tab}</span>
              </button>
            );
          })}
        </div>

        {/* ─── Media Grid ─── */}
        {filtered.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
              <Search className="w-6 h-6 text-white/20" />
            </div>
            <p className="text-white/30 font-bold">No media yet</p>
            <p className="text-white/20 text-sm mt-1">Check back soon for updates!</p>
          </div>
        ) : (
          <motion.div
            layout
            className="grid grid-cols-2 gap-3"
          >
            <AnimatePresence mode="popLayout">
              {filtered.map((item, idx) => {
                const isTall = idx % 5 === 0 || idx % 5 === 3;
                return (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.3, delay: idx * 0.04, ease: [0.16, 1, 0.3, 1] }}
                    className={`relative rounded-2xl overflow-hidden group cursor-pointer ${
                      item.type === 'video' ? 'col-span-2' : isTall ? 'row-span-2' : ''
                    }`}
                    onClick={() => {
                      if (item.type === 'photo') {
                        const photoIdx = filtered
                          .filter((m) => m.type === 'photo')
                          .indexOf(item);
                        if (photoIdx >= 0) openLightbox(photoIdx);
                      } else {
                        setPlayingVideo(item.url);
                      }
                    }}
                  >
                    {/* Photo / Thumbnail */}
                    <div className="aspect-[4/3] bg-white/5">
                      <img
                        src={item.thumbnail_url || item.url}
                        alt={item.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        loading="lazy"
                      />
                      {/* Overlay gradient */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                      {/* Video play badge */}
                      {item.type === 'video' && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-14 h-14 rounded-full bg-orange-500/90 flex items-center justify-center shadow-xl shadow-orange-500/30 group-hover:scale-110 transition-transform">
                            <Play className="w-6 h-6 text-white ml-0.5" fill="white" />
                          </div>
                        </div>
                      )}

                      {/* Bottom caption */}
                      <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-2 group-hover:translate-y-0 transition-transform">
                        <p className="text-xs font-bold text-white drop-shadow-lg">{item.title}</p>
                        {item.description && (
                          <p className="text-[10px] text-white/70 mt-0.5 line-clamp-1">{item.description}</p>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </motion.div>
        )}
      </div>

      {/* ─── Lightbox ─── */}
      <AnimatePresence>
        {lightboxIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-lg flex items-center justify-center"
            onClick={closeLightbox}
          >
            <button
              onClick={closeLightbox}
              className="absolute top-4 right-4 p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors z-10"
            >
              <X className="w-6 h-6" />
            </button>

            {playingVideo ? (
              <div className="w-full max-w-3xl aspect-video mx-4" onClick={(e) => e.stopPropagation()}>
                <iframe
                  src={playingVideo}
                  className="w-full h-full rounded-2xl"
                  allow="accelerometer; autoplay; encrypted-media; gyroscope"
                  allowFullScreen
                />
              </div>
            ) : (
              <motion.div
                key={lightboxIndex}
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="max-w-3xl w-full mx-4"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="aspect-[4/3] rounded-2xl overflow-hidden">
                  <img
                    src={filtered.filter((m) => m.type === 'photo')[lightboxIndex]?.url}
                    alt=""
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="mt-4 text-center">
                  <p className="font-bold text-lg">
                    {filtered.filter((m) => m.type === 'photo')[lightboxIndex]?.title}
                  </p>
                  <p className="text-white/50 text-sm mt-1">
                    {filtered.filter((m) => m.type === 'photo')[lightboxIndex]?.description}
                  </p>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}