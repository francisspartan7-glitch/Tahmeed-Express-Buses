import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Phone } from 'lucide-react';
import {
  TAHMEED_WHATSAPP_PRIMARY,
  TAHMEED_PHONE,
  TAHMEED_PHONE_2,
} from '../constants';

const WhatsAppWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const defaultMessage = encodeURIComponent(
    'Hello Tahmeed Express, I would like to make an inquiry...'
  );
  const whatsappUrl = `https://wa.me/${TAHMEED_WHATSAPP_PRIMARY}?text=${defaultMessage}`;

  const supportOptions = [
    { label: 'Primary Support', number: TAHMEED_PHONE, href: `https://wa.me/${TAHMEED_WHATSAPP_PRIMARY}?text=${defaultMessage}` },
    { label: 'Secondary Support', number: TAHMEED_PHONE_2, href: `https://wa.me/254${TAHMEED_PHONE_2.substring(1)}?text=${defaultMessage}` },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="mb-2 w-72 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden"
          >
            <div className="bg-emerald-500 p-4 text-white">
              <h3 className="font-bold text-base">Need help?</h3>
              <p className="text-sm text-white/90 mt-1">
                Chat with us on WhatsApp for bookings or inquiries.
              </p>
            </div>
            <div className="p-3 space-y-2">
              {supportOptions.map((option) => (
                <a
                  key={option.number}
                  href={option.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 hover:bg-emerald-50 transition-colors group"
                  onClick={() => setIsOpen(false)}
                >
                  <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Phone size={18} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-900">{option.label}</p>
                    <p className="text-xs text-gray-500">{option.number}</p>
                  </div>
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen((prev) => !prev)}
        aria-label={isOpen ? 'Close WhatsApp support' : 'Open WhatsApp support'}
        className="w-14 h-14 rounded-full bg-emerald-500 text-white shadow-lg shadow-emerald-500/30 flex items-center justify-center hover:bg-emerald-600 transition-colors"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <X size={24} />
            </motion.div>
          ) : (
            <motion.div
              key="open"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <MessageCircle size={26} fill="currentColor" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>
    </div>
  );
};

export default WhatsAppWidget;
