export const TAHMEED_BRAND_NAME = "Tahmeed Coach";
export const TAHMEED_SHORT_NAME = "TAHMEED";
export const TAHMEED_PAYBILL_NUMBER = "529914";
export const TAHMEED_PAYBILL_ACCOUNT = "393270";
export const TAHMEED_PAYBILL_NUMBER_2 = "714777";
export const TAHMEED_PAYBILL_ACCOUNT_2 = "254798536240";
export const TAHMEED_TILL_NUMBER = "512345";
export const TAHMEED_SEND_MONEY_NUMBER = "0722000000";
export const TAHMEED_ACCOUNT_PREFIX = "TAH";
export const TAHMEED_STK_SHORTCODE = "174379";
export const TAHMEED_TAGLINE = "Travel in Comfort, Arrive in Style";
export const TAHMEED_PHONE = "0751299364";
export const TAHMEED_PHONE_2 = "0755951417";
export const TAHMEED_EMAIL = "tahmeedbus28@gmail.com";
export const TAHMEED_WHATSAPP_PRIMARY = "254751299364";
export const TAHMEED_LOGO_URL = "https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1783081885012_FB_IMG_1783081764091.jpg";
export const TAHMEED_PRIMARY_COLOR = "#f97316";
export const TAHMEED_PRIMARY_COLOR_DARK = "#ea580c";

// MobileSimulator constants
export const BRAND = {
  name: "Tahmeed Coach",
};

export const CITIES = [
  { id: "nbo", name: "Nairobi", code: "NBO", region: "Central", popular: true },
  { id: "msa", name: "Mombasa", code: "MSA", region: "Coast", popular: true },
  { id: "kis", name: "Kisumu", code: "KIS", region: "Western", popular: false },
  { id: "eld", name: "Eldoret", code: "ELD", region: "Rift Valley", popular: false },
  { id: "nak", name: "Nakuru", code: "NAK", region: "Rift Valley", popular: false },
  { id: "mln", name: "Malindi", code: "MLN", region: "Coast", popular: false },
  { id: "kla", name: "Kampala", code: "KLA", region: "International", popular: true },
  { id: "dar", name: "Dar es Salaam", code: "DAR", region: "International", popular: true },
];

// Paystack payment integration
export const PAYSTACK = {
  PAYMENT_URL: 'https://paystack.shop/pay/x8gm1fm4uu',
  BRAND_COLOR: '#00C244',
  LABEL: 'Pay Now with M-Pesa / Card',
};

export const FEATURES = [
  { icon: "WifiHigh", title: "Free WiFi", description: "Stay connected on the go", color: "#0F4C43" },
  { icon: "PlugCharging", title: "USB Charging", description: "Keep your devices powered", color: "#E29548" },
  { icon: "Users", title: "Comfortable Seats", description: "Spacious legroom for all", color: "#3B82F6" },
  { icon: "Star", title: "Top Rated", description: "4.8/5 customer satisfaction", color: "#F59E0B" },
];