import { useEffect, useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Amenities from './components/Amenities';
import SearchResults from './components/SearchResults';
import BusSeatSelection, { type PassengerInfo } from './components/BusSeatSelection';
import AdminDashboard, { type Booking } from './components/AdminDashboard';
import WhatsAppWidget from './components/WhatsAppWidget';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner';
import {
  ArrowLeft,
  Smartphone,
  Landmark,
  CreditCard,
  Send,
  Copy,
  Check,
  Download,
  Share2,
  QrCode,
  Barcode,
  Bus,
  CalendarCheck,
  Clock,
  ShieldCheck,
  MailCheck,
} from 'lucide-react';
import {
  TAHMEED_PAYBILL_NUMBER,
  TAHMEED_PAYBILL_ACCOUNT,
  TAHMEED_PAYBILL_NUMBER_2,
  TAHMEED_PAYBILL_ACCOUNT_2,
  TAHMEED_TILL_NUMBER,
  TAHMEED_SEND_MONEY_NUMBER,
  TAHMEED_ACCOUNT_PREFIX,
  TAHMEED_SHORT_NAME,
  TAHMEED_STK_SHORTCODE,
} from './constants';
import type { BusResult } from './components/SearchResults';
import { type View, type PaymentMethod } from './types';

function generateRef() {
  return Math.random().toString(36).substring(2, 9).toUpperCase();
}

function App() {
  const [currentView, setCurrentView] = useState<View>("home");
  const [searchParams, setSearchParams] = useState({ from: "", to: "", date: "" });
  const [selectedBus, setSelectedBus] = useState<BusResult | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<number[]>([]);
  const [passengers, setPassengers] = useState<PassengerInfo[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('stk');
  const [stkPhone, setStkPhone] = useState('');
  const [stkStep, setStkStep] = useState<'phone' | 'waiting' | 'pin' | 'confirming' | 'done'>('phone');
  const [stkPin, setStkPin] = useState('');
  const [paybillVerified, setPaybillVerified] = useState<'idle' | 'verifying' | 'done'>('idle');
  const [tillVerified, setTillVerified] = useState<'idle' | 'verifying' | 'done'>('idle');
  const [sendVerified, setSendVerified] = useState<'idle' | 'done'>('idle');
  const [tripRef, setTripRef] = useState('');
  const [allBookings, setAllBookings] = useState<Booking[]>([]);

  useEffect(() => {
    document.title = 'Tahmeed Express - Book Your Next Journey';
  }, []);

  useEffect(() => {
    const handleBookingSuccess = async (event: Event) => {
      const detail = (event as CustomEvent).detail;
      if (!detail) return;

      const emailData = {
        to: 'tahmeedbus28@gmail.com',
        subject: `New Booking Confirmed - ${detail.booking_id}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f9fafb;">
            <div style="background: #f97316; color: white; padding: 20px; border-radius: 12px 12px 0 0; text-align: center;">
              <h1 style="margin: 0; font-size: 22px;">Booking Confirmed!</h1>
              <p style="margin: 4px 0 0; opacity: 0.9;">Tahmeed Express</p>
            </div>
            <div style="background: white; padding: 24px; border-radius: 0 0 12px 12px; border: 1px solid #e5e7eb;">
              <div style="margin-bottom: 20px;">
                <h2 style="font-size: 18px; color: #111827; margin: 0 0 4px;">${detail.passenger_name}</h2>
                <p style="color: #6b7280; margin: 0; font-size: 14px;">${detail.passenger_phone}</p>
              </div>
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-size: 13px;">Booking ID</td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; font-weight: 600; font-size: 13px; text-align: right;">${detail.booking_id}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-size: 13px;">Route</td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; font-weight: 600; font-size: 13px; text-align: right;">${detail.route}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-size: 13px;">Travel Date</td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; font-weight: 600; font-size: 13px; text-align: right;">${detail.travel_date}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-size: 13px;">Seats</td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; font-weight: 600; font-size: 13px; text-align: right;">${detail.seats}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-size: 13px;">Seat Class</td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; font-weight: 600; font-size: 13px; text-align: right;">${detail.seat_class}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-size: 13px;">Boarding Point</td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; font-weight: 600; font-size: 13px; text-align: right;">${detail.boarding_point}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-size: 13px;">Dropping Point</td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; font-weight: 600; font-size: 13px; text-align: right;">${detail.dropping_point}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-size: 13px;">Payment Method</td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; font-weight: 600; font-size: 13px; text-align: right;">${detail.payment_method}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #6b7280; font-size: 13px;">Total Amount</td>
                  <td style="padding: 8px 0; font-weight: 700; font-size: 16px; text-align: right; color: #f97316;">KSh ${detail.total_amount}</td>
                </tr>
              </table>
              <div style="margin-top: 20px; padding-top: 16px; border-top: 2px dashed #e5e7eb; text-align: center; color: #6b7280; font-size: 12px;">
                <p>Booked at: ${detail.booked_at}</p>
                <p style="margin-top: 8px;">Tahmeed Express &mdash; Safe Travels!</p>
              </div>
            </div>
          </div>
        `,
      };

      try {
        const response = await fetch('https://api.mydala.app/send-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(emailData),
        });

        if (!response.ok) {
          const errText = await response.text().catch(() => 'Unknown error');
          toast.error('Booking email could not be sent. Admin will be notified.');
          console.error('Email API error:', response.status, errText);
        } else {
          toast.success('Booking details sent to your email!', {
            icon: <MailCheck className="w-4 h-4 text-emerald-500" />,
          });
        }
      } catch (err) {
        toast.error('Could not send booking email. Please check your connection.');
        console.error('Email fetch error:', err);
      }
    };

    window.addEventListener('dala_booking_success', handleBookingSuccess);
    return () => window.removeEventListener('dala_booking_success', handleBookingSuccess);
  }, []);

  const handleSearch = (query: string) => {
    const [from, to] = query.split(' to ');
    const date = '10 Jun, 2026';
    setSearchParams({ from: from || '', to: to || '', date });
    setCurrentView('search-results');
    window.scrollTo(0, 0);
  };

  const handleSelectBus = useCallback((bus: BusResult) => {
    setSelectedBus(bus);
    setSelectedSeats([]);
    setPassengers([]);
    setCurrentView('seat-passenger');
    window.scrollTo(0, 0);
  }, []);

  const handleSeatToggle = (seatNum: number) => {
    setSelectedSeats((prev) =>
      prev.includes(seatNum) ? prev.filter((s) => s !== seatNum) : [...prev, seatNum]
    );
  };

  const isVipSeat = (seatNum: number) => {
    if (!selectedBus) return false;
    return selectedBus.busClass.includes('VIP') && seatNum <= 12;
  };

  const handlePassengersComplete = (pax: PassengerInfo[]) => {
    setPassengers(pax);
    setCurrentView('payment');
    window.scrollTo(0, 0);
  };

  const handleBackToResults = () => {
    setCurrentView('search-results');
    setSelectedSeats([]);
    setPassengers([]);
    window.scrollTo(0, 0);
  };

  const handleBackFromPayment = () => {
    setCurrentView('seat-passenger');
    window.scrollTo(0, 0);
  };

  const totalPrice = selectedBus
    ? selectedSeats.length * selectedBus.price
    : 0;

  const bookingRef = useRef(generateRef());

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast.success(`${label} copied!`);
    }).catch(() => toast.error('Failed to copy'));
  };

  const completePayment = () => {
    const ref = bookingRef.current;
    setTripRef(ref);

    if (selectedBus && passengers.length > 0) {
      const newBooking: Booking = {
        id: ref,
        passengerName: passengers[0].name,
        passengerCount: passengers.length,
        phone: passengers[0].phone,
        from: selectedBus.from,
        to: selectedBus.to,
        departureTime: selectedBus.departureTime,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setAllBookings(prev => [newBooking, ...prev]);

      toast.info(`Booking Alert: ${newBooking.passengerName}`, {
        description: `${newBooking.from} → ${newBooking.to} | ${newBooking.passengerCount} passenger${newBooking.passengerCount > 1 ? 's' : ''} | ${newBooking.departureTime}`,
        action: {
          label: 'View Dashboard',
          onClick: () => setCurrentView('admin'),
        },
      });

      const seatList = selectedSeats.sort((a, b) => a - b).join(', ');
      const bookingEvent = new CustomEvent('dala_booking_success', {
        detail: {
          booking_id: ref,
          passenger_name: passengers[0].name,
          passenger_phone: passengers[0].phone,
          route: `${selectedBus.from} to ${selectedBus.to}`,
          from: selectedBus.from,
          to: selectedBus.to,
          travel_date: new Date().toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }),
          seats: seatList,
          seat_class: selectedBus.busClass,
          boarding_point: selectedBus.boardingPoints?.[0] || 'Central Bus Station',
          dropping_point: selectedBus.pickupStations?.[0] || 'Central Bus Station',
          total_amount: totalPrice.toLocaleString(),
          payment_method: paymentMethod === 'stk' ? 'M-Pesa STK Push' : paymentMethod === 'paybill' ? 'M-Pesa Paybill' : paymentMethod === 'till' ? 'M-Pesa Till' : 'M-Pesa Send Money',
          booked_at: new Date().toLocaleString('en-KE'),
        },
      });
      window.dispatchEvent(bookingEvent);
    }

    setCurrentView('ticket');
    window.scrollTo(0, 0);
  };

  const handleUpdateBookingStatus = (id: string, status: 'pending' | 'confirmed') => {
    setAllBookings(prev => prev.map(booking => 
      booking.id === id ? { ...booking, status } : booking
    ));
    if (status === 'confirmed') {
      toast.success(`Payment prompt sent! Passenger will receive M-Pesa request shortly.`);
    }
  };

  const handleStkSubmit = () => {
    if (!stkPhone.trim() || !/^(07|01)\d{8}$/.test(stkPhone.trim())) {
      toast.error('Enter a valid Safaricom number (e.g. 0712 345 678)');
      return;
    }
    
    const adminWhatsAppNumber = '254751299364';
    const passengerPhone = stkPhone.trim();
    const passengerName = passengers.length > 0 ? passengers[0].name : 'Customer';
    const route = selectedBus ? `${selectedBus.from} to ${selectedBus.to}` : 'Route';
    const amount = totalPrice.toLocaleString();
    
    if (selectedBus && passengers.length > 0) {
      const pendingBooking: Booking = {
        id: bookingRef.current,
        passengerName: passengers[0].name,
        passengerCount: passengers.length,
        phone: passengerPhone,
        from: selectedBus.from,
        to: selectedBus.to,
        departureTime: selectedBus.departureTime,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'pending',
      };
      setAllBookings(prev => [pendingBooking, ...prev]);
    }

    const nl = String.fromCharCode(10);
    const adminMessage = '*STK Push Request*' + nl + nl + '*Passenger:* ' + passengerName + nl + '*Phone:* ' + passengerPhone + nl + '*Route:* ' + route + nl + '*Amount:* KSh ' + amount + nl + nl + 'Please send M-Pesa prompt to this number manually.';
    
    const whatsappUrl = `https://wa.me/${adminWhatsAppNumber}?text=${encodeURIComponent(adminMessage)}`;
    window.open(whatsappUrl, '_blank');
    
    toast.success('Your number has been sent to admin. Please wait for the M-Pesa prompt.');
    
    setStkStep('waiting');
  };

  const handlePinSubmit = () => {
    if (stkPin.length !== 4 || !/^\d{4}$/.test(stkPin)) {
      toast.error('Enter a valid 4-digit PIN');
      return;
    }
    setStkStep('confirming');
    setTimeout(() => {
      setStkStep('done');
      setTimeout(() => completePayment(), 800);
    }, 2000);
  };

  const resetBooking = () => {
    setCurrentView('home');
    setSelectedBus(null);
    setSelectedSeats([]);
    setPassengers([]);
    setPaymentMethod('stk');
    setStkPhone('');
    setStkPin('');
    setStkStep('phone');
    setPaybillVerified('idle');
    setTillVerified('idle');
    setSendVerified('idle');
    bookingRef.current = generateRef();
    window.scrollTo(0, 0);
  };

  const handlePrintTicket = () => {
    window.print();
    window.print();
  };

  const handleShareToWhatsApp = () => {
    if (!selectedBus || passengers.length === 0) return;

    const nl = String.fromCharCode(10);
    const passengerInfo = passengers.map(p => '  - ' + p.name + ' (' + p.phone + ')').join(nl);
    const passengerCount = passengers.length;

    const message = '*New Tahmeed Booking!*' + nl + nl + '*Route:* ' + selectedBus.from + ' to ' + selectedBus.to + nl + '*Departure:* ' + selectedBus.departureTime + nl + '*Number of Passengers:* ' + passengerCount + nl + '*Passenger Details:*' + nl + passengerInfo + nl + '*Total Fare:* KSh ' + totalPrice.toLocaleString() + nl + '*Ref:* ' + tripRef + nl + nl + '_Please prompt payment for ' + passengerCount + ' passenger' + (passengerCount > 1 ? 's' : '') + ' manually._';

    const adminWhatsAppNumber = '254751299364';
    const whatsappUrl = `https://wa.me/${adminWhatsAppNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    toast.success('Booking details ready to share!');
  };

  const paymentMethods: { key: PaymentMethod; icon: typeof Smartphone; label: string; sub: string }[] = [
    { key: 'stk', icon: Smartphone, label: 'M-Pesa Express', sub: 'STK Push' },
    { key: 'paybill', icon: Landmark, label: 'Paybill', sub: 'Lipa na M-Pesa' },
  ];

  return (
    <div className="min-h-screen bg-white text-[#111827] font-sans selection:bg-[#f97316] selection:text-white p-4">
      <div className="max-w-[600px] mx-auto min-h-screen flex flex-col">
        {currentView === 'home' && (
          <>
            <Navbar currentView={"home"} setView={setCurrentView} />
            <main className="flex-grow">
              <Hero onSearch={handleSearch} />
              <Amenities />
            </main>
            <div className="h-20" />
          </>
        )}

        {currentView === 'search-results' && (
          <SearchResults
            from={searchParams.from}
            to={searchParams.to}
            date={searchParams.date}
            onBack={() => { setCurrentView('home'); window.scrollTo(0, 0); }}
            onSelectBus={handleSelectBus}
          />
        )}

        {currentView === 'seat-passenger' && selectedBus && (
          <div className="bg-white min-h-screen flex flex-col">
            <div className="bg-[#f97316] text-white px-4 py-3 flex items-center gap-3">
              <button
                onClick={handleBackToResults}
                className="p-1.5 -ml-1.5 hover:bg-white/15 rounded-full transition-colors"
              >
                <ArrowLeft className="w-[22px] h-[22px]" />
              </button>
              <div className="flex-1 min-w-0">
                <h1 className="text-[15px] font-bold tracking-tight leading-tight truncate">
                  {selectedBus.from} - {selectedBus.to}
                </h1>
                <p className="text-[12px] text-white/70 leading-tight mt-0.5">
                  {selectedBus.busClass} - {selectedBus.departureTime} - {selectedBus.arrivalTime}
                </p>
              </div>
            </div>

            <div className="px-4 pt-3 pb-1">
              <div className="flex items-center justify-center gap-2 text-[11px] font-semibold">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-[#f97316] text-white flex items-center justify-center text-[10px] font-bold">1</div>
                  <span className="text-[#f97316]">Seats</span>
                </div>
                <div className="w-8 h-px bg-gray-300" />
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center text-[10px] font-bold">2</div>
                  <span className="text-gray-400">Stops</span>
                </div>
                <div className="w-8 h-px bg-gray-300" />
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center text-[10px] font-bold">3</div>
                  <span className="text-gray-400">Details</span>
                </div>
                <div className="w-8 h-px bg-gray-300" />
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center text-[10px] font-bold">4</div>
                  <span className="text-gray-400">Pay</span>
                </div>
              </div>
            </div>

            <div className="flex-1 p-4">
              <BusSeatSelection
                totalSeats={44}
                occupiedSeats={[3, 7, 12, 18, 21, 25, 30, 33, 38, 41]}
                selectedSeats={selectedSeats}
                onSeatToggle={handleSeatToggle}
                basePrice={selectedBus.price}
                vipSurcharge={500}
                isVipSeat={isVipSeat}
                busClass={selectedBus.busClass}
                departureTime={selectedBus.departureTime}
                arrivalTime={selectedBus.arrivalTime}
                from={selectedBus.from}
                to={selectedBus.to}
                boardingPoints={selectedBus.boardingPoints || ['Central Bus Station', 'Main Stage', 'Highway Stop']}
                dropOffPoints={selectedBus.pickupStations || ['Central Bus Station', 'Main Stage', 'Highway Stop']}
                onPassengersComplete={handlePassengersComplete}
                onBack={handleBackToResults}
              />
            </div>
          </div>
        )}

        {currentView === 'payment' && selectedBus && (
          <div className="bg-white min-h-screen flex flex-col">
            <div className="bg-[#f97316] text-white px-4 py-3 flex items-center gap-3">
              <button
                onClick={handleBackFromPayment}
                className="p-1.5 -ml-1.5 hover:bg-white/15 rounded-full transition-colors"
              >
                <ArrowLeft className="w-[22px] h-[22px]" />
              </button>
              <div className="flex-1 min-w-0">
                <h1 className="text-[15px] font-bold tracking-tight leading-tight truncate">Payment</h1>
                <p className="text-[12px] text-white/70 leading-tight mt-0.5">
                  KSh {totalPrice.toLocaleString()} - {selectedSeats.length} seat{selectedSeats.length > 1 ? 's' : ''}
                </p>
              </div>
            </div>

            <div className="px-4 pt-3 pb-1">
              <div className="flex items-center justify-center gap-2 text-[11px] font-semibold">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-[10px] font-bold"><Check className="w-3 h-3" /></div>
                  <span className="text-emerald-600">Seats</span>
                </div>
                <div className="w-6 h-px bg-emerald-400" />
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-[10px] font-bold"><Check className="w-3 h-3" /></div>
                  <span className="text-emerald-600">Stops</span>
                </div>
                <div className="w-6 h-px bg-emerald-400" />
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-[10px] font-bold"><Check className="w-3 h-3" /></div>
                  <span className="text-emerald-600">Details</span>
                </div>
                <div className="w-6 h-px bg-gray-300" />
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-[#f97316] text-white flex items-center justify-center text-[10px] font-bold">4</div>
                  <span className="text-[#f97316]">Pay</span>
                </div>
              </div>
            </div>

            <div className="flex-1 p-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              >
                <h2 className="text-[17px] font-extrabold text-gray-900 mb-1">Choose Payment Method</h2>
                <p className="text-[13px] text-gray-500 mb-4">Select how you'd like to pay KSh {totalPrice.toLocaleString()}</p>

                <div className="grid grid-cols-2 gap-2 mb-5">
                  {paymentMethods.map(({ key, icon: Icon, label, sub }) => (
                    <motion.button
                      key={key}
                      whileTap={{ scale: 0.96 }}
                      onClick={() => setPaymentMethod(key)}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition-all text-center ${
                        paymentMethod === key
                          ? 'border-[#f97316] bg-orange-50 shadow-sm'
                          : 'border-gray-200 bg-white hover:border-gray-300'
                      }`}
                    >
                      <Icon className={`w-5 h-5 ${paymentMethod === key ? 'text-[#f97316]' : 'text-gray-500'}`} />
                      <span className={`text-[12px] font-bold ${paymentMethod === key ? 'text-[#f97316]' : 'text-gray-700'}`}>
                        {label}
                      </span>
                      <span className="text-[10px] text-gray-400">{sub}</span>
                    </motion.button>
                  ))}
                </div>

                <div className="bg-gray-50 rounded-xl border border-gray-200 p-4 mb-4 text-center">
                  <span className="text-[12px] text-gray-500 font-medium">Amount to Pay</span>
                  <div className="text-[28px] font-extrabold text-[#f97316] mt-0.5">
                    KSh {totalPrice.toLocaleString()}
                  </div>
                </div>

                {paymentMethod === 'stk' && (
                  <AnimatePresence mode="wait">
                    {stkStep === 'phone' && (
                      <motion.div
                        key="phone"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="bg-white border-2 border-[#1E824C] rounded-2xl p-4"
                      >
                        <div className="flex items-center gap-2 mb-3">
                          <Smartphone className="w-5 h-5 text-[#1E824C]" />
                          <span className="text-[14px] font-bold text-[#1E824C]">M-Pesa STK Push</span>
                        </div>
                        <p className="text-[12px] text-gray-500 mb-3">
                          Enter your Safaricom number. Our admin will send the M-Pesa prompt to your phone.
                        </p>
                        <label className="block text-[12px] font-semibold text-gray-700 mb-1">Safaricom Number</label>
                        <input
                          type="tel"
                          value={stkPhone}
                          onChange={(e) => setStkPhone(e.target.value)}
                          placeholder="e.g. 0712 345 678"
                          className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-[13px] focus:outline-none focus:ring-2 focus:ring-[#1E824C]/20 focus:border-[#1E824C] mb-3"
                        />
                        <motion.button
                          whileTap={{ scale: 0.97 }}
                          onClick={handleStkSubmit}
                          className="w-full bg-[#1E824C] text-white rounded-full py-2.5 text-[14px] font-bold hover:bg-[#166b3c] transition-colors"
                        >
                          Request M-Pesa Prompt
                        </motion.button>
                      </motion.div>
                    )}

                    {stkStep === 'waiting' && (
                      <motion.div
                        key="waiting"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="bg-white border-2 border-[#1E824C] rounded-2xl p-4"
                      >
                        <div className="flex items-center gap-2 mb-3">
                          <Smartphone className="w-5 h-5 text-[#1E824C]" />
                          <span className="text-[14px] font-bold text-[#1E824C]">Waiting for Admin Prompt</span>
                        </div>
                        <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 mb-3">
                          <p className="text-[12px] text-emerald-700 font-semibold mb-1">&check; Your number has been shared with admin</p>
                          <p className="text-[11px] text-emerald-600">Phone: {stkPhone}</p>
                        </div>
                        <p className="text-[12px] text-gray-600 mb-3">
                          Please wait for the M-Pesa prompt on your phone. The admin will send it manually.
                        </p>
                        <div className="flex items-center gap-2 mb-4">
                          <motion.div
                            animate={{ scale: [1, 1.2, 1] }}
                            transition={{ repeat: Infinity, duration: 1.5 }}
                            className="w-3 h-3 rounded-full bg-[#1E824C]"
                          />
                          <span className="text-[11px] text-gray-500">Admin has been notified...</span>
                        </div>
                        <motion.button
                          whileTap={{ scale: 0.97 }}
                          onClick={() => setStkStep('pin')}
                          className="w-full bg-[#1E824C] text-white rounded-full py-2.5 text-[14px] font-bold hover:bg-[#166b3c] transition-colors"
                        >
                          I Received the Prompt - Enter PIN
                        </motion.button>
                        <button
                          onClick={() => setStkStep('phone')}
                          className="w-full text-[12px] text-gray-500 mt-2 hover:text-gray-700"
                        >
                          Change phone number
                        </button>
                      </motion.div>
                    )}

                    {stkStep === 'pin' && (
                      <motion.div
                        key="pin"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
                      >
                        <div className="bg-[#1a1a1a] rounded-2xl w-full max-w-[320px] overflow-hidden shadow-2xl border border-gray-700">
                          <div className="bg-[#1E824C] px-5 py-3 flex items-center justify-between">
                            <span className="text-white text-[14px] font-bold">M-PESA</span>
                            <span className="text-white/70 text-[11px]">{TAHMEED_STK_SHORTCODE}</span>
                          </div>
                          <div className="p-5">
                            <p className="text-white/80 text-[12px] mb-1">Pay KSh {totalPrice.toLocaleString()} to</p>
                            <p className="text-white text-[15px] font-bold mb-4">{TAHMEED_SHORT_NAME} COACH</p>
                            <label className="block text-[11px] text-white/60 mb-1">Enter M-Pesa PIN:</label>
                            <input
                              type="password"
                              maxLength={4}
                              value={stkPin}
                              onChange={(e) => setStkPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                              className="w-full bg-gray-800 text-white text-center text-[20px] font-bold tracking-[0.3em] py-3 rounded-lg border border-gray-600 focus:outline-none focus:border-[#1E824C] mb-1"
                              placeholder="****"
                              autoFocus
                            />
                            <div className="flex gap-2 mt-4">
                              <button
                                onClick={() => { setStkStep('phone'); setStkPin(''); }}
                                className="flex-1 text-white/60 text-[13px] font-semibold py-2 rounded-lg border border-gray-600 hover:bg-gray-800 transition-colors"
                              >
                                Cancel
                              </button>
                              <motion.button
                                whileTap={{ scale: 0.96 }}
                                onClick={handlePinSubmit}
                                className="flex-1 bg-[#1E824C] text-white text-[13px] font-bold py-2 rounded-lg hover:bg-[#166b3c] transition-colors"
                              >
                                Confirm
                              </motion.button>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {stkStep === 'confirming' && (
                      <motion.div
                        key="confirming"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
                      >
                        <div className="bg-[#1a1a1a] rounded-2xl w-full max-w-[320px] p-6 text-center border border-gray-700">
                          <motion.div
                            animate={{ scale: [1, 1.1, 1] }}
                            transition={{ repeat: Infinity, duration: 1.5 }}
                            className="w-12 h-12 rounded-full bg-[#1E824C]/20 flex items-center justify-center mx-auto mb-3"
                          >
                            <div className="w-6 h-6 rounded-full border-2 border-[#1E824C] border-t-transparent animate-spin" />
                          </motion.div>
                          <p className="text-white font-bold text-[15px] mb-1">Processing Payment</p>
                          <p className="text-white/50 text-[12px]">Please wait...</p>
                        </div>
                      </motion.div>
                    )}

                    {stkStep === 'done' && (
                      <motion.div
                        key="done"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-center"
                      >
                        <Check className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                        <p className="text-[14px] font-bold text-emerald-700">Payment Successful!</p>
                        <p className="text-[12px] text-emerald-600">Redirecting to your ticket...</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                )}

                {paymentMethod === 'paybill' && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white border-2 border-[#1E824C] rounded-2xl p-4"
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <Landmark className="w-5 h-5 text-[#1E824C]" />
                      <span className="text-[14px] font-bold text-[#1E824C]">Lipa na M-Pesa Paybill</span>
                    </div>
                    
                    <div className="mb-4">
                      <div className="text-[12px] font-semibold text-gray-700 mb-2">Option 1</div>
                      <div className="flex flex-col gap-2">
                        <div className="bg-gray-50 rounded-lg p-3">
                          <span className="text-[11px] text-gray-500 font-medium">Business Number</span>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-[16px] font-extrabold text-gray-900">{TAHMEED_PAYBILL_NUMBER}</span>
                            <button
                              onClick={() => copyToClipboard(TAHMEED_PAYBILL_NUMBER, 'Paybill number')}
                              className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors"
                            >
                              <Copy className="w-4 h-4 text-gray-500" />
                            </button>
                          </div>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-3">
                          <span className="text-[11px] text-gray-500 font-medium">Account Number</span>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-[16px] font-extrabold text-gray-900">{TAHMEED_PAYBILL_ACCOUNT}</span>
                            <button
                              onClick={() => copyToClipboard(TAHMEED_PAYBILL_ACCOUNT, 'Account number')}
                              className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors"
                            >
                              <Copy className="w-4 h-4 text-gray-500" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="text-[12px] font-semibold text-gray-700 mb-2">Option 2</div>
                      <div className="flex flex-col gap-2">
                        <div className="bg-gray-50 rounded-lg p-3">
                          <span className="text-[11px] text-gray-500 font-medium">Business Number</span>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-[16px] font-extrabold text-gray-900">{TAHMEED_PAYBILL_NUMBER_2}</span>
                            <button
                              onClick={() => copyToClipboard(TAHMEED_PAYBILL_NUMBER_2, 'Paybill number')}
                              className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors"
                            >
                              <Copy className="w-4 h-4 text-gray-500" />
                            </button>
                          </div>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-3">
                          <span className="text-[11px] text-gray-500 font-medium">Account Number</span>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-[16px] font-extrabold text-gray-900">{TAHMEED_PAYBILL_ACCOUNT_2}</span>
                            <button
                              onClick={() => copyToClipboard(TAHMEED_PAYBILL_ACCOUNT_2, 'Account number')}
                              className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors"
                            >
                              <Copy className="w-4 h-4 text-gray-500" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-gray-50 rounded-lg p-3 mb-3">
                      <span className="text-[11px] text-gray-500 font-medium">Amount</span>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-[18px] font-extrabold text-gray-900">KSh {totalPrice.toLocaleString()}</span>
                        <button
                          onClick={() => copyToClipboard(String(totalPrice), 'Amount')}
                          className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors"
                        >
                          <Copy className="w-4 h-4 text-gray-500" />
                        </button>
                      </div>
                    </div>
                    {paybillVerified === 'idle' && (
                      <motion.button
                        whileTap={{ scale: 0.97 }}
                        onClick={() => {
                          setPaybillVerified('verifying');
                          setTimeout(() => {
                            setPaybillVerified('done');
                            setTimeout(() => completePayment(), 800);
                          }, 1500);
                        }}
                        className="w-full mt-4 bg-[#1E824C] text-white rounded-full py-2.5 text-[14px] font-bold hover:bg-[#166b3c] transition-colors"
                      >
                        Verify Paybill Payment
                      </motion.button>
                    )}
                    {paybillVerified === 'verifying' && (
                      <div className="mt-4 text-center">
                        <div className="w-6 h-6 rounded-full border-2 border-[#1E824C] border-t-transparent animate-spin mx-auto mb-2" />
                        <p className="text-[12px] text-gray-500">Verifying payment...</p>
                      </div>
                    )}
                    {paybillVerified === 'done' && (
                      <div className="mt-4 bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-center">
                        <Check className="w-6 h-6 text-emerald-500 mx-auto mb-1" />
                        <p className="text-[12px] font-bold text-emerald-700">Payment verified!</p>
                      </div>
                    )}
                  </motion.div>
                )}

                {paymentMethod === 'till' && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white border-2 border-[#1E824C] rounded-2xl p-4"
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <CreditCard className="w-5 h-5 text-[#1E824C]" />
                      <span className="text-[14px] font-bold text-[#1E824C]">Lipa na M-Pesa Buy Goods</span>
                    </div>
                    <div className="flex flex-col gap-3">
                      <div className="bg-gray-50 rounded-lg p-3">
                        <span className="text-[11px] text-gray-500 font-medium">Till Number</span>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-[18px] font-extrabold text-gray-900">{TAHMEED_TILL_NUMBER}</span>
                          <button
                            onClick={() => copyToClipboard(TAHMEED_TILL_NUMBER, 'Till number')}
                            className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors"
                          >
                            <Copy className="w-4 h-4 text-gray-500" />
                          </button>
                        </div>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <span className="text-[11px] text-gray-500 font-medium">Amount</span>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-[18px] font-extrabold text-gray-900">KSh {totalPrice.toLocaleString()}</span>
                          <button
                            onClick={() => copyToClipboard(String(totalPrice), 'Amount')}
                            className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors"
                          >
                            <Copy className="w-4 h-4 text-gray-500" />
                          </button>
                        </div>
                      </div>
                    </div>
                    {tillVerified === 'idle' && (
                      <motion.button
                        whileTap={{ scale: 0.97 }}
                        onClick={() => {
                          setTillVerified('verifying');
                          setTimeout(() => {
                            setTillVerified('done');
                            setTimeout(() => completePayment(), 800);
                          }, 1500);
                        }}
                        className="w-full mt-4 bg-[#1E824C] text-white rounded-full py-2.5 text-[14px] font-bold hover:bg-[#166b3c] transition-colors"
                      >
                        Verify Till Payment
                      </motion.button>
                    )}
                    {tillVerified === 'verifying' && (
                      <div className="mt-4 text-center">
                        <div className="w-6 h-6 rounded-full border-2 border-[#1E824C] border-t-transparent animate-spin mx-auto mb-2" />
                        <p className="text-[12px] text-gray-500">Verifying payment...</p>
                      </div>
                    )}
                    {tillVerified === 'done' && (
                      <div className="mt-4 bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-center">
                        <Check className="w-6 h-6 text-emerald-500 mx-auto mb-1" />
                        <p className="text-[12px] font-bold text-emerald-700">Payment verified!</p>
                      </div>
                    )}
                  </motion.div>
                )}

                {paymentMethod === 'send' && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white border-2 border-[#1E824C] rounded-2xl p-4"
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <Send className="w-5 h-5 text-[#1E824C]" />
                      <span className="text-[14px] font-bold text-[#1E824C]">Send Money</span>
                    </div>
                    <p className="text-[12px] text-gray-500 mb-3">
                      Send the exact amount to the official Tahmeed Finance number via M-Pesa.
                    </p>
                    <div className="flex flex-col gap-3">
                      <div className="bg-gray-50 rounded-lg p-3">
                        <span className="text-[11px] text-gray-500 font-medium">Send to</span>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-[18px] font-extrabold text-gray-900">{TAHMEED_SEND_MONEY_NUMBER}</span>
                          <button
                            onClick={() => copyToClipboard(TAHMEED_SEND_MONEY_NUMBER, 'Phone number')}
                            className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors"
                          >
                            <Copy className="w-4 h-4 text-gray-500" />
                          </button>
                        </div>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <span className="text-[11px] text-gray-500 font-medium">Amount</span>
                        <span className="block text-[18px] font-extrabold text-gray-900 mt-1">KSh {totalPrice.toLocaleString()}</span>
                      </div>
                    </div>
                    {sendVerified === 'idle' && (
                      <motion.button
                        whileTap={{ scale: 0.97 }}
                        onClick={() => {
                          setSendVerified('done');
                          setTimeout(() => completePayment(), 1000);
                        }}
                        className="w-full mt-4 bg-[#1E824C] text-white rounded-full py-2.5 text-[14px] font-bold hover:bg-[#166b3c] transition-colors"
                      >
                        I've Sent the Money
                      </motion.button>
                    )}
                    {sendVerified === 'done' && (
                      <div className="mt-4 bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-center">
                        <Check className="w-6 h-6 text-emerald-500 mx-auto mb-1" />
                        <p className="text-[12px] font-bold text-emerald-700">Payment confirmed!</p>
                      </div>
                    )}
                  </motion.div>
                )}
              </motion.div>
            </div>
          </div>
        )}

        {currentView === 'ticket' && selectedBus && (
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="bg-white min-h-screen flex flex-col"
          >
            <div className="bg-emerald-600 text-white px-4 py-3 flex items-center gap-3">
              <div className="flex-1">
                <h1 className="text-[15px] font-bold tracking-tight leading-tight">Your Ticket</h1>
                <p className="text-[12px] text-white/70 leading-tight mt-0.5">
                  Booking Ref: {tripRef}
                </p>
              </div>
              <button onClick={handlePrintTicket} className="p-2 hover:bg-white/15 rounded-full transition-colors">
                <Download className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 p-4">
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                className="bg-white border-2 border-gray-200 rounded-2xl overflow-hidden shadow-lg"
              >
                <div className="bg-gradient-to-r from-orange-500 to-orange-600 p-4 text-white">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-[13px] font-bold opacity-80">TAHMEED EXPRESS</h2>
                      <p className="text-[10px] opacity-60">Coach Services</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] opacity-60">Booking Ref</p>
                      <p className="text-[13px] font-bold">{tripRef}</p>
                    </div>
                  </div>
                  <div className="text-center border-t border-white/20 pt-3">
                    <p className="text-[18px] font-extrabold">{selectedBus.from} &rarr; {selectedBus.to}</p>
                    <p className="text-[11px] opacity-80 mt-1">{selectedBus.departureTime} - {selectedBus.arrivalTime}</p>
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="bg-gray-100 p-2 rounded-lg">
                      <QrCode className="w-12 h-12 text-gray-600" />
                    </div>
                    <div className="flex-1 text-[11px] text-gray-500">
                      <p className="font-semibold text-gray-700 mb-1">Scan this code at boarding</p>
                      <p>Show this ticket to the conductor when boarding.</p>
                    </div>
                  </div>

                  <div className="border-t border-dashed border-gray-200 pt-3 mb-3">
                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div>
                        <span className="text-gray-500">Passenger</span>
                        <p className="font-semibold text-gray-800">{passengers[0]?.name}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Phone</span>
                        <p className="font-semibold text-gray-800">{passengers[0]?.phone}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Seats</span>
                        <p className="font-semibold text-gray-800">
                          {selectedSeats.sort((a, b) => a - b).join(', ')}
                        </p>
                      </div>
                      <div>
                        <span className="text-gray-500">Class</span>
                        <p className="font-semibold text-gray-800">{selectedBus.busClass}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Date</span>
                        <p className="font-semibold text-gray-800">{searchParams.date || 'Today'}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Payment</span>
                        <p className="font-semibold text-gray-800">
                          {paymentMethod === 'stk' ? 'M-Pesa' : paymentMethod === 'paybill' ? 'Paybill' : 'Till'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-3 flex items-center justify-between">
                    <span className="text-[13px] text-gray-500">Total Paid</span>
                    <span className="text-[18px] font-extrabold text-[#f97316]">KSh {totalPrice.toLocaleString()}</span>
                  </div>

                  <div className="flex gap-2 mt-4">
                    <motion.button
                      whileTap={{ scale: 0.97 }}
                      onClick={handlePrintTicket}
                      className="flex-1 flex items-center justify-center gap-1.5 border-2 border-gray-200 text-gray-700 rounded-full py-2.5 text-[12px] font-bold hover:bg-gray-50 transition-colors"
                    >
                      <Download className="w-4 h-4" />
                      Download
                    </motion.button>
                    <motion.button
                      whileTap={{ scale: 0.97 }}
                      onClick={handleShareToWhatsApp}
                      className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-500 text-white rounded-full py-2.5 text-[12px] font-bold hover:bg-emerald-600 transition-colors"
                    >
                      <Share2 className="w-4 h-4" />
                      Share
                    </motion.button>
                  </div>
                </div>
              </motion.div>

              <div className="text-center mt-6">
                <motion.button
                  whileTap={{ scale: 0.97 }}
                  onClick={resetBooking}
                  className="bg-[#f97316] text-white rounded-full px-8 py-2.5 text-[14px] font-bold hover:bg-[#e8630a] transition-colors"
                >
                  Book Another Trip
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}

        {currentView === 'admin' && (
          <AdminDashboard
            bookings={allBookings}
            onBack={() => setCurrentView('home')}
            onUpdateBookingStatus={handleUpdateBookingStatus}
          />
        )}

        <Toaster />
        <WhatsAppWidget />
      </div>
    </div>
  );
}

export default App;