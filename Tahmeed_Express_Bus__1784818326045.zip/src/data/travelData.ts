export interface Station {
  id: string;
  name: string;
  city: string;
  description: string;
  image: string;
  rating: number;
  category: 'Main Hub' | 'Satellite' | 'Terminal' | 'Stopover';
}

export interface PaymentMethod {
  id: string;
  name: string;
  type: 'mobile' | 'card' | 'bank';
  description: string;
}

export interface PassengerDetail {
  name: string;
  phone: string;
  idNumber: string;
  seatNumber?: number;
}

export interface BusRoute {
  id: string;
  title: string;
  origin: string;
  destination: string;
  price: number;
  duration: string;
  departureTime: string;
  image: string;
  rating: number;
  features: string[];
  availablePaymentMethods?: PaymentMethod[];
  busType?: 'VIP' | 'Executive' | 'Standard';
  totalSeats?: number;
  occupiedSeats?: number[];
  seatsLeft?: number;
  boardingPoints?: string[];
  pickupStations?: string[];
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  image: string;
  date: string;
  author: string;
  category: string;
}

// New high-quality image assets
export const IMAGES = {
  PRIMARY_BANNER: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1778078671764_IMG-20260506-WA0005.jpg',
  FLEET_FRONT: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1778078671289_1778078624300.jpg',
  BOOKING_OFFICE: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1778078671760_IMG-20260506-WA0001.jpg',
  ROAD_BUS: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1778078671323_1778078613633.jpg',
  REAR_BUS: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1778078671285_1778078635068.jpg',
  MARKET_BUS: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1778078670832_1778078608783.jpg',
  SCHEDULE_AD: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1778078671759_IMG-20260506-WA0002.jpg',
  INTERIOR: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/7f901b81-3f15-47f9-8c28-202789f34fc0/tahmeed-bus-interior-1-995040ef-1778074763631.webp',
  FLEET_COACH: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1784409254863_images.jpeg',
  SLEEPER_CABIN: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/f42895c6-cbf2-4557-bbdd-bb2f6288d912/1784409254864_images__1_.jpeg'
};

export const DEFAULT_PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: 'whatsapp',
    name: 'WhatsApp Booking',
    type: 'mobile',
    description: 'Complete payment and confirm ticket via WhatsApp'
  }
];

const initialStations: Station[] = [
  {
    id: 's1',
    name: 'Nairobi Central Terminal',
    city: 'Nairobi',
    description: 'Our primary hub in the heart of Nairobi (River Road), equipped with VIP lounges and 24/7 security.',
    image: IMAGES.PRIMARY_BANNER,
    rating: 4.8,
    category: 'Main Hub'
  },
  {
    id: 's2',
    name: 'Mombasa Jomo Kenyatta Ave',
    city: 'Mombasa',
    description: 'Conveniently located near the port, serving all coastal routes with modern facilities.',
    image: IMAGES.FLEET_FRONT,
    rating: 4.9,
    category: 'Terminal'
  },
  {
    id: 's3',
    name: 'Malindi Branch',
    city: 'Malindi',
    description: 'The gateway to the North Coast, providing reliable connections to Lamu and Nairobi.',
    image: IMAGES.ROAD_BUS,
    rating: 4.7,
    category: 'Terminal'
  },
  {
    id: 's4',
    name: 'Kisumu City Terminal',
    city: 'Kisumu',
    description: 'Serving the lake region with daily executive departures to Mombasa and Nairobi.',
    image: IMAGES.BOOKING_OFFICE,
    rating: 4.9,
    category: 'Terminal'
  },
  {
    id: 's5',
    name: 'Eldoret Town Office',
    city: 'Eldoret',
    description: 'Strategic hub for the Rift Valley and North Rift region travelers.',
    image: IMAGES.REAR_BUS,
    rating: 4.6,
    category: 'Satellite'
  },
  {
    id: 's6',
    name: 'Nakuru Highway Stop',
    city: 'Nakuru',
    description: 'Major stopover point with clean facilities and refreshment areas.',
    image: IMAGES.MARKET_BUS,
    rating: 4.5,
    category: 'Stopover'
  },
  {
    id: 's7',
    name: 'Busia Border Point',
    city: 'Busia',
    description: 'Crucial terminal for cross-border travelers between Kenya and Uganda.',
    image: IMAGES.ROAD_BUS,
    rating: 4.7,
    category: 'Terminal'
  },
  {
    id: 's8',
    name: 'Kitale Terminal',
    city: 'Kitale',
    description: 'Providing luxury travel options for the agricultural hub of Western Kenya.',
    image: IMAGES.FLEET_FRONT,
    rating: 4.6,
    category: 'Satellite'
  },
  {
    id: 's9',
    name: 'Kilifi Office',
    city: 'Kilifi',
    description: 'Serving the beautiful coastal town of Kilifi with reliable daily connections.',
    image: IMAGES.ROAD_BUS,
    rating: 4.5,
    category: 'Terminal'
  },
  {
    id: 's10',
    name: 'Lamu Manda Terminal',
    city: 'Lamu',
    description: 'The end point for our coastal express, connecting travelers to the historic Lamu island.',
    image: IMAGES.REAR_BUS,
    rating: 4.8,
    category: 'Terminal'
  },
  {
    id: 's11',
    name: 'Bungoma Town Center',
    city: 'Bungoma',
    description: 'A key transit point in Western Kenya for travelers heading to Uganda and beyond.',
    image: IMAGES.MARKET_BUS,
    rating: 4.4,
    category: 'Terminal'
  },
  {
    id: 's12',
    name: 'Kakamega Terminal',
    city: 'Kakamega',
    description: 'Connecting the heart of Western Kenya to the capital and the coast.',
    image: IMAGES.FLEET_FRONT,
    rating: 4.6,
    category: 'Terminal'
  },
  {
    id: 's13',
    name: 'Machakos Junction',
    city: 'Machakos',
    description: 'Vital stopover and connection point for Eastern region travelers.',
    image: IMAGES.ROAD_BUS,
    rating: 4.3,
    category: 'Stopover'
  },
  {
    id: 's14',
    name: 'Voi Highway Office',
    city: 'Voi',
    description: 'Strategic stopover between Nairobi and Mombasa with refreshment services.',
    image: IMAGES.REAR_BUS,
    rating: 4.5,
    category: 'Stopover'
  },
  {
    id: 's15',
    name: 'Meru Town Terminal',
    city: 'Meru',
    description: 'Expanding our footprint in Upper Eastern with daily luxury departures.',
    image: IMAGES.ROAD_BUS,
    rating: 4.7,
    category: 'Terminal'
  },
  {
    id: 's16',
    name: 'Kisii Stage Terminal',
    city: 'Kisii',
    description: 'Key terminal for South Nyanza region with daily trips to the coast.',
    image: IMAGES.FLEET_FRONT,
    rating: 4.8,
    category: 'Terminal'
  },
  {
    id: 's17',
    name: 'Kampala New Bus Park',
    city: 'Kampala',
    description: "International terminal connecting Kenya to Uganda's capital city with daily cross-border services.",
    image: IMAGES.ROAD_BUS,
    rating: 4.6,
    category: 'Terminal'
  },
  {
    id: 's18',
    name: 'Dar es Salaam Mwenge Terminal',
    city: 'Dar es Salaam',
    description: "Tanzania's largest city terminal offering seamless connections from Nairobi and Mombasa.",
    image: IMAGES.FLEET_FRONT,
    rating: 4.7,
    category: 'Terminal'
  }
];

export const KENYA_COUNTIES = [
  "Mombasa", "Kwale", "Kilifi", "Tana River", "Lamu", "Taita-Taveta", "Garissa", "Wajir", "Mandera", "Marsabit", "Isiolo", "Meru", "Tharaka-Nithi", "Embu", "Kitui", "Machakos", "Makueni", "Nyandarua", "Nyeri", "Kirinyaga", "Murang'a", "Kiambu", "Turkana", "West Pokot", "Samburu", "Trans-Nzoia", "Uasin Gishu", "Elgeyo-Marakwet", "Nandi", "Baringo", "Laikipia", "Nakuru", "Narok", "Kajiado", "Kericho", "Bomet", "Kakamega", "Vihiga", "Bungoma", "Busia", "Siaya", "Kisumu", "Homa Bay", "Migori", "Kisii", "Nyamira", "Nairobi"
];

export const INTERNATIONAL_DESTINATIONS = ["Kampala", "Dar es Salaam"];
export const ALL_DESTINATIONS = [...KENYA_COUNTIES, ...INTERNATIONAL_DESTINATIONS];

const existingCities = new Set(initialStations.map(s => s.city.toLowerCase()));
const extraStations: Station[] = KENYA_COUNTIES
  .filter(c => !existingCities.has(c.toLowerCase()))
  .map((county, idx) => ({
    id: `ext-s-${idx}`,
    name: `${county} County Terminal`,
    city: county,
    description: `Connecting ${county} to our nationwide network with safe and efficient bus services.`,
    image: IMAGES.MARKET_BUS,
    rating: 4.5,
    category: 'Terminal'
  }));

export const stations: Station[] = [...initialStations, ...extraStations];

const getBasePrice = (origin: string, dest: string) => {
  if (origin === dest) return 0;
  
  // International routes - realistic pricing
  if (origin === 'Kampala' || dest === 'Kampala') {
    if (origin === 'Nairobi' || dest === 'Nairobi') return 2500;
    if (origin === 'Mombasa' || dest === 'Mombasa') return 3500;
    if (origin === 'Kisumu' || dest === 'Kisumu') return 2200;
    if (origin === 'Eldoret' || dest === 'Eldoret') return 2400;
    if (origin === 'Busia' || dest === 'Busia') return 2300;
    if (origin === 'Malindi' || dest === 'Malindi') return 3200;
    return 2800;
  }
  
  if (origin === 'Dar es Salaam' || dest === 'Dar es Salaam') {
    if (origin === 'Nairobi' || dest === 'Nairobi') return 3000;
    if (origin === 'Mombasa' || dest === 'Mombasa') return 2000;
    if (origin === 'Kisumu' || dest === 'Kisumu') return 3500;
    if (origin === 'Malindi' || dest === 'Malindi') return 2200;
    if (origin === 'Eldoret' || dest === 'Eldoret') return 3800;
    return 3200;
  }
  
  // Mombasa routes - specific pricing based on distance
  if (origin === 'Mombasa' || dest === 'Mombasa') {
    const other = origin === 'Mombasa' ? dest : origin;
    
    // Nairobi - 480km
    if (other === 'Nairobi') return 1200;
    
    // Coastal region - short distances
    if (['Kwale', 'Kilifi', 'Tana River', 'Lamu', 'Malindi', 'Voi'].includes(other)) return 600;
    if (other === 'Taita-Taveta') return 800;
    
    // Eastern region
    if (['Machakos', 'Makueni', 'Kitui', 'Embu', 'Tharaka-Nithi'].includes(other)) return 1200;
    if (other === 'Meru') return 2000;
    if (['Isiolo', 'Marsabit'].includes(other)) return 2200;
    
    // Central region
    if (['Kiambu', "Murang'a", 'Nyeri', 'Kirinyaga', 'Nyandarua'].includes(other)) return 1300;
    
    // Rift Valley - user specified 1,500 for some
    if (['Nakuru', 'Kericho', 'Narok', 'Kajiado'].includes(other)) return 1500;
    if (['Bomet'].includes(other)) return 1600;
    if (['Eldoret', 'Kitale', 'Trans-Nzoia'].includes(other)) return 2200;
    if (['Uasin Gishu', 'Nandi', 'Baringo', 'Elgeyo-Marakwet'].includes(other)) return 2000;
    if (['Turkana', 'West Pokot', 'Samburu', 'Laikipia'].includes(other)) return 2400;
    
    // Western region - user specified prices
    if (['Kisumu', 'Homa Bay', 'Homabay', 'Oyugis', 'Ugunja'].includes(other)) return 2000;
    if (['Kisii', 'Nyamira'].includes(other)) return 1500;
    if (['Kakamega', 'Vihiga', 'Bungoma', 'Busia'].includes(other)) return 2200;
    if (['Siaya', 'Migori'].includes(other)) return 2100;
    
    return 1800;
  }
  
  // Nairobi routes
  if (origin === 'Nairobi' || dest === 'Nairobi') {
    const other = origin === 'Nairobi' ? dest : origin;
    
    // Coastal
    if (['Mombasa', 'Kwale', 'Kilifi', 'Tana River', 'Lamu', 'Malindi'].includes(other)) return 1200;
    if (other === 'Voi' || other === 'Taita-Taveta') return 800;
    
    // Central region - short distances
    if (['Kiambu', "Murang'a", 'Machakos', 'Makueni'].includes(other)) return 500;
    if (['Nyeri', 'Kirinyaga', 'Nyandarua', 'Embu'].includes(other)) return 700;
    if (other === 'Tharaka-Nithi') return 800;
    
    // Eastern
    if (other === 'Meru') return 1000;
    if (['Isiolo', 'Marsabit'].includes(other)) return 1200;
    if (other === 'Kitui') return 900;
    
    // Rift Valley
    if (other === 'Nakuru') return 800;
    if (['Kajiado', 'Narok'].includes(other)) return 700;
    if (['Kericho', 'Bomet'].includes(other)) return 1000;
    if (['Eldoret', 'Kitale', 'Uasin Gishu', 'Trans-Nzoia'].includes(other)) return 1200;
    if (['Nandi', 'Baringo', 'Elgeyo-Marakwet', 'Laikipia'].includes(other)) return 1100;
    if (['Turkana', 'West Pokot', 'Samburu'].includes(other)) return 1400;
    
    // Western
    if (['Kisumu', 'Siaya'].includes(other)) return 1200;
    if (['Kakamega', 'Vihiga', 'Bungoma', 'Busia'].includes(other)) return 1300;
    if (['Kisii', 'Nyamira', 'Homa Bay', 'Migori'].includes(other)) return 1200;
    
    return 1000;
  }

  const regions: Record<string, string[]> = {
    coastal: ["Mombasa", "Kwale", "Kilifi", "Tana River", "Lamu", "Taita-Taveta", "Voi", "Malindi", "Bamburi"],
    western: ["Kakamega", "Vihiga", "Bungoma", "Busia", "Kisumu", "Siaya", "Homa Bay", "Migori", "Kisii", "Nyamira", "Bomet", "Kericho", "Webuye", "Ugunja", "Homabay", "Oyugis"],
    rift: ["Turkana", "West Pokot", "Samburu", "Trans-Nzoia", "Uasin Gishu", "Elgeyo-Marakwet", "Nandi", "Baringo", "Laikipia", "Nakuru", "Narok", "Kajiado", "Eldoret", "Kitale", "Kapsabet"],
    central: ["Nyandarua", "Nyeri", "Kirinyaga", "Murang'a", "Kiambu", "Nairobi"],
    eastern: ["Marsabit", "Isiolo", "Meru", "Tharaka-Nithi", "Embu", "Kitui", "Machakos", "Makueni"]
  };

  const getRegion = (city: string) => {
    for (const [region, cities] of Object.entries(regions)) {
      if (cities.includes(city)) return region;
    }
    return 'other';
  };

  const r1 = getRegion(origin);
  const r2 = getRegion(dest);

  // Inter-region pricing (realistic based on distance)
  if (r1 === r2) return 600;
  if ((r1 === 'coastal' && r2 === 'western') || (r1 === 'western' && r2 === 'coastal')) return 2200;
  if ((r1 === 'central' && r2 === 'coastal') || (r1 === 'coastal' && r2 === 'central')) return 1200;
  if ((r1 === 'central' && r2 === 'western') || (r1 === 'western' && r2 === 'central')) return 1200;
  if ((r1 === 'central' && r2 === 'rift') || (r1 === 'rift' && r2 === 'central')) return 900;
  if ((r1 === 'eastern' && r2 === 'central') || (r1 === 'central' && r2 === 'eastern')) return 900;
  if ((r1 === 'eastern' && r2 === 'coastal') || (r1 === 'coastal' && r2 === 'eastern')) return 1500;
  if ((r1 === 'coastal' && r2 === 'rift') || (r1 === 'rift' && r2 === 'coastal')) return 1800;
  if ((r1 === 'western' && r2 === 'rift') || (r1 === 'rift' && r2 === 'western')) return 1200;
  if ((r1 === 'eastern' && r2 === 'western') || (r1 === 'western' && r2 === 'eastern')) return 1600;
  if ((r1 === 'eastern' && r2 === 'rift') || (r1 === 'rift' && r2 === 'eastern')) return 1300;

  return 1400;
};

export const HUB_CITIES = [
  "Nairobi", "Mombasa", "Kisumu", "Eldoret", "Nakuru", "Malindi", "Voi", "Busia", "Kampala", "Dar es Salaam"
];

const BOARDING_POINTS: Record<string, { boarding: string[]; pickup: string[] }> = {
  'Nairobi': {
    boarding: ['River Road Terminal', 'Ambassadeur Hotel', 'Easy Coach Terminal', 'River Road Stage'],
    pickup: ['CBD - River Road', 'Westlands - Sarit Centre', 'Eastleigh - Garissa Lodge', 'Ngong Road - Yaya Centre', 'Thika Road - Garden City', 'Mombasa Road - Junction Mall']
  },
  'Mombasa': {
    boarding: ['Digo Road Terminal', 'Mwembe Tayari', 'Nyali Centre', 'Bamburi Beach', 'Changamwe Stage', 'Likoni Ferry', 'Mtwapa Stage'],
    pickup: ['CBD - Digo Road', 'Mwembe Tayari - Stage', 'Nyali - Mombasa Mall', 'Bamburi - Stage', 'Changamwe - Highway', 'Likoni - Ferry Point', 'Mtwapa - Stage', 'Kilifi - Bridge']
  },
  'Kisumu': {
    boarding: ['Kibuye Market Stage', 'Oginga Odinga Street', 'Milimani Stage'],
    pickup: ['CBD - Kibuye', 'Mamboleo - Stage', 'Kondele - Stage', 'Maseno - Junction', 'Awasi - Stage']
  },
  'Eldoret': {
    boarding: ['Bus Station CBD', 'Uganda Road Stage', 'Oloo Street Terminal'],
    pickup: ['CBD - Bus Station', 'Langas - Stage', 'Kapseret - Stage', 'Turbo - Junction', 'Burnt Forest - Stage']
  },
  'Nakuru': {
    boarding: ['Nakuru Town Stage', 'Stem Hotel', 'Nakuru Highway', 'Bus Station CBD', 'Kenyatta Avenue', 'Oginga Odinga Avenue'],
    pickup: ['CBD - Bus Station', 'Stem Hotel - Stop', 'Nakuru Highway - Junction', 'Milimani - Stage', 'Section 5 - Stage', 'Naivasha - Junction', 'Gilgil - Stage', 'Lanet - Stage']
  },
  'Kampala': {
    boarding: ['New Bus Park', 'Old Taxi Park', 'Kisenyi Stage'],
    pickup: ['CBD - New Bus Park', 'Nansana - Stage', 'Kawempe - Stage', 'Mukono - Junction', 'Entebbe - Road', 'Jinja - Highway']
  },
  'Dar es Salaam': {
    boarding: ['Mwenge Terminal', 'Ubungo Bus Stand', 'Shekilango Stage', 'Kariakoo Market', 'Chalinze Stage'],
    pickup: ['CBD - Kariakoo', 'Mwenge - Stage', 'Ubungo - Bus Stand', 'Sinza - Stage', 'Shekilango - Stage', 'Mbezi Beach - Stage', 'Bagamoyo - Road', 'Chalinze - Junction', 'Pugu - Stage']
  },
  'Malindi': {
    boarding: ['Bus Station CBD', 'Silversand Stage'],
    pickup: ['CBD - Bus Station', 'Watamu - Stage', 'Mambrui - Stage', 'Marafa - Stage']
  },
  'Meru': {
    boarding: ['Bus Station CBD', 'Makutano Stage'],
    pickup: ['CBD - Bus Station', 'Maua - Stage', 'Chuka - Stage', 'Nkubu - Stage']
  },
  'Busia': {
    boarding: ['Border Point Terminal', 'Busia Town Stage', 'Sofia Stage', 'CBD Stage'],
    pickup: ['Border - Bus Park', 'Busia Town - Centre', 'Sofia - Junction', 'CBD - Stage', 'Malaba - Junction', 'Nambale - Stage']
  }
};

const getBoardingPoints = (city: string): string[] => {
  return BOARDING_POINTS[city]?.boarding || ['Central Bus Station'];
};

const getPickupStations = (city: string): string[] => {
  return BOARDING_POINTS[city]?.pickup || ['Main Highway Stop'];
};

const getDuration = (origin: string, dest: string, price: number): string => {
  if (origin === 'Dar es Salaam' || dest === 'Dar es Salaam') return '16-20 Hours';
  if (origin === 'Kampala' || dest === 'Kampala') return '12-16 Hours';
  if (price > 2500) return '10-14 Hours';
  return '4-7 Hours';
};

export const generateRoutesForHubs = (): BusRoute[] => {
  const generated: BusRoute[] = [];
  let routeId = 100;
  const times = ['06:00 AM', '08:30 AM', '10:00 AM', '02:00 PM', '07:30 PM', '09:00 PM', '10:30 PM'];

  HUB_CITIES.forEach(origin => {
    ALL_DESTINATIONS.forEach(dest => {
      if (origin === dest) return;
      const basePrice = getBasePrice(origin, dest);
      if (basePrice === 0) return;

      const tripCount = origin === 'Mombasa' ? 4 : 2;

      for (let i = 0; i < tripCount; i++) {
        const departureTime = times[(routeId + i) % times.length];
        const busType = i % 2 === 0 ? 'VIP' : 'Executive';
        const price = busType === 'VIP' ? basePrice + 600 : basePrice;

        generated.push({
          id: `rt-${routeId++}`,
          title: `${origin} to ${dest} ${busType}`,
          origin: origin,
          destination: dest,
          price: price,
          duration: getDuration(origin, dest, price),
          departureTime: departureTime,
          image: routeId % 3 === 0 ? IMAGES.ROAD_BUS : routeId % 3 === 1 ? IMAGES.FLEET_FRONT : IMAGES.MARKET_BUS,
          rating: 4.5 + (Math.random() * 0.5),
          features: ['Air Con', 'USB Charging', 'Luxury Seats', 'WiFi', 'Refreshments'],
          availablePaymentMethods: DEFAULT_PAYMENT_METHODS,
          busType: busType,
          totalSeats: 49,
          occupiedSeats: Array.from({ length: 12 }, () => Math.floor(Math.random() * 49) + 1),
          boardingPoints: getBoardingPoints(origin),
          pickupStations: getPickupStations(origin)
        });
      }
    });
  });

  return generated;
};

export const routes: BusRoute[] = generateRoutesForHubs();

export const blogPosts: BlogPost[] = [
  {
    id: 'b1',
    title: 'Top 5 Scenic Stops on the Nairobi-Mombasa Route',
    excerpt: 'Explore the hidden gems and beautiful landscapes you will encounter during your journey to the coast.',
    image: IMAGES.MARKET_BUS,
    date: 'Oct 20, 2023',
    author: 'Travel Team',
    category: 'Travel Tips'
  },
  {
    id: 'b2',
    title: 'Why Choose VIP Class for Your Next Trip?',
    excerpt: 'Discover the premium amenities and unparalleled comfort of our executive VIP bus services.',
    image: IMAGES.INTERIOR,
    date: 'Nov 05, 2023',
    author: 'Logistics Dept',
    category: 'Luxury Travel'
  },
  {
    id: 'b3',
    title: 'Expanding Our Network: New Routes to Western Kenya',
    excerpt: 'We are thrilled to announce more daily departures to Kisumu, Eldoret, and Kitale starting this month.',
    image: IMAGES.SCHEDULE_AD,
    date: 'Dec 12, 2023',
    author: 'Management',
    category: 'News'
  }
];